# ADR-31: Database-Generated Offer Codes via IDENTITY

## Status
Accepted

## Date
2026-02-05

## Context

### Problem
Application-level offer code generation using `MAX(OfferCode) + 1` creates race conditions during concurrent tactic creation. This manifests as:

- **E2E Test Failures:** Proofreader tests fail intermittently with 500 errors when running in parallel
- **Race Condition:** Multiple concurrent requests can retrieve the same MAX value before any INSERT completes
- **Retry Complexity:** Required retry logic with exponential backoff adds code complexity
- **Performance Overhead:** Each tactic creation requires a MAX() query across all tactics

### Previous Implementation
```csharp
// Application-level generation (problematic)
var maxOfferCode = await _dbContext.Tactics.MaxAsync(t => (int?)t.OfferCode);
var nextOfferCode = maxOfferCode.HasValue ? maxOfferCode.Value + 1 : 100000;

// Retry loop for collision handling
for (int attempt = 1; attempt <= MaxRetryAttempts; attempt++) {
    try {
        tactic.OfferCode = nextOfferCode;
        await _tacticRepository.AddAsync(tactic);
        break;
    }
    catch (DuplicateOfferCodeException) {
        // Retry with backoff...
    }
}
```

### Root Cause
The gap between reading MAX(OfferCode) and inserting the new tactic allows concurrent operations to generate duplicate values. Even with retry logic, the race window exists.

## Decision

**Use SQL Server IDENTITY column to generate offer codes atomically at the database level.**

### Implementation Details

**Database Schema:**
```sql
[OfferCode] INT NOT NULL IDENTITY(100000, 1)
```

**EF Core Configuration:**
```csharp
modelBuilder.Entity<Tactic>()
    .Property(t => t.OfferCode)
    .UseIdentityColumn(seed: 100000, increment: 1)
    .ValueGeneratedOnAdd();
```

**Application Code:**
```csharp
// Simplified - no retry logic needed
var newTactic = new Tactic(...);
await _tacticRepository.AddAsync(newTactic, cancellationToken);
// OfferCode is automatically populated by EF Core after SaveChangesAsync
```

## Consequences

### Positive

1. **Eliminates Race Conditions**
   - Database handles synchronization atomically
   - No concurrent access issues
   - Guaranteed unique values

2. **Simpler Application Code**
   - Removed 206 lines of retry logic
   - No `GetNextOfferCodeAsync()` method needed
   - No `MaxRetryAttempts` or `CalculateBackoffDelay()` complexity
   - Single `AddAsync()` call

3. **Better Performance**
   - No MAX() query overhead on every tactic creation
   - Single database round-trip instead of multiple (query + insert + potential retries)
   - Reduced database load

4. **Industry-Standard Pattern**
   - IDENTITY columns are the standard approach for auto-incrementing values
   - Well-understood by database administrators
   - Proven reliability at scale

5. **Test Reliability**
   - E2E tests can run in parallel without collisions
   - No intermittent failures due to timing issues
   - Predictable behavior

### Negative

1. **Offer Codes May Have Gaps**
   - **Acceptable:** Offer codes are identifiers, not sequential counters
   - Gaps occur due to:
     - Transaction rollbacks
     - Failed validations after IDENTITY generation
     - Deleted records (if implemented)
   - **Mitigation:** Document that gaps are expected and normal

2. **Database-Specific Feature**
   - **Mitigated:** EF Core abstracts the implementation
   - Different databases use different syntax (IDENTITY, SERIAL, AUTO_INCREMENT)
   - Current architecture already committed to SQL Server

3. **Cannot Pre-Assign Offer Codes**
   - Application cannot choose specific offer code values
   - **Acceptable:** No business requirement for pre-assigned codes
   - Codes are generated sequentially starting from 100000

4. **Migration Complexity for Existing Data**
   - Existing production tactics have manually assigned codes (1000-1009 range)
   - **Deferred:** Production migration handled in separate story
   - New development environments start clean with IDENTITY

### Performance Considerations

**Expected Load:**
- Tactic creation rate: < 10 per second (typical)
- Peak concurrent users: ~50
- IDENTITY contention: Negligible at this scale

**Monitoring:**
- Track tactic creation latency
- Monitor for IDENTITY-related blocking (unlikely)
- Alert if creation rate exceeds 100/second

**Scalability:**
- SQL Server IDENTITY performs well up to thousands of inserts/second
- Current scale is well within safe limits
- If scale increases significantly, consider partitioning strategies

## Alternatives Considered

### 1. Distributed Lock (e.g., Redis)
**Rejected:** Adds external dependency and complexity. IDENTITY is simpler and sufficient.

### 2. GUID/UUID for Offer Codes
**Rejected:** Business requirement for numeric, sequential-looking codes starting at 100000.

### 3. Application-Level Sequence Generator
**Rejected:** Still requires synchronization mechanism. Database IDENTITY is more reliable.

### 4. Optimistic Concurrency with Retry
**Rejected:** Current approach, proven unreliable under concurrent load.

## Implementation

### Files Modified
- `src/api/docker/mssql/init/003-create-tactic-tbl.sql` - Added IDENTITY to OfferCode column
- `src/api/docker/mssql/init/1000-seed-tactics.sql` - Removed explicit OfferCode values
- `src/api/src/TacticManagement.Infrastructure/Data/TacticDbContext.cs` - Added EF Core configuration
- `src/api/src/TacticManagement.Infrastructure/Repositories/TacticRepository.cs` - Removed GetNextOfferCodeAsync
- `src/api/src/TacticManagement.Application/Commands/CreateTacticCommandHandler.cs` - Removed retry logic

### Testing
- **Unit Tests:** 18/18 passing with simulated IDENTITY generation
- **E2E Tests:** Pending verification (proofreader tests)
- **Manual Testing:** Pending

### Rollback Plan
If critical issues arise:
1. Revert SQL init scripts to original versions
2. Remove EF Core IDENTITY configuration
3. Restore application code with retry logic
4. Temporary workaround: Run E2E tests serially (`workers: 1`)

**Note:** Rollback should be avoided if tactics have been created with IDENTITY codes. Fix forward instead.

## Related Documents

- **Implementation Plan:** `docs/reqs/_tech/0E - OfferCode Generation Fix/IMPLEMENTATION_PLAN.md`
- **TDD Test Plan:** `docs/reqs/_tech/0E - OfferCode Generation Fix/TDD_TEST_PLAN.md`
- **Story Analysis:** `docs/reqs/_tech/0E - OfferCode Generation Fix/STORY_ANALYSIS.md`
- **Design Review:** `docs/reqs/_tech/0E - OfferCode Generation Fix/DESIGN_REVIEW.md`

## References

- [SQL Server IDENTITY Property](https://learn.microsoft.com/en-us/sql/t-sql/statements/create-table-transact-sql-identity-property)
- [EF Core Value Generation](https://learn.microsoft.com/en-us/ef/core/modeling/generated-properties)
- [ADR-11: Delegate Duplicate to Create Command](20251124-11-delegate-duplicate-to-create-command.md)
- [ADR-12: Sequential Duplicate Operations](20251124-12-sequential-duplicate-operations.md)

## Notes

- **Non-breaking change:** No API contract changes required
- **No UI changes:** Frontend unaffected
- **Backward compatible:** Existing tactics unchanged
- **Isolated scope:** Only affects tactic creation flow
- **Production migration:** Deferred to separate story after validation

## Approval

- **Author:** Development Team
- **Reviewers:** TBD
- **Date Accepted:** 2026-02-05
