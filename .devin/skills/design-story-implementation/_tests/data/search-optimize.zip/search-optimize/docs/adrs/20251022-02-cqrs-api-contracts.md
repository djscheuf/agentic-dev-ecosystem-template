# 20251022-02. Adopt CQRS Pattern in API Contracts

Date: 2025-10-22

## Status

Accepted

## Context

As the Coupon Builder UI evolves, we're seeing increasing complexity in our API contracts where read and write operations are often mixed together, leading to:

1. Over-fetching of data in read operations
2. Complex mutations with side effects
3. Difficulty in optimizing read performance
4. Tight coupling between command and query responsibilities

The Command Query Responsibility Segregation (CQRS) pattern can help address these issues by separating read and write operations at the API contract level.

## Decision

We will adopt the CQRS pattern for our API contracts with the following guidelines:

1. **Separation of Commands and Queries**
   - Commands (writes) will use POST/PUT/PATCH/DELETE methods
   - Queries (reads) will use GET methods with clear naming conventions

2. **Naming Conventions**
   - Commands: `{Resource}Command` (e.g., `CreateCouponCommand`, `UpdateCouponCommand`)
   - Queries: `{Resource}Query` (e.g., `GetCouponByIdQuery`, `SearchCouponsQuery`)
   - Responses: `{Resource}Response` (e.g., `CouponResponse`, `CouponListResponse`)

3. **API Endpoints**
   - Commands: `/api/commands/{command-name}`
   - Queries: `/api/queries/{query-name}`

4. **Versioning**
   - All endpoints will be versioned (e.g., `/api/v1/...`)
   - Breaking changes will require a new version

## Consequences

### Benefits

- Clear separation of concerns between read and write operations
- Ability to optimize read and write paths independently
- Better scalability for read-heavy operations
- Improved maintainability and testability
- Easier to implement caching strategies for queries

### Drawbacks

- Initial learning curve for the team
- Slightly increased complexity in API design
- Potential for code duplication between commands and queries

### Risks

- Inconsistent implementation across the codebase
- Over-engineering simple CRUD operations

### Mitigation Strategies

- Provide clear documentation and examples
- Start with high-traffic or complex domains first
- Conduct knowledge sharing sessions
- Regular code reviews to ensure consistency
