using TacticManagement.Domain.Enums;

namespace TacticManagement.Domain.Models;

public class Tactic
{
    public Guid Id { get; set; }
    public string? Description { get; set; }
    public int OfferCode { get; set; }
    public int TacticTypeId { get; set; }
    public TacticType? TacticType { get; set; }
    public int DeliveryMethodId { get; set; }
    public DeliveryMethod? DeliveryMethod { get; set; }
    public string? PromoPlanId { get; set; }
    public string? Databar { get; set; }
    public string? Comments { get; set; }
    public string? Notes { get; set; }
    public int StatusId { get; set; }
    public Models.TacticStatus? Status { get; set; }
    public string OwnerId { get; set; }
    public string RequesterId { get; set; }
    
    // OpCo Assignment
    public Guid? OpCoId { get; set; }
    public OpCo? OpCo { get; set; }
    
    // Budget Input Fields (all nullable - optional)
    public decimal? FaceValue { get; set; }
    public int? CirculationQuantity { get; set; }
    public decimal? RedemptionRate { get; set; }
    public decimal? NonworkingBudget { get; set; }
    
    // Design Card Fields (all nullable - optional)
    public Guid? DigitalProviderId { get; set; }
    public Guid? CreativeAgencyId { get; set; }
    public Guid? PrinterId { get; set; }
    public string? DesignComments { get; set; }
    public string? DigitalProviderComments { get; set; }
    
    // Design Card Navigation Properties
    public DigitalProvider? DigitalProvider { get; set; }
    public CreativeAgency? CreativeAgency { get; set; }
    public Printer? Printer { get; set; }
    
    // Offer Details Fields (all nullable - optional)
    public int? ProductQuantity { get; set; }
    public int? OfferTypeId { get; set; }
    public string? OfferVerbiage { get; set; }
    public string? VerbiageComments { get; set; }
    
    // Offer Details Navigation Property
    public OfferType? OfferType { get; set; }
    
    public string LastModifiedBy { get; set; }
    public DateTime LastModified { get; set; }
    public DateTime CreatedDate { get; set; }
    public string CreatedBy { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public DateTime ExpiryDate { get; set; }

    // Accounting Allocations
    public ICollection<TacticAllocation> Allocations { get; set; } = new List<TacticAllocation>();

    // File Attachments
    public ICollection<TacticAttachment> Attachments { get; set; } = new List<TacticAttachment>();

    // Offer Verbiage Product Rows
    public ICollection<TacticProductRow> ProductRows { get; set; } = new List<TacticProductRow>();

    public Tactic(
        string description,
        string requesterId,
        DateTime startDate,
        DateTime endDate,
        DateTime expiryDate,
        string? ownerId = null
        )
    {
        Id = Guid.NewGuid();
        
        StatusId = (int)Enums.TacticStatusEnum.DRAFT;
        Description = description;
        StartDate = startDate;
        EndDate = endDate;
        ExpiryDate = expiryDate;

        RequesterId = requesterId;
        OwnerId = ownerId ?? requesterId;

        CreatedBy = requesterId;
        CreatedDate = DateTime.UtcNow;

        LastModified = DateTime.UtcNow;
        LastModifiedBy = requesterId;
    }

    public int GenerateOfferCode()
    {
        var random = new Random();
        return random.Next(100000, 1000000); // 6-digit number (100000-999999)
    }
}