import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { renderHook, waitFor } from "@testing-library/react";
import { useTacticTable } from "./use-tactic-table";
import tacticsApi from "../../../shared/apis/tactics-api";
import { useNavigate } from "react-router-dom";
import type { TacticListItemDTO } from "@coupon-builder/models";

// Mock dependencies
vi.mock("../../../shared/apis/tactics-api");
vi.mock("react-router-dom", () => ({
  useNavigate: vi.fn(),
}));
vi.mock("../../../shared/utils/logger.util", () => ({
  logger: {
    info: vi.fn(),
    error: vi.fn(),
    debug: vi.fn(),
    warn: vi.fn(),
  },
}));

describe("useTacticTable", () => {
  const mockNavigate = vi.fn();
  const mockTactics: TacticListItemDTO[] = [
    {
      id: "1",
      offerCode: "OFFER-001",
      description: "Test Tactic 1",
      status: "DRAFT",
      tacticDistributionMethodId: 1,
      campaignStartDate: new Date("2024-01-01"),
      campaignEndDate: new Date("2024-12-31"),
    },
    {
      id: "2",
      offerCode: "OFFER-002",
      description: "Test Tactic 2",
      status: "PROOF_READY",
      tacticDistributionMethodId: 2,
      campaignStartDate: new Date("2024-02-01"),
      campaignEndDate: new Date("2024-11-30"),
    },
  ];

  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(useNavigate).mockReturnValue(mockNavigate);
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe("GIVEN the hook is initialized", () => {
    describe("WHEN tactics are successfully fetched", () => {
      beforeEach(() => {
        vi.mocked(tacticsApi.getTactics).mockResolvedValue({
          items: mockTactics,
        });
      });

      it("THEN sets isLoading to true initially", async () => {
        const { result } = renderHook(() => useTacticTable());
        // Check immediately - should be true before effect completes
        expect(result.current.isLoading).toBe(true);

        // Wait for the effect to complete
        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });
      });

      it("THEN fetches tactics from the API", async () => {
        renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(tacticsApi.getTactics).toHaveBeenCalledTimes(1);
        });
      });

      it("THEN sets tactics data correctly", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        expect(result.current.tactics).toEqual(mockTactics);
        expect(result.current.error).toBeNull();
      });

      it("THEN provides tableProps with data and onRowClick", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        expect(result.current.tableProps).toHaveProperty("data", mockTactics);
        expect(result.current.tableProps).toHaveProperty("onRowClick");
        expect(typeof result.current.tableProps.onRowClick).toBe("function");
      });
    });

    describe("WHEN API returns empty array", () => {
      beforeEach(() => {
        vi.mocked(tacticsApi.getTactics).mockResolvedValue({
          items: [],
        });
      });

      it("THEN sets tactics to empty array", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        expect(result.current.tactics).toEqual([]);
        expect(result.current.error).toBeNull();
      });
    });

    describe("WHEN API call fails", () => {
      const mockError = new Error("Failed to fetch tactics");

      beforeEach(() => {
        vi.mocked(tacticsApi.getTactics).mockRejectedValue(mockError);
      });

      it("THEN sets error state", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        expect(result.current.error).toEqual(mockError);
        expect(result.current.tactics).toEqual([]);
      });

      it("THEN sets isLoading to false", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        expect(result.current.isLoading).toBe(false);
      });
    });

    describe("WHEN API throws non-Error object", () => {
      beforeEach(() => {
        vi.mocked(tacticsApi.getTactics).mockRejectedValue("String error");
      });

      it("THEN wraps error in Error object", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        expect(result.current.error).toBeInstanceOf(Error);
        expect(result.current.error?.message).toBe("Unknown error occurred");
      });
    });
  });

  describe("GIVEN tactics are loaded", () => {
    beforeEach(() => {
      vi.mocked(tacticsApi.getTactics).mockResolvedValue({
        items: mockTactics,
      });
    });

    describe("WHEN a row is clicked", () => {
      it("THEN navigates to the tactic details page", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        const tacticToClick = mockTactics[0];
        result.current.tableProps.onRowClick(tacticToClick);

        expect(mockNavigate).toHaveBeenCalledWith(
          `/tactic/${tacticToClick.id}`,
        );
      });

      it("THEN navigates with correct tactic ID", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        const tacticToClick = mockTactics[1];
        result.current.tableProps.onRowClick(tacticToClick);

        expect(mockNavigate).toHaveBeenCalledWith("/tactic/2");
      });
    });
  });

  describe("F-T30: Filter State Management - tacticTypeIds", () => {
    beforeEach(() => {
      vi.mocked(tacticsApi.getTactics).mockResolvedValue({
        items: mockTactics,
      });
    });

    describe("GIVEN the hook is initialized", () => {
      it("THEN tacticTypeIds should default to empty array", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        expect(result.current.tacticTypeIds).toEqual([]);
      });

      it("THEN should provide setTacticTypeIds function", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        expect(result.current.setTacticTypeIds).toBeDefined();
        expect(typeof result.current.setTacticTypeIds).toBe("function");
      });
    });

    describe("WHEN setTacticTypeIds is called", () => {
      it("THEN should update tacticTypeIds state", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        const newTacticTypeIds = [1, 2, 3];
        result.current.setTacticTypeIds(newTacticTypeIds);

        await waitFor(() => {
          expect(result.current.tacticTypeIds).toEqual(newTacticTypeIds);
        });
      });

      it("THEN should handle empty array", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        result.current.setTacticTypeIds([1, 2]);
        await waitFor(() => {
          expect(result.current.tacticTypeIds).toEqual([1, 2]);
        });

        result.current.setTacticTypeIds([]);
        await waitFor(() => {
          expect(result.current.tacticTypeIds).toEqual([]);
        });
      });

      it("THEN should trigger API refetch with filter parameters", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        vi.clearAllMocks();

        result.current.setTacticTypeIds([1, 2]);

        await waitFor(() => {
          expect(tacticsApi.getTactics).toHaveBeenCalledWith({
            sortBy: "offerCode",
            sortOrder: "desc",
            page: 1,
            pageSize: 20,
            tacticTypeIds: [1, 2],
          });
        });
      });
    });
  });

  describe("F-T32: Search input is debounced (300ms)", () => {
    beforeEach(() => {
      vi.mocked(tacticsApi.getTactics).mockResolvedValue({
        items: mockTactics,
      });
    });

    describe("GIVEN the hook is initialized", () => {
      it("THEN should provide searchTerm state", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        expect(result.current.searchTerm).toBeDefined();
        expect(result.current.searchTerm).toBe("");
      });

      it("THEN should provide setSearchTerm function", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        expect(result.current.setSearchTerm).toBeDefined();
        expect(typeof result.current.setSearchTerm).toBe("function");
      });
    });

    describe("WHEN setSearchTerm is called rapidly", () => {
      it("THEN should debounce API calls with 300ms delay", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        vi.clearAllMocks();

        // Type rapidly - each keystroke within 300ms
        result.current.setSearchTerm("a");
        await new Promise(resolve => setTimeout(resolve, 50));
        
        result.current.setSearchTerm("ab");
        await new Promise(resolve => setTimeout(resolve, 50));
        
        result.current.setSearchTerm("abc");

        // Should not have called API yet (within debounce window)
        expect(tacticsApi.getTactics).not.toHaveBeenCalled();

        // Wait for debounce delay to complete
        await waitFor(() => {
          expect(tacticsApi.getTactics).toHaveBeenCalledTimes(1);
        }, { timeout: 500 });

        expect(tacticsApi.getTactics).toHaveBeenCalledWith({
          sortBy: "offerCode",
          sortOrder: "desc",
          page: 1,
          pageSize: 20,
          term: "abc",
        });
      });

      it("THEN should cancel previous debounced calls", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        vi.clearAllMocks();

        // Type "test" rapidly
        result.current.setSearchTerm("t");
        await new Promise(resolve => setTimeout(resolve, 50));
        
        result.current.setSearchTerm("te");
        await new Promise(resolve => setTimeout(resolve, 50));
        
        result.current.setSearchTerm("tes");
        await new Promise(resolve => setTimeout(resolve, 50));
        
        result.current.setSearchTerm("test");

        // Wait for debounce to complete
        await waitFor(() => {
          expect(tacticsApi.getTactics).toHaveBeenCalled();
        }, { timeout: 500 });

        // Should only call API once with final value
        expect(tacticsApi.getTactics).toHaveBeenCalledTimes(1);
        expect(tacticsApi.getTactics).toHaveBeenCalledWith({
          sortBy: "offerCode",
          sortOrder: "desc",
          page: 1,
          pageSize: 20,
          term: "test",
        });
      });

      it("THEN should handle empty search term", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        vi.clearAllMocks();

        result.current.setSearchTerm("test");

        await waitFor(() => {
          expect(tacticsApi.getTactics).toHaveBeenCalledWith({
            sortBy: "offerCode",
            sortOrder: "desc",
            page: 1,
            pageSize: 20,
            term: "test",
          });
        }, { timeout: 500 });

        vi.clearAllMocks();

        // Clear search
        result.current.setSearchTerm("");

        await waitFor(() => {
          expect(tacticsApi.getTactics).toHaveBeenCalledWith({
            sortBy: "offerCode",
            sortOrder: "desc",
            page: 1,
            pageSize: 20,
          });
        }, { timeout: 500 });
      });
    });

    describe("WHEN combining search with tacticTypeIds filter", () => {
      it("THEN should include both parameters in API call", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        vi.clearAllMocks();

        // Set both filters
        result.current.setTacticTypeIds([1, 2]);
        result.current.setSearchTerm("test");

        await waitFor(() => {
          expect(tacticsApi.getTactics).toHaveBeenCalledWith({
            sortBy: "offerCode",
            sortOrder: "desc",
            page: 1,
            pageSize: 20,
            tacticTypeIds: [1, 2],
            term: "test",
          });
        }, { timeout: 500 });
      });
    });
  });

  describe("F-T40: Clear Filters button resets all filters", () => {
    beforeEach(() => {
      vi.mocked(tacticsApi.getTactics).mockResolvedValue({
        items: mockTactics,
      });
    });

    describe("GIVEN filters are applied", () => {
      it("THEN should provide clearFilters function", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        expect(result.current.clearFilters).toBeDefined();
        expect(typeof result.current.clearFilters).toBe("function");
      });
    });

    describe("WHEN clearFilters is called", () => {
      it("THEN should reset tacticTypeIds to empty array", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        // Set filters
        result.current.setTacticTypeIds([1, 2, 3]);
        await waitFor(() => {
          expect(result.current.tacticTypeIds).toEqual([1, 2, 3]);
        });

        // Clear filters
        result.current.clearFilters();

        await waitFor(() => {
          expect(result.current.tacticTypeIds).toEqual([]);
        });
      });

      it("THEN should reset searchTerm to empty string", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        // Set search term
        result.current.setSearchTerm("test search");
        await waitFor(() => {
          expect(result.current.searchTerm).toBe("test search");
        });

        // Clear filters
        result.current.clearFilters();

        await waitFor(() => {
          expect(result.current.searchTerm).toBe("");
        });
      });

      it("THEN should reset all filters at once", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        // Set multiple filters
        result.current.setTacticTypeIds([1, 2]);
        result.current.setSearchTerm("test");

        await waitFor(() => {
          expect(result.current.tacticTypeIds).toEqual([1, 2]);
          expect(result.current.searchTerm).toBe("test");
        });

        vi.clearAllMocks();

        // Clear all filters
        result.current.clearFilters();

        await waitFor(() => {
          expect(result.current.tacticTypeIds).toEqual([]);
          expect(result.current.searchTerm).toBe("");
        });
      });

      it("THEN should trigger API refetch with no filters", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        // Set filters
        result.current.setTacticTypeIds([1, 2]);
        result.current.setSearchTerm("test");

        await waitFor(() => {
          expect(tacticsApi.getTactics).toHaveBeenCalledWith({
            sortBy: "offerCode",
            sortOrder: "desc",
            page: 1,
            pageSize: 20,
            tacticTypeIds: [1, 2],
            term: "test",
          });
        }, { timeout: 500 });

        vi.clearAllMocks();

        // Clear filters
        result.current.clearFilters();

        await waitFor(() => {
          expect(tacticsApi.getTactics).toHaveBeenCalledWith({
            sortBy: "offerCode",
            sortOrder: "desc",
            page: 1,
            pageSize: 20,
          });
        }, { timeout: 500 });
      });

      it("THEN should handle clearing when no filters are set", async () => {
        const { result } = renderHook(() => useTacticTable());

        await waitFor(() => {
          expect(result.current.isLoading).toBe(false);
        });

        // Clear filters when none are set
        result.current.clearFilters();

        // Should still have default values
        expect(result.current.tacticTypeIds).toEqual([]);
        expect(result.current.searchTerm).toBe("");
      });
    });
  });
});
