using MediatR;
using TacticManagement.Application.Tactics.DTOs;

namespace TacticManagement.Application.Tactics.Queries
{
    public record GetUserTacticsQuery(
        string UserId,
        string? Term,
        string? Status,
        List<int>? TacticTypeIds,
        List<string>? StatusCodes,
        List<string>? RequesterUserIds,
        int Page,
        int PageSize,
        string SortBy,
        string SortOrder) : IRequest<PaginatedResponseDto<TacticListItemDto>>;
}
