using FluentAssertions;
using Microsoft.Extensions.Logging;
using NSubstitute;
using TacticManagement.Application.Interfaces;
using TacticManagement.Application.Common.Interfaces;
using TacticManagement.Application.Queries;
using TacticManagement.Application.Repositories;
using TacticManagement.Application.Tactics.DTOs;
using TacticManagement.Application.Tactics.Queries;
using TacticManagement.Application.Tests.Helpers;
using TacticManagement.Domain.Enums;
using TacticStatusEnum = TacticManagement.Domain.Enums.TacticStatusEnum;
using TacticManagement.Domain.Models;
using Xunit;

namespace TacticManagement.Application.Tests.Queries;

public class GetUserTacticsQueryHandlerSearchAndFiltersTests : IDisposable
{
    private readonly ITacticRepository _mockRepository;
    private readonly IUserContextService _mockUserContextService;
    private readonly IUserEntityRepository _mockUserEntityRepository;
    private readonly ILogger<GetUserTacticsQueryHandler> _mockLogger;
    private readonly GetUserTacticsQueryHandler _handler;
    private GetUserTacticsQuery _query = null!;
    private PaginatedResponseDto<TacticListItemDto>? _result;
    private readonly CancellationToken _cancellationToken;
    private readonly string _userId = "user-123";

    private readonly ITacticReadAuthorizationService _mockAuthService;

    public GetUserTacticsQueryHandlerSearchAndFiltersTests()
    {
        _mockRepository = Substitute.For<ITacticRepository>();
        _mockUserContextService = Substitute.For<IUserContextService>();
        _mockUserEntityRepository = Substitute.For<IUserEntityRepository>();
        _mockAuthService = Substitute.For<ITacticReadAuthorizationService>();
        var mockUserOpCoRepo = Substitute.For<IUserOpCoRepository>();
        _mockLogger = Substitute.For<ILogger<GetUserTacticsQueryHandler>>();
        _handler = new GetUserTacticsQueryHandler(_mockRepository, _mockUserContextService, _mockUserEntityRepository, _mockAuthService, mockUserOpCoRepo, _mockLogger);
        _cancellationToken = CancellationToken.None;

        _mockUserContextService
            .GetUserContextAsync(Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(callInfo => new TacticManagement.Application.Common.Models.UserContext(
                UserId: callInfo.ArgAt<string>(0),
                Roles: new List<string> { "Requester" },
                OpCos: Array.Empty<TacticManagement.Application.Common.Models.OpCoInfo>(),
                BusinessEntity: null,
                IsAuthenticated: true,
                FromJwt: false));
        
        // Default: authorization service returns a filter for Requester role
        _mockAuthService
            .BuildReadAuthorizationFiltersAsync(
                Arg.Any<string>(),
                Arg.Any<TacticManagement.Application.Common.Models.UserContext>(),
                Arg.Any<List<string>?>(),
                Arg.Any<string>(),
                Arg.Any<CancellationToken>())
            .Returns(callInfo =>
            {
                var userId = callInfo.ArgAt<string>(0);
                var filters = new List<System.Linq.Expressions.Expression<Func<Tactic, bool>>>
                {
                    t => t.OwnerId == userId || t.RequesterId == userId
                };
                return Task.FromResult(filters);
            });
        
        // Default: count mock returns 1 for most tests
        _mockRepository
            .GetUserTacticsWithFiltersCountAsync(
                Arg.Any<List<System.Linq.Expressions.Expression<Func<Tactic, bool>>>>(),
                Arg.Any<string?>(),
                Arg.Any<TacticStatusEnum?>(),
                Arg.Any<List<int>?>(),
                Arg.Any<List<string>?>(),
                Arg.Any<CancellationToken>())
            .Returns(1);
        
        // Setup catch-all mock for GetUserTacticsWithFiltersAsync to return what GetUserTacticsAsync returns
        _mockRepository.GetUserTacticsWithFiltersAsync(
            Arg.Any<List<System.Linq.Expressions.Expression<Func<Tactic, bool>>>>(),
            Arg.Any<string?>(),
            Arg.Any<TacticStatusEnum?>(),
            Arg.Any<List<int>?>(),
            Arg.Any<List<string>?>(),
            Arg.Any<int>(),
            Arg.Any<int>(),
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<CancellationToken>())
            .Returns(callInfo => 
            {
                // Delegate to GetUserTacticsAsync mock if it's been set up
                var searchTerm = callInfo.ArgAt<string?>(1);
                var status = callInfo.ArgAt<TacticStatus?>(2);
                var tacticTypeIds = callInfo.ArgAt<List<int>?>(3);
                var statusCodes = callInfo.ArgAt<List<string>?>(4);
                var page = callInfo.ArgAt<int>(5);
                var pageSize = callInfo.ArgAt<int>(6);
                var sortBy = callInfo.ArgAt<string>(7);
                var sortOrder = callInfo.ArgAt<string>(8);
                var ct = callInfo.ArgAt<CancellationToken>(9);
                
                return _mockRepository.GetUserTacticsAsync(
                    _userId, searchTerm, null, null, null, null, page, pageSize, sortBy, sortOrder, ct);
            });
    }

    public void Dispose()
    {
    }

    private async Task When_Handling_Query()
    {
        _result = await _handler.Handle(_query, _cancellationToken);
    }

    #region Search Expansion Tests (B-T13 to B-T16)

    [Fact]
    public async Task Handle_SearchTerm_MatchesBrandField()
    {
        // Arrange
        var brand = new VerbiageBrand { Id = 1, Name = "Purina Pro Plan" };
        var tactic = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(_userId)
            .WithRequesterId(_userId)
            .WithDescription("Test tactic")
            .Build();

        tactic.ProductRows = new List<TacticProductRow>
        {
            new TacticProductRow { Id = Guid.NewGuid(), BrandId = 1, Brand = "Purina Pro Plan", BrandNavigation = brand, TacticId = tactic.Id }
        };

        _query = new GetUserTacticsQuery(_userId, "Pro Plan", null, null, null, null, 1, 20, "", "");
        _mockRepository.GetUserTacticsAsync(
            Arg.Any<string>(), Arg.Is<string?>(s => s == "Pro Plan"), Arg.Any<TacticStatusEnum?>(),
            Arg.Any<List<int>?>(), Arg.Any<List<string>?>(), Arg.Any<int?>(),
            Arg.Any<int>(), Arg.Any<int>(), Arg.Any<string>(), Arg.Any<string>(),
            Arg.Any<CancellationToken>())
            .Returns(new List<Tactic> { tactic });
        _mockRepository.GetUserTacticsWithFiltersAsync(
            Arg.Any<List<System.Linq.Expressions.Expression<Func<Tactic, bool>>>>(),
            Arg.Is<string?>(s => s == "Pro Plan"), Arg.Any<TacticStatusEnum?>(),
            Arg.Any<List<int>?>(), Arg.Any<List<string>?>(),
            Arg.Any<int>(), Arg.Any<int>(), Arg.Any<string>(), Arg.Any<string>(),
            Arg.Any<CancellationToken>())
            .Returns(new List<Tactic> { tactic });

        // Act
        await When_Handling_Query();

        // Assert
        _result.Should().NotBeNull();
        _result!.Items.Should().HaveCount(1);
        _result.Items.First().Brand.Should().Contain("Purina Pro Plan");
    }

    [Fact]
    public async Task Handle_SearchTerm_MatchesDigitalProviderField()
    {
        // Arrange
        var digitalProviderId = Guid.NewGuid();
        var digitalProvider = new DigitalProvider { Id = digitalProviderId, Name = "Amazon" };
        var tactic = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(_userId)
            .WithRequesterId(_userId)
            .WithDescription("Test tactic")
            .Build();

        tactic.DigitalProviderId = digitalProviderId;
        tactic.DigitalProvider = digitalProvider;

        _query = new GetUserTacticsQuery(_userId, "Amazon", null, null, null, null, 1, 20, "", "");
        _mockRepository.GetUserTacticsAsync(
            Arg.Any<string>(), Arg.Is<string?>(s => s == "Amazon"), Arg.Any<TacticStatusEnum?>(),
            Arg.Any<List<int>?>(), Arg.Any<List<string>?>(), Arg.Any<int?>(),
            Arg.Any<int>(), Arg.Any<int>(), Arg.Any<string>(), Arg.Any<string>(),
            Arg.Any<CancellationToken>())
            .Returns(new List<Tactic> { tactic });

        // Act
        await When_Handling_Query();

        // Assert
        _result.Should().NotBeNull();
        _result!.Items.Should().HaveCount(1);
        _result.Items.First().Vendors.Should().Be("Amazon");
    }

    [Fact]
    public async Task Handle_SearchTerm_MatchesDescriptionField()
    {
        // Arrange
        var tactic = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(_userId)
            .WithRequesterId(_userId)
            .WithDescription("Holiday promotion")
            .Build();

        _query = new GetUserTacticsQuery(_userId, "Holiday", null, null, null, null, 1, 20, "", "");
        _mockRepository.GetUserTacticsAsync(
            Arg.Any<string>(), Arg.Is<string?>(s => s == "Holiday"), Arg.Any<TacticStatusEnum?>(),
            Arg.Any<List<int>?>(), Arg.Any<List<string>?>(), Arg.Any<int?>(),
            Arg.Any<int>(), Arg.Any<int>(), Arg.Any<string>(), Arg.Any<string>(),
            Arg.Any<CancellationToken>())
            .Returns(new List<Tactic> { tactic });

        // Act
        await When_Handling_Query();

        // Assert
        _result.Should().NotBeNull();
        _result!.Items.Should().HaveCount(1);
        _result.Items.First().Description.Should().Contain("Holiday");
    }

    [Fact]
    public async Task Handle_SearchTerm_MatchesOfferVerbiageField()
    {
        // Arrange
        var tactic = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(_userId)
            .WithRequesterId(_userId)
            .WithDescription("Test tactic")
            .Build();

        tactic.OfferVerbiage = "Save 20% on all products";

        _query = new GetUserTacticsQuery(_userId, "Save 20%", null, null, null, null, 1, 20, "", "");
        _mockRepository.GetUserTacticsAsync(
            Arg.Any<string>(), Arg.Is<string?>(s => s == "Save 20%"), Arg.Any<TacticStatusEnum?>(),
            Arg.Any<List<int>?>(), Arg.Any<List<string>?>(), Arg.Any<int?>(),
            Arg.Any<int>(), Arg.Any<int>(), Arg.Any<string>(), Arg.Any<string>(),
            Arg.Any<CancellationToken>())
            .Returns(new List<Tactic> { tactic });

        // Act
        await When_Handling_Query();

        // Assert
        _result.Should().NotBeNull();
        _result!.Items.Should().HaveCount(1);
        _result.Items.First().OfferVerbiage.Should().Contain("Save 20%");
    }

    #endregion

    #region Filter Tests (B-T17 to B-T20)

    [Fact]
    public async Task Handle_TacticTypeIdsFilter_WithSingleId_ReturnsMatchingTactics()
    {
        // Arrange
        var tacticType1 = new TacticType { Id = 1, Name = "Digital Coupon" };
        var tacticType2 = new TacticType { Id = 2, Name = "Print Coupon" };

        var tactic1 = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(_userId)
            .WithRequesterId(_userId)
            .Build();
        tactic1.TacticTypeId = 1;
        tactic1.TacticType = tacticType1;

        var tactic2 = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(_userId)
            .WithRequesterId(_userId)
            .Build();
        tactic2.TacticTypeId = 2;
        tactic2.TacticType = tacticType2;

        _query = new GetUserTacticsQuery(_userId, null, null, new List<int> { 1 }, null, null, 1, 20, "", "");
        _mockRepository.GetUserTacticsAsync(
            Arg.Any<string>(), Arg.Any<string?>(), Arg.Any<TacticStatusEnum?>(),
            Arg.Any<List<int>?>(), Arg.Any<List<string>?>(), Arg.Any<int?>(),
            Arg.Any<int>(), Arg.Any<int>(), Arg.Any<string>(), Arg.Any<string>(),
            Arg.Any<CancellationToken>())
            .Returns(new List<Tactic> { tactic1 }); // Only tactic1 should be returned

        // Act
        await When_Handling_Query();

        // Assert
        _result.Should().NotBeNull();
        _result!.Items.Should().HaveCount(1);
        _result.Items.First().TacticTypeName.Should().Be("Digital Coupon");
    }

    [Fact]
    public async Task Handle_TacticTypeIdsFilter_WithMultipleIds_ReturnsMatchingTactics()
    {
        // Arrange
        var tacticType1 = new TacticType { Id = 1, Name = "Digital Coupon" };
        var tacticType2 = new TacticType { Id = 2, Name = "Print Coupon" };
        var tacticType3 = new TacticType { Id = 3, Name = "Rebate" };

        var tactic1 = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(_userId)
            .WithRequesterId(_userId)
            .Build();
        tactic1.TacticTypeId = 1;
        tactic1.TacticType = tacticType1;

        var tactic2 = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(_userId)
            .WithRequesterId(_userId)
            .Build();
        tactic2.TacticTypeId = 2;
        tactic2.TacticType = tacticType2;

        var tactic3 = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(_userId)
            .WithRequesterId(_userId)
            .Build();
        tactic3.TacticTypeId = 3;
        tactic3.TacticType = tacticType3;

        _query = new GetUserTacticsQuery(_userId, null, null, new List<int> { 1, 2 }, null, null, 1, 20, "", "");
        _mockRepository.GetUserTacticsAsync(
            Arg.Any<string>(), Arg.Any<string?>(), Arg.Any<TacticStatusEnum?>(),
            Arg.Any<List<int>?>(), Arg.Any<List<string>?>(), Arg.Any<int?>(),
            Arg.Any<int>(), Arg.Any<int>(), Arg.Any<string>(), Arg.Any<string>(),
            Arg.Any<CancellationToken>())
            .Returns(new List<Tactic> { tactic1, tactic2 }); // Only tactic1 and tactic2 should be returned

        // Act
        await When_Handling_Query();

        // Assert
        _result.Should().NotBeNull();
        _result!.Items.Should().HaveCount(2);
        _result.Items.Select(t => t.TacticTypeName).Should().Contain(new[] { "Digital Coupon", "Print Coupon" });
    }

    [Fact]
    public async Task Handle_UserIdFilter_MatchesRequester()
    {
        // Arrange
        var requester1 = "requester-1";
        var requester2 = "requester-2";

        var tactic1 = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(_userId)
            .WithRequesterId(requester1)
            .Build();

        var tactic2 = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(_userId)
            .WithRequesterId(requester2)
            .Build();

        _query = new GetUserTacticsQuery(_userId, null, null, null, null, null, 1, 20, "", "");
        _mockRepository.GetUserTacticsAsync(
            Arg.Any<string>(), Arg.Any<string?>(), Arg.Any<TacticStatusEnum?>(),
            Arg.Any<List<int>?>(), Arg.Any<List<string>?>(), Arg.Any<int?>(),
            Arg.Any<int>(), Arg.Any<int>(), Arg.Any<string>(), Arg.Any<string>(),
            Arg.Any<CancellationToken>())
            .Returns(new List<Tactic> { tactic1 }); // Only tactic1 should be returned

        // Act
        await When_Handling_Query();

        // Assert
        _result.Should().NotBeNull();
        _result!.Items.Should().HaveCount(1);
        // Note: RequesterId is not in DTO anymore, but we can verify the tactic was filtered correctly
        _result.Items.First().Id.Should().Be(tactic1.Id);
    }

    [Fact]
    public async Task Handle_UserIdFilter_MatchesOwner()
    {
        // Arrange
        var owner1 = "owner-1";
        var owner2 = "owner-2";

        var tactic1 = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(owner1)
            .WithRequesterId(_userId)
            .Build();

        var tactic2 = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(owner2)
            .WithRequesterId(_userId)
            .Build();

        _query = new GetUserTacticsQuery(_userId, null, null, null, null, null, 1, 20, "", "");
        _mockRepository.GetUserTacticsAsync(
            Arg.Any<string>(), Arg.Any<string?>(), Arg.Any<TacticStatusEnum?>(),
            Arg.Any<List<int>?>(), Arg.Any<List<string>?>(), Arg.Any<int?>(),
            Arg.Any<int>(), Arg.Any<int>(), Arg.Any<string>(), Arg.Any<string>(),
            Arg.Any<CancellationToken>())
            .Returns(new List<Tactic> { tactic1 }); // Only tactic1 should be returned

        // Act
        await When_Handling_Query();

        // Assert
        _result.Should().NotBeNull();
        _result!.Items.Should().HaveCount(1);
        _result.Items.First().OwnerId.Should().Be(owner1);
    }

    #endregion

    #region Status Code Filtering Tests (B-T2 to B-T4)

    [Fact]
    public async Task Should_Filter_By_Single_Status_Code()
    {
        // Arrange - B-T2: Query handler filters by single status code
        var tactic1 = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(_userId)
            .WithStatus(TacticStatusEnum.DRAFT)
            .Build();

        var tactic2 = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(_userId)
            .WithStatus(TacticStatusEnum.PROOF_READY)
            .Build();

        _query = new GetUserTacticsQuery(_userId, null, null, null, new List<string> { "DRAFT" }, null, 1, 20, "", "");
        _mockRepository.GetUserTacticsAsync(
            Arg.Any<string>(), Arg.Any<string?>(), Arg.Any<TacticStatusEnum?>(),
            Arg.Any<List<int>?>(), Arg.Any<List<string>?>(), Arg.Any<int?>(),
            Arg.Any<int>(), Arg.Any<int>(), Arg.Any<string>(), Arg.Any<string>(),
            Arg.Any<CancellationToken>())
            .Returns(new List<Tactic> { tactic1 }); // Only DRAFT tactics

        // Act
        await When_Handling_Query();

        // Assert
        _result.Should().NotBeNull();
        _result!.Items.Should().HaveCount(1);
        _result.Items.First().Status.Should().Be("DRAFT");
    }

    [Fact]
    public async Task Should_Filter_By_Multiple_Status_Codes_With_OR_Logic()
    {
        // Arrange - B-T3: Query handler filters by multiple status codes (OR logic)
        var tactic1 = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(_userId)
            .WithStatus(TacticStatusEnum.DRAFT)
            .Build();

        var tactic2 = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(_userId)
            .WithStatus(TacticStatusEnum.PROOF_READY)
            .Build();

        var tactic3 = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(_userId)
            .WithStatus(TacticStatusEnum.FINAL_APPROVALS)
            .Build();

        _query = new GetUserTacticsQuery(_userId, null, null, null, new List<string> { "DRAFT", "PROOF_READY" }, null, 1, 20, "", "");
        _mockRepository.GetUserTacticsAsync(
            Arg.Any<string>(), Arg.Any<string?>(), Arg.Any<TacticStatusEnum?>(),
            Arg.Any<List<int>?>(), Arg.Any<List<string>?>(), Arg.Any<int?>(),
            Arg.Any<int>(), Arg.Any<int>(), Arg.Any<string>(), Arg.Any<string>(),
            Arg.Any<CancellationToken>())
            .Returns(new List<Tactic> { tactic1, tactic2 }); // DRAFT and PROOF_READY, not FINAL_APPROVALS

        // Act
        await When_Handling_Query();

        // Assert
        _result.Should().NotBeNull();
        _result!.Items.Should().HaveCount(2);
        _result.Items.Should().Contain(t => t.Status == "DRAFT");
        _result.Items.Should().Contain(t => t.Status == "PROOF_READY");
        _result.Items.Should().NotContain(t => t.Status == "FINAL_APPROVALS");
    }

    [Fact]
    public async Task Should_Combine_Status_Filter_With_Other_Filters_Using_AND_Logic()
    {
        // Arrange - B-T4: Status filter combines with other filters (AND logic)
        var tacticType1 = new TacticType { Id = 1, Name = "Digital Coupon" };
        
        var tactic1 = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(_userId)
            .WithStatus(TacticStatusEnum.DRAFT)
            .Build();
        tactic1.TacticTypeId = 1;
        tactic1.TacticType = tacticType1;

        var tactic2 = new TacticTestDataBuilder()
            .WithId(Guid.NewGuid())
            .WithOwnerId(_userId)
            .WithStatus(TacticStatusEnum.DRAFT)
            .Build();
        tactic2.TacticTypeId = 2;
        tactic2.TacticType = new TacticType { Id = 2, Name = "Print Coupon" };

        _query = new GetUserTacticsQuery(_userId, null, null, new List<int> { 1 }, new List<string> { "DRAFT" }, null, 1, 20, "", "");
        _mockRepository.GetUserTacticsAsync(
            Arg.Any<string>(), Arg.Any<string?>(), Arg.Any<TacticStatusEnum?>(),
            Arg.Any<List<int>?>(), Arg.Any<List<string>?>(), Arg.Any<int?>(),
            Arg.Any<int>(), Arg.Any<int>(), Arg.Any<string>(), Arg.Any<string>(),
            Arg.Any<CancellationToken>())
            .Returns(new List<Tactic> { tactic1 }); // Only tactic1 matches both filters

        // Act
        await When_Handling_Query();

        // Assert
        _result.Should().NotBeNull();
        _result!.Items.Should().HaveCount(1);
        _result.Items.First().Status.Should().Be("DRAFT");
        _result.Items.First().TacticTypeName.Should().Be("Digital Coupon");
    }

    #endregion
}
