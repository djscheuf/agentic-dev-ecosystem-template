import { logger } from "../utils/logger.util";
import { apiClient } from "../utils/api-client.util";
import { tacticApiBaseUrl, apiMode } from "../../config";
import type {
  Tactic,
  TacticListItemDTO,
  CreateTacticResponse,
  ValidationErrorResponse,
} from "@coupon-builder/models";

// Request body for updating a tactic (matches C# UpdateTacticRequest)
// Note: This is a partial update endpoint, but date fields are always sent
interface UpdateTacticRequest {
  tacticTypeId: number; // Required by backend
  campaignStartDate: string; // ISO date string - always sent
  campaignEndDate: string; // ISO date string - always sent
  expiryDate: string; // ISO date string - always sent (now required, non-nullable)
  description?: string;
  comments?: string;
  promoPlanId?: string;
  databar?: string;
  ownerId: string;
  deliveryMethodId?: number | null; // Allow null to match Tactic model
  // Budget fields (optional)
  faceValue?: number | null;
  circulationQuantity?: number | null;
  redemptionRate?: number | null;
  nonworkingBudget?: number | null;
  // Design Card fields (optional)
  digitalProviderId?: string | null;
  creativeAgencyId?: string | null;
  printerId?: string | null;
  designComments?: string | null;
  digitalProviderComments?: string | null;
  // Offer Details fields (optional)
  productQuantity?: number | null;
  offerTypeId?: number | null;
  offerVerbiage?: string | null;
  verbiageComments?: string | null;
}

// Response from duplicate endpoint
interface DuplicateTacticResponse {
  id: string; // New tactic ID
}

// Response from mark-proof-ready endpoint
interface MarkProofReadyResponse {
  tacticId: string;
  success: boolean;
  message: string | null;
  errors: ValidationError[] | null;
}

// Response from filter-presets endpoint
interface FilterPresetsDto {
  defaultStatuses: string[];
}

// Validation error structure from mark-proof-ready endpoint
interface ValidationError {
  property: string;
  errorCode: string;
  parameters?: Record<string, any>;
}

// Custom error class to preserve structured validation errors
export class ApiValidationError extends Error {
  public readonly errors: ValidationError[];
  public readonly statusCode: number;

  constructor(message: string, errors: ValidationError[], statusCode: number) {
    super(message);
    this.name = "ApiValidationError";
    this.errors = errors;
    this.statusCode = statusCode;
  }
}

// Helper function to convert API response to Tactic model and parse dates
const parseTacticDates = (tactic: any): Tactic => {
  return {
    id: tactic.id,
    offerCode: tactic.offerCode,
    description: tactic.description,
    comments: tactic.comments,
    status: tactic.status,
    tacticTypeId: tactic.tacticTypeId,
    tacticTypeName: tactic.tacticTypeName,
    tacticTypeCategory: tactic.tacticTypeCategory,
    deliveryMethodId: tactic.deliveryMethodId,
    deliveryMethodName: tactic.deliveryMethodName,
    ownerId: tactic.ownerId,
    requesterId: tactic.requesterId,
    lastModifiedBy: tactic.lastModifiedBy,
    lastModified: tactic.lastModified
      ? new Date(tactic.lastModified)
      : new Date(),
    created: tactic.created ? new Date(tactic.created) : new Date(),
    campaignStartDate: tactic.campaignStartDate
      ? new Date(tactic.campaignStartDate)
      : new Date(),
    campaignEndDate: tactic.campaignEndDate
      ? new Date(tactic.campaignEndDate)
      : new Date(),
    expiryDate: new Date(tactic.expiryDate),
    promoPlanId: tactic.promoPlanId,
    databar: tactic.databar,
    currency: tactic.currency,
    // Budget fields
    faceValue: tactic.faceValue,
    circulationQuantity: tactic.circulationQuantity,
    redemptionRate: tactic.redemptionRate,
    nonworkingBudget: tactic.nonworkingBudget,
    // Design fields
    digitalProviderId: tactic.digitalProviderId,
    creativeAgencyId: tactic.creativeAgencyId,
    printerId: tactic.printerId,
    designComments: tactic.designComments,
    // Offer Details fields
    productQuantity: tactic.productQuantity,
    offerTypeId: tactic.offerTypeId,
    offerVerbiage: tactic.offerVerbiage,
    verbiageComments: tactic.verbiageComments,
    // Allocations (directly from API - field names match)
    allocations: tactic.allocations ?? [],
  };
};

interface GetTacticsParams {
  term?: string;
  status?: string;
  tacticTypeIds?: number[];
  statusCodes?: string[];
  requesterUserIds?: string[];
  page?: number;
  pageSize?: number;
  sortBy?: string;
  sortOrder?: "asc" | "desc";
}

const getTactics = async (
  params: GetTacticsParams = {},
): Promise<{ items: TacticListItemDTO[] }> => {
  try {
    // Build query string
    const queryParams = new URLSearchParams();

    if (params.term) {
      queryParams.append("term", params.term);
    }
    if (params.status) {
      queryParams.append("status", params.status);
    }
    if (params.tacticTypeIds && params.tacticTypeIds.length > 0) {
      params.tacticTypeIds.forEach((id) => {
        queryParams.append("tacticTypeIds", id.toString());
      });
    }
    if (params.statusCodes && params.statusCodes.length > 0) {
      params.statusCodes.forEach((code) => {
        queryParams.append("statusCodes", code);
      });
    }
    if (params.requesterUserIds && params.requesterUserIds.length > 0) {
      params.requesterUserIds.forEach((userId) => {
        queryParams.append("userId", userId);
      });
    }
    if (params.page !== undefined) {
      queryParams.append("page", params.page.toString());
    }
    if (params.pageSize !== undefined) {
      queryParams.append("pageSize", params.pageSize.toString());
    }
    if (params.sortBy) {
      queryParams.append("sortBy", params.sortBy);
    }
    if (params.sortOrder) {
      queryParams.append("sortOrder", params.sortOrder);
    }

    const queryString = queryParams.toString();
    const tacticEndpoint = `${tacticApiBaseUrl}/tactics${queryString ? `?${queryString}` : ""}`;

    logger.debug("Fetching tactics", { endpoint: tacticEndpoint, params });
    const response = await apiClient(tacticEndpoint);

    if (!response.ok) {
      throw new Error(`Failed to fetch tactics: ${response.status}`);
    }

    const data = await response.json();
    logger.info("Tactics loaded successfully", { count: data.items?.length });

    // Parse date strings back to Date objects for each tactic list item
    if (data.items) {
      data.items = data.items.map((item: any) => ({
        ...item,
        created: item.created ? new Date(item.created) : new Date(),
        lastModified: item.lastModified
          ? new Date(item.lastModified)
          : new Date(),
        campaignStartDate: item.campaignStartDate
          ? new Date(item.campaignStartDate)
          : new Date(),
        campaignEndDate: item.campaignEndDate
          ? new Date(item.campaignEndDate)
          : new Date(),
        expiryDate: new Date(item.expiryDate),
      }));
    }

    return data;
  } catch (err) {
    logger.error("Failed to load tactics", { error: err });
    throw err; // Re-throw so the caller can handle it
  }
};

const getTacticById = async (id: string) => {
  try {
    const tacticEndpoint = `${tacticApiBaseUrl}/tactics/${id}`;
    logger.debug("Fetching tactic by ID", { id, endpoint: tacticEndpoint });
    const response = await apiClient(tacticEndpoint);

    if (!response.ok) {
      throw new Error(`Failed to fetch tactic: ${response.status}`);
    }

    const data = await response.json();
    logger.debug("Raw API response:", JSON.stringify(data, null, 2));
    logger.info("Tactic loaded successfully", {
      id,
      description: data.description,
      lastModified: data.lastModified,
    });

    return parseTacticDates(data);
  } catch (err) {
    logger.error("Failed to load tactic by ID", { error: err, id });
    throw err; // Re-throw so the caller can handle it
  }
};

const updateTactic = async (
  id: string,
  tactic: Tactic,
  originalTactic?: Tactic,
) => {
  try {
    const tacticEndpoint = `${tacticApiBaseUrl}/tactics/${id}`;
    logger.debug("Updating tactic", { id, endpoint: tacticEndpoint });

    logger.debug("Tactic to update", tactic);
    if (originalTactic) {
      logger.debug("Original tactic provided for diff", { id });
    }

    // Helper to convert empty strings to null for optional fields
    const emptyToNull = (
      value: string | null | undefined,
    ): string | null | undefined => {
      return value === "" ? null : value;
    };

    // Helper to check if a value has changed
    const hasChanged = (field: keyof Tactic): boolean => {
      if (!originalTactic) return true; // No original = send all fields

      const oldVal = originalTactic[field];
      const newVal = tactic[field];

      // Handle Date objects
      if (oldVal instanceof Date && newVal instanceof Date) {
        return oldVal.getTime() !== newVal.getTime();
      }

      // Handle null/undefined equivalence
      if (
        (oldVal === null || oldVal === undefined) &&
        (newVal === null || newVal === undefined)
      ) {
        return false;
      }

      return oldVal !== newVal;
    };

    // Transform Tactic model to UpdateTacticRequest format
    // Only include fields that have changed (if originalTactic provided)
    const updateRequest: Partial<UpdateTacticRequest> = {};

    // Apply diff logic to ALL fields (including previously "required" ones)
    // This ensures role-based field authorization works correctly
    if (hasChanged("tacticTypeId")) {
      updateRequest.tacticTypeId = tactic.tacticTypeId;
    }
    if (hasChanged("campaignStartDate")) {
      updateRequest.campaignStartDate = tactic.campaignStartDate
        ? new Date(tactic.campaignStartDate).toISOString()
        : new Date().toISOString();
    }
    if (hasChanged("campaignEndDate")) {
      updateRequest.campaignEndDate = tactic.campaignEndDate
        ? new Date(tactic.campaignEndDate).toISOString()
        : new Date().toISOString();
    }
    if (hasChanged("expiryDate")) {
      updateRequest.expiryDate = tactic.expiryDate
        ? new Date(tactic.expiryDate).toISOString()
        : new Date().toISOString();
    }
    if (hasChanged("ownerId")) {
      updateRequest.ownerId = tactic.ownerId;
    }

    // Conditionally include other fields only if changed
    if (hasChanged("description")) {
      updateRequest.description = emptyToNull(tactic.description) ?? undefined;
    }
    if (hasChanged("comments")) {
      updateRequest.comments = emptyToNull(tactic.comments) ?? undefined;
    }
    if (hasChanged("promoPlanId")) {
      updateRequest.promoPlanId = emptyToNull(tactic.promoPlanId) ?? undefined;
    }
    if (hasChanged("databar")) {
      updateRequest.databar = emptyToNull(tactic.databar) ?? undefined;
    }
    if (hasChanged("deliveryMethodId")) {
      updateRequest.deliveryMethodId = tactic.deliveryMethodId;
    }
    // Budget fields
    if (hasChanged("faceValue")) {
      updateRequest.faceValue = tactic.faceValue;
    }
    if (hasChanged("circulationQuantity")) {
      updateRequest.circulationQuantity = tactic.circulationQuantity;
    }
    if (hasChanged("redemptionRate")) {
      updateRequest.redemptionRate = tactic.redemptionRate;
    }
    if (hasChanged("nonworkingBudget")) {
      updateRequest.nonworkingBudget = tactic.nonworkingBudget;
    }
    // Design Card fields
    if (hasChanged("digitalProviderId")) {
      updateRequest.digitalProviderId = tactic.digitalProviderId;
    }
    if (hasChanged("creativeAgencyId")) {
      updateRequest.creativeAgencyId = tactic.creativeAgencyId;
    }
    if (hasChanged("printerId")) {
      updateRequest.printerId = tactic.printerId;
    }
    if (hasChanged("designComments")) {
      updateRequest.designComments = emptyToNull(tactic.designComments);
    }
    if (hasChanged("digitalProviderComments")) {
      updateRequest.digitalProviderComments = emptyToNull(tactic.digitalProviderComments);
    }
    // Offer Details fields
    if (hasChanged("productQuantity")) {
      updateRequest.productQuantity = tactic.productQuantity;
    }
    if (hasChanged("offerTypeId")) {
      updateRequest.offerTypeId = tactic.offerTypeId;
    }
    if (hasChanged("offerVerbiage")) {
      updateRequest.offerVerbiage = emptyToNull(tactic.offerVerbiage);
    }
    if (hasChanged("verbiageComments")) {
      updateRequest.verbiageComments = emptyToNull(tactic.verbiageComments);
    }

    logger.debug("Update request body", updateRequest);

    const response = await apiClient(tacticEndpoint, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(updateRequest),
    });

    if (!response.ok) {
      throw new Error(`Failed to update tactic: ${response.status}`);
    }

    const data = await response.json();
    logger.debug("Update API response:", JSON.stringify(data, null, 2));
    logger.info("Tactic updated successfully", {
      id,
      tacticId: data.tacticId,
      lastModified: data.lastModified,
    });

    // API returns UpdateTacticResponseDto with limited fields (tacticId, campaignStartDate, campaignEndDate, lastModified)
    // Caller should re-fetch full tactic details if needed
    return data;
  } catch (err) {
    logger.error("Failed to update tactic", { error: err, id });
    throw err; // Re-throw so the caller can handle it
  }
};

const assignFromTo =
  (tacticRequest: Partial<Tactic>, requestBody: Record<string, any>) =>
  (propertyName: keyof Tactic, isDate = false) => {
    if (
      tacticRequest[propertyName] !== undefined &&
      tacticRequest[propertyName] !== null
    ) {
      const value = tacticRequest[propertyName];
      requestBody[propertyName] = isDate
        ? new Date(value as string | number | Date).toISOString()
        : value;
    }
  };

/**
 * Creates a new tactic
 * @param tacticRequest - Partial tactic object with required fields
 * @returns Promise<CreateTacticResponse> - Object containing the ID of the created tactic
 * @throws Error if validation fails (400), permission denied (403), or other API errors
 */
const createTactic = async (
  tacticRequest: Partial<Tactic>,
): Promise<CreateTacticResponse> => {
  try {
    const endpoint = `${tacticApiBaseUrl}/tactics`;
    logger.debug("Creating tactic", { endpoint, tacticRequest });

    // Transform Date objects to ISO strings for API
    const requestBody: Record<string, any> = {};

    /**
     * Extracts a property from the tacticRequest object and adds it to the requestBody object.
     * @param tacticRequest - The tacticRequest object to extract the property from.
     * @param requestBody - The object to add the extracted property to.
     * @param propertyName - The name of the property to extract.
     */
    const assignPropIfDefined = assignFromTo(tacticRequest, requestBody);

    assignPropIfDefined("tacticTypeId");
    assignPropIfDefined("deliveryMethodId");
    assignPropIfDefined("campaignStartDate", true);
    assignPropIfDefined("campaignEndDate", true);
    assignPropIfDefined("expiryDate", true);
    assignPropIfDefined("description");
    assignPropIfDefined("ownerId");
    assignPropIfDefined("comments");
    assignPropIfDefined("promoPlanId");
    assignPropIfDefined("databar");
    assignPropIfDefined("faceValue");
    assignPropIfDefined("circulationQuantity");
    assignPropIfDefined("redemptionRate");
    assignPropIfDefined("nonworkingBudget");
    assignPropIfDefined("digitalProviderId");
    assignPropIfDefined("creativeAgencyId");
    assignPropIfDefined("printerId");
    assignPropIfDefined("designComments");
    assignPropIfDefined("productQuantity");
    assignPropIfDefined("offerTypeId");
    assignPropIfDefined("offerVerbiage");
    assignPropIfDefined("verbiageComments");
    assignPropIfDefined("orphanedAttachmentIds");

    const response = await apiClient(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(requestBody),
    });

    if (!response.ok) {
      // Handle validation errors (400)
      if (response.status === 400) {
        const errorData: ValidationErrorResponse = await response.json();
        const errorMessages = errorData.errors
          .map((err) => `${err.field}: ${err.message}`)
          .join("; ");
        throw new Error(`${errorData.message}: ${errorMessages}`);
      }

      // Handle permission errors (403)
      if (response.status === 403) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Permission denied");
      }

      // Handle other errors
      throw new Error(`Failed to create tactic: ${response.status}`);
    }

    const data: CreateTacticResponse = await response.json();
    logger.info("Tactic created successfully", { id: data.id });

    return data;
  } catch (err) {
    logger.error("Failed to create tactic", { error: err });
    throw err;
  }
};

/**
 * Duplicates an existing tactic
 * Creates a new tactic in DRAFT status with most data copied from the original
 *
 * @param tacticId - UUID of the tactic to duplicate
 * @returns Promise with new tactic ID
 * @throws Error with status code and message for failures
 */
const duplicateTactic = async (
  tacticId: string,
): Promise<DuplicateTacticResponse> => {
  try {
    const endpoint = `${tacticApiBaseUrl}/tactics/${tacticId}/duplicate`;
    logger.debug("Duplicating tactic", { tacticId, endpoint });

    const response = await apiClient(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });

    // Handle error responses
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));

      switch (response.status) {
        case 400:
          throw new Error(errorData.detail || "Invalid tactic ID format");
        case 401:
          throw new Error(errorData.detail || "Authentication required");
        case 403:
          throw new Error(
            errorData.detail ||
              "You do not have permission to duplicate tactics",
          );
        case 404:
          throw new Error(
            errorData.detail ||
              "Tactic not found or you do not have access to it",
          );
        case 500:
          throw new Error(
            errorData.detail || "Failed to duplicate tactic. Please try again.",
          );
        default:
          throw new Error(`Failed to duplicate tactic: ${response.status}`);
      }
    }

    const data: DuplicateTacticResponse = await response.json();
    logger.info("Tactic duplicated successfully", {
      originalTacticId: tacticId,
      newTacticId: data.id,
    });

    return data;
  } catch (error) {
    logger.error("Failed to duplicate tactic", {
      tacticId,
      error: error instanceof Error ? error.message : "Unknown error",
    });
    throw error;
  }
};

/**
 * Marks a tactic as proof-ready
 * Transitions a DRAFT tactic to PROOF_READY status after validation
 *
 * @param tacticId - UUID of the tactic to mark as proof-ready
 * @returns Promise with mark-proof-ready response (tacticId, success, message, errors)
 * @throws Error with status code and message for failures
 */
const markProofReady = async (
  tacticId: string,
): Promise<MarkProofReadyResponse> => {
  try {
    const endpoint = `${tacticApiBaseUrl}/tactics/${tacticId}/mark-proof-ready`;
    logger.debug("Marking tactic as proof-ready", { tacticId, endpoint });

    const response = await apiClient(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });

    // Handle error responses
    if (!response.ok) {
      const errorData: MarkProofReadyResponse | any = await response
        .json()
        .catch(() => ({}));

      switch (response.status) {
        case 400:
          // Handle structured validation errors from API contract
          if (errorData.errors && Array.isArray(errorData.errors)) {
            const errorMessages = errorData.errors
              .map(
                (err: ValidationError) => `${err.property}: ${err.errorCode}`,
              )
              .join("; ");
            throw new ApiValidationError(
              errorData.message || `Validation failed: ${errorMessages}`,
              errorData.errors,
              400,
            );
          }
          throw new Error(
            errorData.detail ||
              errorData.message ||
              "Validation failed. Please check all required fields.",
          );
        case 401:
          throw new Error(errorData.detail || "Authentication required");
        case 403:
          throw new Error(
            errorData.detail ||
              "You do not have permission to mark this tactic as proof-ready",
          );
        case 404:
          throw new Error(
            errorData.detail ||
              "Tactic not found or you do not have access to it",
          );
        case 500:
          throw new Error(
            errorData.detail ||
              "Failed to mark tactic as proof-ready. Please try again.",
          );
        default:
          throw new Error(
            `Failed to mark tactic as proof-ready: ${response.status}`,
          );
      }
    }

    const data: MarkProofReadyResponse = await response.json();
    logger.info("Tactic marked as proof-ready successfully", {
      tacticId: data.tacticId,
      success: data.success,
      message: data.message,
    });

    return data;
  } catch (error) {
    logger.error("Failed to mark tactic as proof-ready", {
      tacticId,
      error: error instanceof Error ? error.message : "Unknown error",
    });
    throw error;
  }
};

/**
 * Approves the verbiage for a tactic (proof reader action)
 *
 * Transitions a PROOF_READY tactic to APPROVED status after proof reader approval.
 *
 * @param tacticId - The ID of the tactic to approve
 * @throws Error if tacticId is not provided or API call fails
 */
export const approveVerbiage = async (tacticId: string): Promise<void> => {
  try {
    if (!tacticId || tacticId.trim() === "") {
      throw new Error("tacticId is required");
    }

    const endpoint = `${tacticApiBaseUrl}/tactics/${tacticId}/approve-verbiage`;
    logger.debug("Approving verbiage", { tacticId, endpoint });

    const response = await apiClient(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to approve verbiage: ${response.status}`);
    }

    logger.info("Verbiage approved successfully", { tacticId });
  } catch (error) {
    logger.error("Failed to approve verbiage", {
      tacticId,
      error: error instanceof Error ? error.message : "Unknown error",
    });
    throw error;
  }
};

/**
 * Requests review from the requester (proof reader action)
 *
 * Sends a request back to the requester with a comment explaining what needs review.
 *
 * @param tacticId - The ID of the tactic
 * @param comment - Comment explaining why review is needed
 * @throws Error if tacticId or comment is not provided or API call fails
 */
export const requestReview = async (
  tacticId: string,
  comment: string,
): Promise<void> => {
  try {
    if (!tacticId || tacticId.trim() === "") {
      throw new Error("tacticId is required");
    }

    if (!comment || comment.trim() === "") {
      throw new Error("comment is required");
    }

    const endpoint = `${tacticApiBaseUrl}/tactics/${tacticId}/request-review`;
    logger.debug("Requesting review", { tacticId, endpoint });

    const response = await apiClient(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ comment }),
    });

    if (!response.ok) {
      throw new Error(`Failed to request review: ${response.status}`);
    }

    logger.info("Review requested successfully", { tacticId });
  } catch (error) {
    logger.error("Failed to request review", {
      tacticId,
      error: error instanceof Error ? error.message : "Unknown error",
    });
    throw error;
  }
};

/**
 * Completes clearinghouse review for a digital tactic (clearinghouse agent action)
 *
 * Transitions an INFORMING_VENDORS tactic to CLEARINGHOUSE_COMPLETE status.
 *
 * @param tacticId - The ID of the tactic to complete review for
 * @throws Error if tacticId is not provided or API call fails
 */
export const completeClearinghouseReview = async (tacticId: string): Promise<void> => {
  try {
    if (!tacticId || tacticId.trim() === "") {
      throw new Error("tacticId is required");
    }

    const endpoint = `${tacticApiBaseUrl}/tactics/${tacticId}/complete-clearinghouse-review`;
    logger.debug("Completing clearinghouse review", { tacticId, endpoint });

    const response = await apiClient(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to complete clearinghouse review: ${response.status}`);
    }

    logger.info("Clearinghouse review completed successfully", { tacticId });
  } catch (error) {
    logger.error("Failed to complete clearinghouse review", {
      tacticId,
      error: error instanceof Error ? error.message : "Unknown error",
    });
    throw error;
  }
};

/**
 * Confirm a rescheduled tactic and transition to DRAFTING_PROOF (Clearinghouse Agent action)
 * Validates databar is present and transitions status from RESCHEDULE_SUBMITTED to DRAFTING_PROOF
 *
 * @param tacticId - The ID of the tactic to confirm reschedule for
 * @throws Error if tacticId is not provided or API call fails
 */
export const confirmRescheduledTactic = async (tacticId: string): Promise<void> => {
  try {
    if (!tacticId || tacticId.trim() === "") {
      throw new Error("tacticId is required");
    }

    const endpoint = `${tacticApiBaseUrl}/tactics/${tacticId}/confirm-reschedule`;
    logger.debug("Confirming rescheduled tactic", { tacticId, endpoint });

    const response = await apiClient(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to confirm reschedule: ${response.status}`);
    }

    logger.info("Reschedule confirmed successfully", { tacticId });
  } catch (error) {
    logger.error("Failed to confirm reschedule", {
      tacticId,
      error: error instanceof Error ? error.message : "Unknown error",
    });
    throw error;
  }
};

/**
 * Submits creative artwork for a tactic (creative agent action)
 *
 * Transitions an INFORMING_VENDORS or CLEARINGHOUSE_COMPLETE tactic to CREATIVE_COMPLETE status.
 *
 * @param tacticId - The ID of the tactic to submit artwork for
 * @throws Error if tacticId is not provided or API call fails
 */
export const submitCreativeArtwork = async (tacticId: string): Promise<void> => {
  try {
    if (!tacticId || tacticId.trim() === "") {
      throw new Error("tacticId is required");
    }

    const endpoint = `${tacticApiBaseUrl}/tactics/${tacticId}/submit-creative-artwork`;
    logger.debug("Submitting creative artwork", { tacticId, endpoint });

    const response = await apiClient(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to submit creative artwork: ${response.status}`);
    }

    logger.info("Creative artwork submitted successfully", { tacticId });
  } catch (error) {
    logger.error("Failed to submit creative artwork", {
      tacticId,
      error: error instanceof Error ? error.message : "Unknown error",
    });
    throw error;
  }
};

/**
 * Submits digital proofs for final approvals (digital provider action)
 *
 * Transitions a DRAFTING_PROOF tactic to FINAL_APPROVALS status.
 *
 * @param tacticId - The ID of the tactic to submit digital proofs for
 * @throws Error if tacticId is not provided or API call fails
 */
export const submitDigitalProofs = async (tacticId: string): Promise<void> => {
  try {
    if (!tacticId || tacticId.trim() === "") {
      throw new Error("tacticId is required");
    }

    const endpoint = `${tacticApiBaseUrl}/tactics/${tacticId}/submit-digital-proofs`;
    logger.debug("Submitting digital proofs", { tacticId, endpoint });

    const response = await apiClient(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to submit digital proofs: ${response.status}`);
    }

    logger.info("Digital proofs submitted successfully", { tacticId });
  } catch (error) {
    logger.error("Failed to submit digital proofs", {
      tacticId,
      error: error instanceof Error ? error.message : "Unknown error",
    });
    throw error;
  }
};

/**
 * Requests vendor review for a digital tactic (clearinghouse agent action)
 *
 * Transitions an INFORMING_VENDORS tactic to VENDOR_REVIEW status with a comment.
 *
 * @param tacticId - The ID of the tactic
 * @param comment - Comment providing context for the vendor review request
 * @throws Error if tacticId or comment is not provided or API call fails
 */
export const requestVendorReview = async (
  tacticId: string,
  comment: string,
): Promise<void> => {
  try {
    if (!tacticId || tacticId.trim() === "") {
      throw new Error("tacticId is required");
    }

    if (!comment || comment.trim() === "") {
      throw new Error("comment is required");
    }

    const endpoint = `${tacticApiBaseUrl}/tactics/${tacticId}/request-vendor-review`;
    logger.debug("Requesting vendor review", { tacticId, endpoint });

    const response = await apiClient(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ comment }),
    });

    if (!response.ok) {
      throw new Error(`Failed to request vendor review: ${response.status}`);
    }

    logger.info("Vendor review requested successfully", { tacticId });
  } catch (error) {
    logger.error("Failed to request vendor review", {
      tacticId,
      error: error instanceof Error ? error.message : "Unknown error",
    });
    throw error;
  }
};

/**
 * Approves digital proof as Requester/Owner (parallel approval with Clearinghouse)
 *
 * Transitions tactic from FINAL_APPROVALS to REQUESTER_FINAL_APPROVED,
 * or from CLEARINGHOUSE_FINAL_APPROVED to AWAITING_START.
 *
 * @param tacticId - The ID of the tactic
 * @throws Error if tacticId is not provided or API call fails
 */
export const approveRequesterFinalProof = async (
  tacticId: string,
): Promise<void> => {
  try {
    if (!tacticId || tacticId.trim() === "") {
      throw new Error("tacticId is required");
    }

    const endpoint = `${tacticApiBaseUrl}/tactics/${tacticId}/requester-approve-final-proof`;
    logger.debug("Approving requester final proof", { tacticId, endpoint });

    const response = await apiClient(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to approve final proof: ${response.status} - ${errorText}`);
    }

    logger.info("Requester final proof approved successfully", { tacticId });
  } catch (error) {
    logger.error("Failed to approve requester final proof", {
      tacticId,
      error: error instanceof Error ? error.message : "Unknown error",
    });
    throw error;
  }
};

/**
 * Approves digital proof as Clearinghouse Agent (parallel approval with Requester)
 *
 * Transitions tactic from FINAL_APPROVALS to CLEARINGHOUSE_FINAL_APPROVED,
 * or from REQUESTER_FINAL_APPROVED to AWAITING_START.
 *
 * @param tacticId - The ID of the tactic
 * @throws Error if tacticId is not provided or API call fails
 */
export const approveClearinghouseFinalProof = async (
  tacticId: string,
): Promise<void> => {
  try {
    if (!tacticId || tacticId.trim() === "") {
      throw new Error("tacticId is required");
    }

    const endpoint = `${tacticApiBaseUrl}/tactics/${tacticId}/approve-digital-proof-clearinghouse`;
    logger.debug("Approving clearinghouse final proof", { tacticId, endpoint });

    const response = await apiClient(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to approve final proof: ${response.status} - ${errorText}`);
    }

    logger.info("Clearinghouse final proof approved successfully", { tacticId });
  } catch (error) {
    logger.error("Failed to approve clearinghouse final proof", {
      tacticId,
      error: error instanceof Error ? error.message : "Unknown error",
    });
    throw error;
  }
};

/**
 * Rejects digital proof as Requester/Owner and returns to drafting
 *
 * Transitions tactic from FINAL_APPROVALS or CLEARINGHOUSE_FINAL_APPROVED
 * back to DRAFTING_PROOF with rejection comments.
 *
 * @param tacticId - The ID of the tactic
 * @param digitalProviderComments - Comments explaining why the proof is rejected
 * @throws Error if tacticId or comments are not provided or API call fails
 */
export const rejectRequesterFinalProof = async (
  tacticId: string,
  digitalProviderComments: string,
): Promise<void> => {
  try {
    if (!tacticId || tacticId.trim() === "") {
      throw new Error("tacticId is required");
    }

    if (!digitalProviderComments || digitalProviderComments.trim() === "") {
      throw new Error("digitalProviderComments is required for rejection");
    }

    const endpoint = `${tacticApiBaseUrl}/tactics/${tacticId}/requester-reject-final-proof`;
    logger.debug("Rejecting requester final proof", { tacticId, endpoint });

    const response = await apiClient(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ digitalProviderComments }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to reject final proof: ${response.status} - ${errorText}`);
    }

    logger.info("Requester final proof rejected successfully", { tacticId });
  } catch (error) {
    logger.error("Failed to reject requester final proof", {
      tacticId,
      error: error instanceof Error ? error.message : "Unknown error",
    });
    throw error;
  }
};

/**
 * Rejects digital proof as Clearinghouse Agent and returns to drafting
 *
 * Transitions tactic from FINAL_APPROVALS or REQUESTER_FINAL_APPROVED
 * back to DRAFTING_PROOF with rejection comments.
 *
 * @param tacticId - The ID of the tactic
 * @param digitalProviderComments - Comments explaining why the proof is rejected
 * @throws Error if tacticId or comments are not provided or API call fails
 */
export const rejectClearinghouseFinalProof = async (
  tacticId: string,
  digitalProviderComments: string,
): Promise<void> => {
  try {
    if (!tacticId || tacticId.trim() === "") {
      throw new Error("tacticId is required");
    }

    if (!digitalProviderComments || digitalProviderComments.trim() === "") {
      throw new Error("digitalProviderComments is required for rejection");
    }

    const endpoint = `${tacticApiBaseUrl}/tactics/${tacticId}/reject-digital-proof-clearinghouse`;
    logger.debug("Rejecting clearinghouse final proof", { tacticId, endpoint });

    const response = await apiClient(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ digitalProviderComments }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to reject final proof: ${response.status} - ${errorText}`);
    }

    logger.info("Clearinghouse final proof rejected successfully", { tacticId });
  } catch (error) {
    logger.error("Failed to reject clearinghouse final proof", {
      tacticId,
      error: error instanceof Error ? error.message : "Unknown error",
    });
    throw error;
  }
};

/**
 * Submits rescheduled tactic with new dates (AWAITING_START → RESCHEDULE_SUBMITTED)
 * @param tacticId - The ID of the tactic to reschedule
 * @param startDate - New start date (must be tomorrow or later)
 * @param endDate - New end date (must be on or after start date)
 * @param expiryDate - New expiry date (must be on or after end date)
 * @throws Error if the request fails or dates are invalid
 */
export const submitRescheduledTactic = async (
  tacticId: string,
  startDate: Date,
  endDate: Date,
  expiryDate: Date
): Promise<void> => {
  try {
    if (!tacticId || tacticId.trim() === "") {
      throw new Error("tacticId is required");
    }

    const endpoint = `${tacticApiBaseUrl}/tactics/${tacticId}/submit-reschedule`;
    logger.debug("Submitting rescheduled tactic", { tacticId, startDate, endDate, expiryDate, endpoint });

    const response = await apiClient(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
        expiryDate: expiryDate.toISOString(),
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to submit rescheduled tactic: ${response.status} - ${errorText}`);
    }

    logger.info("Rescheduled tactic submitted successfully", { tacticId });
  } catch (error) {
    logger.error("Failed to submit rescheduled tactic", {
      tacticId,
      error: error instanceof Error ? error.message : "Unknown error",
    });
    throw error;
  }
};

/**
 * Submit reschedule for a LIVE tactic with new End and Expiry dates
 * Start date is preserved from the database
 * Transitions tactic from LIVE to RESCHEDULE_SUBMITTED status
 * 
 * @param tacticId - The ID of the tactic to reschedule
 * @param endDate - New end date (must be tomorrow or later)
 * @param expiryDate - New expiry date (must be on or after end date)
 * @throws Error if the request fails, tactic is expired, or dates are invalid
 */
export const submitRescheduledTacticFromLive = async (
  tacticId: string,
  endDate: Date,
  expiryDate: Date
): Promise<void> => {
  try {
    if (!tacticId || tacticId.trim() === "") {
      throw new Error("tacticId is required");
    }

    const endpoint = `${tacticApiBaseUrl}/tactics/${tacticId}/submit-reschedule-from-live`;
    logger.debug("Submitting rescheduled tactic from LIVE", { tacticId, endDate, expiryDate, endpoint });

    const response = await apiClient(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        endDate: endDate.toISOString(),
        expiryDate: expiryDate.toISOString(),
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to submit rescheduled tactic from LIVE: ${response.status} - ${errorText}`);
    }

    logger.info("Rescheduled tactic from LIVE submitted successfully", { tacticId });
  } catch (error) {
    logger.error("Failed to submit rescheduled tactic from LIVE", {
      tacticId,
      error: error instanceof Error ? error.message : "Unknown error",
    });
    throw error;
  }
};

/**
 * Reassigns a tactic to a new owner
 * 
 * @param tacticId - ID of the tactic to reassign
 * @param newOwnerId - ID of the new owner
 * @returns Promise<{ success: boolean }> - Success response
 * @throws Error if the API call fails
 */
export const reassignOwner = async (
  tacticId: string,
  newOwnerId: string,
): Promise<{ success: boolean }> => {
  try {
    const endpoint = `${tacticApiBaseUrl}/tactics/${tacticId}/owner`;
    logger.debug("Reassigning tactic owner", { tacticId, newOwnerId, endpoint });

    const response = await apiClient(endpoint, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ newOwnerId }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Failed to reassign owner: ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    logger.info("Tactic owner reassigned successfully", { tacticId, newOwnerId });

    return { success: true };
  } catch (error) {
    logger.error("Failed to reassign tactic owner", {
      tacticId,
      newOwnerId,
      error: error instanceof Error ? error.message : "Unknown error",
    });
    throw error;
  }
};

/**
 * Gets default filter presets based on the current user's role
 * 
 * Returns an array of status codes that should be pre-selected in the filter
 * based on the user's role precedence (Requester > ProofReader > ClearinghouseAgent > CreativeAgent > DigitalProvider).
 * Empty array means show all statuses (no filter).
 * 
 * @returns Promise<FilterPresetsDto> - Object containing array of status codes to filter by
 * @throws Error if the API call fails
 */
export const getDefaultFilterPresets = async (): Promise<FilterPresetsDto> => {
  try {
    const endpoint = `${tacticApiBaseUrl}/tactics/filter-presets`;
    logger.debug("Fetching default filter presets", { endpoint });

    const response = await apiClient(endpoint);

    if (!response.ok) {
      throw new Error(`Failed to fetch filter presets: ${response.status}`);
    }

    const data: FilterPresetsDto = await response.json();
    logger.info("Filter presets loaded successfully", {
      statusCodes: data.defaultStatuses,
    });

    return data;
  } catch (err) {
    logger.error("Failed to load filter presets", { error: err });
    throw err;
  }
};

export default {
  getTactics,
  getTacticById,
  updateTactic,
  createTactic,
  duplicateTactic,
  markProofReady,
  approveVerbiage,
  requestReview,
  completeClearinghouseReview,
  confirmRescheduledTactic,
  submitCreativeArtwork,
  submitDigitalProofs,
  requestVendorReview,
  approveRequesterFinalProof,
  rejectRequesterFinalProof,
  approveClearinghouseFinalProof,
  rejectClearinghouseFinalProof,
  submitRescheduledTactic,
  submitRescheduledTacticFromLive,
  reassignOwner,
  getDefaultFilterPresets,
};
