using System;
using System.IO;
using System.Security.Claims;
using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TacticManagement.Application.Tactics.DTOs;
using TacticManagement.Application.Tactics.Queries;
using TacticManagement.Application.Tactics.Commands;
using TacticManagement.Application.Tactics.Commands.ApproveDigitalProofClearinghouse;
using TacticManagement.Application.Tactics.Commands.ApproveVerbiage;
using TacticManagement.Application.Tactics.Commands.CompleteClearinghouseReview;
using TacticManagement.Application.Tactics.Commands.ConfirmRescheduledTactic;
using TacticManagement.Application.Tactics.Commands.RejectDigitalProofClearinghouse;
using TacticManagement.Application.Tactics.Commands.RequestVendorReview;
using TacticManagement.Application.Tactics.Commands.SubmitCreativeArtwork;
using TacticManagement.Application.Tactics.Commands.SubmitDigitalProofs;
using TacticManagement.Application.Tactics.Commands.RequesterApproveFinalProof;
using TacticManagement.Application.Tactics.Commands.RequesterRejectFinalProof;
using TacticManagement.Application.Tactics.Commands.SubmitRescheduledTactic;
using TacticManagement.Application.Tactics.Commands.SubmitRescheduledTacticFromLive;
using TacticManagement.Application.Tactics.Commands.ChangeOwner;
using TacticManagement.Domain.Exceptions;

namespace TacticManagement.Api.Controllers
{
    [ApiController]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/tactics")]
    [Authorize]
    public class TacticsController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<TacticsController> _logger;

        public TacticsController(IMediator mediator, ILogger<TacticsController> logger)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <summary>
        /// Retrieves a paginated list of tactics for the current user.
        /// </summary>
        /// <param name="term">Search term to filter tactics. Searches across Description, Notes, OfferVerbiage, DigitalProvider name, and Brand fields. If the term is a valid integer, performs exact match on OfferCode.</param>
        /// <param name="status">Filter by tactic status (e.g., DRAFT, PROOF_READY)</param>
        /// <param name="tacticTypeIds">Filter by tactic type IDs (can specify multiple)</param>
        /// <param name="statusCodes">Filter by status codes (can specify multiple)</param>
        /// <param name="userId">Filter by requester user IDs (Requester role only, can specify multiple: ?userId=id1&userId=id2)</param>
        /// <param name="page">Page number (default: 1)</param>
        /// <param name="pageSize">Number of items per page (default: 20, max: 100)</param>
        /// <param name="sortBy">Field to sort by (default: "offerCode")</param>
        /// <param name="sortOrder">Sort order: "asc" or "desc" (default: "desc")</param>
        /// <returns>Paginated list of tactics</returns>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<PaginatedResponseDto<TacticListItemDto>>> GetTactics(
            [FromQuery] string? term,
            [FromQuery] string? status,
            [FromQuery] List<int>? tacticTypeIds,
            [FromQuery] List<string>? statusCodes,
            [FromQuery] List<string>? userId,
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 20,
            [FromQuery] string sortBy = "offerCode",
            [FromQuery] string sortOrder = "desc")
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var currentUserId = GetUserIdFromClaims();
            
            _logger.LogInformation(
                "[{CorrelationId}] GetTactics request started for UserId: {UserId}",
                correlationId, currentUserId);
            
            _logger.LogDebug(
                "[{CorrelationId}] GetTactics parameters - Term: {Term}, Status: {Status}, TacticTypeIds: {TacticTypeIds}, StatusCodes: {StatusCodes}, RequesterUserIds: {RequesterUserIds}, Page: {Page}, PageSize: {PageSize}, SortBy: {SortBy}, SortOrder: {SortOrder}",
                correlationId, term ?? "null", status ?? "null", tacticTypeIds != null ? string.Join(",", tacticTypeIds) : "null", statusCodes != null ? string.Join(",", statusCodes) : "null", userId != null ? string.Join(",", userId) : "null", page, pageSize, sortBy, sortOrder);
            
            var query = new GetUserTacticsQuery(currentUserId, term, status, tacticTypeIds, statusCodes, userId, page, pageSize, sortBy, sortOrder);
            var result = await _mediator.Send(query);
            
            _logger.LogInformation(
                "[{CorrelationId}] GetTactics completed successfully for UserId: {UserId}. Returned {TotalCount} total tactics",
                correlationId, currentUserId, result.TotalCount);
            
            return Ok(result);
        }

        [HttpGet("filter-presets")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<FilterPresetsDto>> GetDefaultFilterPresets()
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();
            
            _logger.LogInformation(
                "[{CorrelationId}] GetDefaultFilterPresets request started for UserId: {UserId}",
                correlationId, userId);
            
            var query = new GetDefaultFilterPresetsQuery(userId);
            var result = await _mediator.Send(query);
            
            _logger.LogInformation(
                "[{CorrelationId}] GetDefaultFilterPresets completed successfully for UserId: {UserId}. DefaultStatuses: {DefaultStatuses}",
                correlationId, userId, string.Join(", ", result.DefaultStatuses));
            
            return Ok(result);
        }

        [HttpGet("{tacticId:guid}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<TacticDetailDto>> GetTacticById(Guid tacticId)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();
            
            _logger.LogInformation(
                "[{CorrelationId}] GetTacticById request started for TacticId: {TacticId}, UserId: {UserId}",
                correlationId, tacticId, userId);
            
            _logger.LogDebug(
                "[{CorrelationId}] Retrieving tactic details for TacticId: {TacticId}",
                correlationId, tacticId);
            
            var query = new GetTacticByIdQuery(tacticId, userId);
            var result = await _mediator.Send(query);
            
            _logger.LogInformation(
                "[{CorrelationId}] GetTacticById completed successfully for TacticId: {TacticId}, UserId: {UserId}. Tactic Description: {TacticDescription}, Status: {Status}",
                correlationId, tacticId, userId, result.Description, result.Status);
            
            return Ok(result);
        }

        /// <summary>
        /// Updates an existing tactic with the provided information.
        /// </summary>
        /// <param name="tacticId">The unique identifier of the tactic to update</param>
        /// <param name="request">The update request containing tactic details</param>
        /// <returns>The updated tactic details</returns>
        /// <response code="200">Tactic updated successfully</response>
        /// <response code="400">Invalid request data</response>
        /// <response code="401">User is not authenticated</response>
        /// <response code="403">User does not have permission to update this tactic</response>
        /// <response code="404">Tactic not found</response>
        /// <response code="500">Internal server error</response>
        [HttpPatch("{tacticId:guid}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<UpdateTacticResponseDto>> UpdateTactic(
            Guid tacticId,
            [FromBody] UpdateTacticRequest request)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();
            
            _logger.LogInformation(
                "[{CorrelationId}] UpdateTactic request started for TacticId: {TacticId}, UserId: {UserId}",
                correlationId, tacticId, userId);
            
            _logger.LogDebug(
                "[{CorrelationId}] UpdateTactic parameters - TacticId: {TacticId}, Description: {Description}, CampaignStartDate: {StartDate}, CampaignEndDate: {EndDate}, ExpiryDate: {ExpiryDate}, Comments: {Comments}, PromoPlanId: {PromoPlanId}, Databar: {Databar}, DeliveryMethodId: {DeliveryMethodId}, OwnerId: {OwnerId}, TacticTypeId: {TacticTypeId}, FaceValue: {FaceValue}, CirculationQuantity: {CirculationQuantity}, RedemptionRate: {RedemptionRate}, NonworkingBudget: {NonworkingBudget}, DigitalProviderId: {DigitalProviderId}, CreativeAgencyId: {CreativeAgencyId}, PrinterId: {PrinterId}, DesignComments: {DesignComments}, ProductQuantity: {ProductQuantity}, OfferTypeId: {OfferTypeId}, OfferVerbiage: {OfferVerbiage}",
                correlationId, tacticId, request.Description, request.CampaignStartDate, request.CampaignEndDate, request.ExpiryDate, request.Comments, request.PromoPlanId, request.Databar, request.DeliveryMethodId, request.OwnerId, request.TacticTypeId, request.FaceValue, request.CirculationQuantity, request.RedemptionRate, request.NonworkingBudget, request.DigitalProviderId, request.CreativeAgencyId, request.PrinterId, request.DesignComments, request.ProductQuantity, request.OfferTypeId, request.OfferVerbiage);
            
            var command = new UpdateTacticCommand(
                tacticId, 
                userId, 
                request.CampaignStartDate, 
                request.CampaignEndDate,
                request.ExpiryDate,
                request.Description,
                request.Comments,
                request.PromoPlanId,
                request.Databar,
                request.DeliveryMethodId,
                request.OwnerId,
                request.TacticTypeId,
                request.FaceValue,
                request.CirculationQuantity,
                request.RedemptionRate,
                request.NonworkingBudget,
                request.DigitalProviderId,
                request.CreativeAgencyId,
                request.PrinterId,
                request.DesignComments,
                request.DigitalProviderComments,
                request.ProductQuantity,
                request.OfferTypeId,
                request.OfferVerbiage,
                request.VerbiageComments
            );
            var result = await _mediator.Send(command);
            
            _logger.LogInformation(
                "[{CorrelationId}] UpdateTactic completed successfully for TacticId: {TacticId}, UserId: {UserId}",
                correlationId, tacticId, userId);
            
            return Ok(result);
        }

        /// <summary>
        /// Update allocations for a tactic
        /// </summary>
        /// <param name="tacticId">The ID of the tactic to update allocations for</param>
        /// <param name="request">The allocation update request</param>
        /// <returns>No content on success</returns>
        /// <response code="204">Allocations updated successfully</response>
        /// <response code="400">Invalid request or tactic is not in DRAFT, VERBIAGE_REVIEW, or VENDOR_REVIEW status</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="404">Tactic not found or user not authorized</response>
        /// <response code="500">Internal server error</response>
        [HttpPatch("{tacticId:guid}/allocations")]
        [Authorize(Roles = "Requester")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> UpdateAllocations(
            Guid tacticId,
            [FromBody] UpdateTacticAllocationsRequest request)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();

            _logger.LogInformation(
                "[{CorrelationId}] UpdateAllocations request started for TacticId: {TacticId}, UserId: {UserId}, AllocationCount: {Count}",
                correlationId, tacticId, userId, request.Allocations?.Count ?? 0);

            _logger.LogDebug(
                "[{CorrelationId}] UpdateAllocations parameters - TacticId: {TacticId}, Allocations: {@Allocations}",
                correlationId, tacticId, request.Allocations);

            try
            {
                // Create command
                var command = new UpdateTacticAllocationsCommand
                {
                    TacticId = tacticId,
                    UserId = userId,
                    Allocations = request.Allocations ?? new List<TacticAllocationDto>()
                };

                await _mediator.Send(command);

                _logger.LogInformation(
                    "[{CorrelationId}] UpdateAllocations completed successfully for TacticId: {TacticId}, UserId: {UserId}",
                    correlationId, tacticId, userId);

                return NoContent();
            }
            catch (KeyNotFoundException)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] UpdateAllocations failed: Tactic not found or user not authorized. TacticId: {TacticId}",
                    correlationId, tacticId);
                
                return NotFound();
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] UpdateAllocations failed: Unauthorized. TacticId: {TacticId}, UserId: {UserId}, Reason: {Reason}",
                    correlationId, tacticId, userId, ex.Message);
                
                return Forbid();
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] UpdateAllocations failed: Invalid operation. TacticId: {TacticId}, Reason: {Reason}",
                    correlationId, tacticId, ex.Message);
                
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Changes the owner of a tactic.
        /// Allows Requesters/Owners to reassign tactic ownership to other active requesters in their OpCo.
        /// </summary>
        /// <param name="tacticId">The ID of the tactic to reassign</param>
        /// <param name="request">The change owner request containing new owner ID</param>
        /// <returns>Success response with updated tactic information</returns>
        /// <response code="200">Owner changed successfully</response>
        /// <response code="400">Invalid request or tactic is in terminal status</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="403">User is not owner or requester of the tactic</response>
        /// <response code="404">Tactic not found or user not authorized</response>
        /// <response code="500">Internal server error</response>
        [HttpPatch("{tacticId:guid}/owner")]
        [Authorize(Roles = "Requester")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<ChangeOwnerResponse>> ChangeOwner(
            Guid tacticId,
            [FromBody] ChangeOwnerRequest request)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();

            _logger.LogInformation(
                "[{CorrelationId}] ChangeOwner request started for TacticId: {TacticId}, UserId: {UserId}, NewOwnerId: {NewOwnerId}",
                correlationId, tacticId, userId, request.NewOwnerId);

            try
            {
                var command = new ChangeOwnerCommand
                {
                    TacticId = tacticId,
                    NewOwnerId = request.NewOwnerId,
                    UserId = userId
                };

                var response = await _mediator.Send(command);

                _logger.LogInformation(
                    "[{CorrelationId}] ChangeOwner completed successfully for TacticId: {TacticId}, NewOwnerId: {NewOwnerId}",
                    correlationId, tacticId, request.NewOwnerId);

                return Ok(response);
            }
            catch (TacticNotFoundException)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] ChangeOwner failed: Tactic not found or user not authorized. TacticId: {TacticId}",
                    correlationId, tacticId);
                
                return NotFound();
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] ChangeOwner failed: Unauthorized. TacticId: {TacticId}, UserId: {UserId}, Reason: {Reason}",
                    correlationId, tacticId, userId, ex.Message);
                
                return Forbid();
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] ChangeOwner failed: Invalid operation. TacticId: {TacticId}, Reason: {Reason}",
                    correlationId, tacticId, ex.Message);
                
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Creates a new tactic.
        /// </summary>
        /// <param name="request">The create request containing tactic details</param>
        /// <returns>The created tactic details</returns>
        /// <response code="201">Tactic created successfully</response>
        /// <response code="400">Invalid request data</response>
        /// <response code="401">User is not authenticated</response>
        /// <response code="500">Internal server error</response>
        [HttpPost]
        [Authorize(Roles = "Requester")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<CreateTacticResponse>> CreateTactic([FromBody] CreateTacticRequest request)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();
            
            _logger.LogInformation(
                "[{CorrelationId}] CreateTactic request started for UserId: {UserId}",
                correlationId, userId);
            
            _logger.LogDebug(
                "[{CorrelationId}] CreateTactic parameters - Description: {Description}, TacticTypeId: {TacticTypeId}, StartDate: {StartDate}, EndDate: {EndDate}, OrphanedAttachmentCount: {OrphanedAttachmentCount}",
                correlationId, request.Description, request.TacticTypeId, request.CampaignStartDate, request.CampaignEndDate, request.OrphanedAttachmentIds?.Count ?? 0);

            var command = new CreateTacticCommand(request, userId);
            var result = await _mediator.Send(command);
            
            _logger.LogInformation(
                "[{CorrelationId}] CreateTactic completed successfully for UserId: {UserId}. New TacticId: {TacticId}",
                correlationId, userId, result.Id);
            
            return CreatedAtAction(
                nameof(GetTacticById),
                new { tacticId = result.Id },
                result);
        }

        /// <summary>
        /// Marks a DRAFT or VERBIAGE_REVIEW tactic as Proof-Ready after validating dates and business rules.
        /// </summary>
        /// <param name="tacticId">The ID of the tactic to mark as Proof-Ready</param>
        /// <returns>Success response or validation errors</returns>
        /// <response code="200">Tactic successfully marked as Proof-Ready</response>
        /// <response code="400">Validation failed (invalid dates or status)</response>
        /// <response code="404">Tactic not found or user not authorized</response>
        [HttpPost("{tacticId:guid}/mark-proof-ready")]
        [Authorize(Roles = "Requester")]
        [ProducesResponseType(typeof(MarkTacticProofReadyResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(MarkTacticProofReadyResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> MarkProofReady(Guid tacticId)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();

            _logger.LogInformation(
                "[{CorrelationId}] Marking tactic {TacticId} as Proof-Ready for user {UserId}",
                correlationId, tacticId, userId);

            var command = new MarkTacticProofReadyCommand(tacticId, userId);
            var response = await _mediator.Send(command);

            if (!response.Success)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] Failed to mark tactic {TacticId} as Proof-Ready: {ErrorCount} validation errors",
                    correlationId, tacticId, response.Errors?.Count ?? 0);
                
                return BadRequest(response);
            }

            _logger.LogInformation(
                "[{CorrelationId}] Successfully marked tactic {TacticId} as Proof-Ready",
                correlationId, tacticId);

            return Ok(response);
        }

        /// <summary>
        /// Request review for a PROOF_READY tactic. Transitions tactic from PROOF_READY to VERBIAGE_REVIEW status.
        /// Only users with the ProofReader role can request review.
        /// </summary>
        /// <param name="tacticId">The ID of the tactic to request review for</param>
        /// <returns>Success response or validation errors</returns>
        /// <response code="200">Review successfully requested, tactic status updated to VERBIAGE_REVIEW</response>
        /// <response code="400">Validation failed (missing VerbiageComments or invalid status)</response>
        /// <response code="401">Authentication required</response>
        /// <response code="403">User does not have ProofReader role</response>
        /// <response code="404">Tactic not found</response>
        /// <response code="500">Internal server error</response>
        [HttpPost("{tacticId:guid}/request-review")]
        [Authorize(Roles = "ProofReader")]
        [ProducesResponseType(typeof(RequestReviewResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(RequestReviewResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> RequestReview(Guid tacticId)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();

            _logger.LogInformation(
                "[{CorrelationId}] Requesting review for tactic {TacticId} by user {UserId}",
                correlationId, tacticId, userId);

            var command = new RequestReviewCommand(tacticId, userId);
            var response = await _mediator.Send(command);

            if (!response.Success)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] Failed to request review for tactic {TacticId}: {ErrorCount} validation errors",
                    correlationId, tacticId, response.Errors?.Count ?? 0);
                
                return BadRequest(response);
            }

            _logger.LogInformation(
                "[{CorrelationId}] Successfully requested review for tactic {TacticId}",
                correlationId, tacticId);

            return Ok(response);
        }

        /// <summary>
        /// Duplicate an existing tactic. Any user with the Requester role can duplicate any tactic.
        /// </summary>
        /// <param name="tacticId">ID of the tactic to duplicate</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>ID of the newly created tactic</returns>
        /// <response code="201">Tactic successfully duplicated</response>
        /// <response code="400">Invalid tactic ID format</response>
        /// <response code="401">Authentication required (must have Requester role)</response>
        /// <response code="404">Tactic not found</response>
        /// <response code="500">Internal server error</response>
        [HttpPost("{tacticId}/duplicate")]
        [Authorize(Roles = "Requester")]
        [ProducesResponseType(typeof(DuplicateTacticResponse), StatusCodes.Status201Created)]
        [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<DuplicateTacticResponse>> DuplicateTactic(
            [FromRoute] Guid tacticId,
            CancellationToken cancellationToken)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            
            // Validate tacticId format
            if (tacticId == Guid.Empty)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] DuplicateTactic request failed: Invalid tacticId (Guid.Empty)",
                    correlationId);
                
                return BadRequest(new ProblemDetails
                {
                    Type = "BadRequest",
                    Title = "Invalid request",
                    Status = StatusCodes.Status400BadRequest,
                    Detail = "The tactic ID must be a valid UUID format."
                });
            }
            
            // Extract and validate user ID
            string userId;
            try
            {
                userId = GetUserIdFromClaims();
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogError(
                    "[{CorrelationId}] DuplicateTactic request failed: Missing or invalid user ID in JWT claims. Error: {ErrorMessage}",
                    correlationId, ex.Message);
                
                return Unauthorized(new ProblemDetails
                {
                    Type = "Unauthorized",
                    Title = "Authentication required",
                    Status = StatusCodes.Status401Unauthorized,
                    Detail = "A valid JWT token with user ID is required to access this resource."
                });
            }

            _logger.LogInformation(
                "[{CorrelationId}] DuplicateTactic request started for TacticId: {TacticId}, UserId: {UserId}",
                correlationId, tacticId, userId);

            try
            {
                _logger.LogDebug(
                    "[{CorrelationId}] Sending DuplicateTacticCommand: SourceTacticId={SourceTacticId}, RequesterId={RequesterId}",
                    correlationId, tacticId, userId);

                var command = new DuplicateTacticCommand
                {
                    SourceTacticId = tacticId,
                    RequesterId = userId
                };

                var response = await _mediator.Send(command, cancellationToken);

                _logger.LogInformation(
                    "[{CorrelationId}] DuplicateTactic completed successfully: SourceTacticId={SourceTacticId}, NewTacticId={NewTacticId}, UserId={UserId}",
                    correlationId, tacticId, response.Id, userId);

                return CreatedAtAction(
                    nameof(GetTacticById),
                    new { tacticId = response.Id },
                    response);
            }
            catch (KeyNotFoundException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] DuplicateTactic failed: Tactic not found. TacticId: {TacticId}, UserId: {UserId}, Error: {ErrorMessage}",
                    correlationId, tacticId, userId, ex.Message);
                
                return NotFound(new ProblemDetails
                {
                    Type = "NotFound",
                    Title = "Resource not found",
                    Status = StatusCodes.Status404NotFound,
                    Detail = "The requested tactic could not be found or you do not have access to it."
                });
            }
            catch (InvalidOperationException ex) when (ex.Message.Contains("offer code"))
            {
                _logger.LogError(
                    "[{CorrelationId}] DuplicateTactic failed: Offer code collision. TacticId: {TacticId}, UserId: {UserId}, Error: {ErrorMessage}",
                    correlationId, tacticId, userId, ex.Message);
                
                return StatusCode(StatusCodes.Status500InternalServerError, new ProblemDetails
                {
                    Type = "InternalServerError",
                    Title = "Server error",
                    Status = StatusCodes.Status500InternalServerError,
                    Detail = $"Failed to generate unique offer code after multiple attempts. Please try again. Error: {ex.Message}"
                });
            }
            catch (IOException ex)
            {
                _logger.LogError(
                    "[{CorrelationId}] DuplicateTactic failed: Blob storage failure. TacticId: {TacticId}, UserId: {UserId}, Error: {ErrorMessage}",
                    correlationId, tacticId, userId, ex.Message);
                
                return StatusCode(StatusCodes.Status500InternalServerError, new ProblemDetails
                {
                    Type = "InternalServerError",
                    Title = "Server error",
                    Status = StatusCodes.Status500InternalServerError,
                    Detail = $"Failed to copy attachment files. Please try again. Error: {ex.Message}"
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(
                    "[{CorrelationId}] DuplicateTactic failed: Unexpected error. TacticId: {TacticId}, UserId: {UserId}, Error: {ErrorMessage}",
                    correlationId, tacticId, userId, ex.Message);
                
                return StatusCode(StatusCodes.Status500InternalServerError, new ProblemDetails
                {
                    Type = "InternalServerError",
                    Title = "Server error",
                    Status = StatusCodes.Status500InternalServerError,
                    Detail = "An error occurred while duplicating the tactic. Please try again."
                });
            }
        }

        /// <summary>
        /// Approves verbiage for a tactic, transitioning it from PROOF_READY to INFORMING_VENDORS status.
        /// </summary>
        /// <param name="id">The tactic ID</param>
        /// <returns>200 OK if successful</returns>
        /// <response code="200">Verbiage approved successfully</response>
        /// <response code="400">Invalid status or empty verbiage</response>
        /// <response code="403">User does not have ProofReader role</response>
        /// <response code="404">Tactic not found</response>
        [HttpPost("{id}/approve-verbiage")]
        [Authorize(Roles = "ProofReader")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> ApproveVerbiage(Guid id)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();

            _logger.LogInformation(
                "[{CorrelationId}] ApproveVerbiage request started. TacticId: {TacticId}, UserId: {UserId}",
                correlationId, id, userId);

            try
            {
                var command = new ApproveVerbiageCommand(id, userId);
                await _mediator.Send(command);

                _logger.LogInformation(
                    "[{CorrelationId}] ApproveVerbiage completed successfully. TacticId: {TacticId}, UserId: {UserId}",
                    correlationId, id, userId);

                return Ok();
            }
            catch (TacticNotFoundException)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] ApproveVerbiage failed: Tactic not found. TacticId: {TacticId}",
                    correlationId, id);
                
                return NotFound();
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] ApproveVerbiage failed: Unauthorized. TacticId: {TacticId}, UserId: {UserId}, Reason: {Reason}",
                    correlationId, id, userId, ex.Message);
                
                return Forbid();
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] ApproveVerbiage failed: Invalid operation. TacticId: {TacticId}, Reason: {Reason}",
                    correlationId, id, ex.Message);
                
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Completes clearinghouse review for a digital tactic, transitioning it from INFORMING_VENDORS to CLEARINGHOUSE_COMPLETE status.
        /// </summary>
        /// <param name="id">The tactic ID</param>
        /// <returns>200 OK if successful</returns>
        /// <response code="200">Clearinghouse review completed successfully</response>
        /// <response code="400">Invalid status or empty databar</response>
        /// <response code="403">User does not have ClearinghouseAgent role</response>
        /// <response code="404">Tactic not found</response>
        [HttpPost("{id}/complete-clearinghouse-review")]
        [Authorize(Roles = "ClearinghouseAgent")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> CompleteClearinghouseReview(Guid id)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();

            _logger.LogInformation(
                "[{CorrelationId}] CompleteClearinghouseReview request started. TacticId: {TacticId}, UserId: {UserId}",
                correlationId, id, userId);

            try
            {
                var command = new CompleteClearinghouseReviewCommand(id, userId);
                await _mediator.Send(command);

                _logger.LogInformation(
                    "[{CorrelationId}] CompleteClearinghouseReview completed successfully. TacticId: {TacticId}, UserId: {UserId}",
                    correlationId, id, userId);

                return Ok();
            }
            catch (TacticNotFoundException)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] CompleteClearinghouseReview failed: Tactic not found. TacticId: {TacticId}",
                    correlationId, id);
                
                return NotFound();
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] CompleteClearinghouseReview failed: Unauthorized. TacticId: {TacticId}, UserId: {UserId}, Reason: {Reason}",
                    correlationId, id, userId, ex.Message);
                
                return Forbid();
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] CompleteClearinghouseReview failed: Invalid operation. TacticId: {TacticId}, Reason: {Reason}",
                    correlationId, id, ex.Message);
                
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Confirms a rescheduled tactic and transitions to DRAFTING_PROOF (Clearinghouse Agent action)
        /// </summary>
        /// <param name="id">The tactic ID</param>
        /// <returns>200 OK if successful</returns>
        /// <response code="200">Reschedule confirmed successfully</response>
        /// <response code="400">Invalid status or missing databar</response>
        /// <response code="403">User does not have ClearinghouseAgent role</response>
        /// <response code="404">Tactic not found</response>
        [HttpPost("{id}/confirm-reschedule")]
        [Authorize(Roles = "ClearinghouseAgent")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> ConfirmRescheduledTactic(Guid id)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();

            _logger.LogInformation(
                "[{CorrelationId}] ConfirmRescheduledTactic request started. TacticId: {TacticId}, UserId: {UserId}",
                correlationId, id, userId);

            try
            {
                var command = new ConfirmRescheduledTacticCommand(id, userId);
                await _mediator.Send(command);

                _logger.LogInformation(
                    "[{CorrelationId}] ConfirmRescheduledTactic completed successfully. TacticId: {TacticId}, UserId: {UserId}",
                    correlationId, id, userId);

                return Ok();
            }
            catch (TacticNotFoundException)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] ConfirmRescheduledTactic failed: Tactic not found. TacticId: {TacticId}",
                    correlationId, id);
                
                return NotFound();
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] ConfirmRescheduledTactic failed: Unauthorized. TacticId: {TacticId}, UserId: {UserId}, Reason: {Reason}",
                    correlationId, id, userId, ex.Message);
                
                return Forbid();
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] ConfirmRescheduledTactic failed: Invalid operation. TacticId: {TacticId}, Reason: {Reason}",
                    correlationId, id, ex.Message);
                
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Submits creative artwork for a tactic (Creative Agent action)
        /// </summary>
        /// <param name="id">The tactic ID</param>
        /// <returns>200 OK if successful</returns>
        /// <response code="200">Creative artwork submitted successfully</response>
        /// <response code="400">Invalid status or missing design attachments</response>
        /// <response code="403">User does not have CreativeAgent role</response>
        /// <response code="404">Tactic not found</response>
        [HttpPost("{id}/submit-creative-artwork")]
        [Authorize(Roles = "CreativeAgent")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> SubmitCreativeArtwork(Guid id)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();

            _logger.LogInformation(
                "[{CorrelationId}] SubmitCreativeArtwork request started. TacticId: {TacticId}, UserId: {UserId}",
                correlationId, id, userId);

            try
            {
                var command = new SubmitCreativeArtworkCommand(id, userId);
                await _mediator.Send(command);

                _logger.LogInformation(
                    "[{CorrelationId}] SubmitCreativeArtwork completed successfully. TacticId: {TacticId}, UserId: {UserId}",
                    correlationId, id, userId);

                return Ok();
            }
            catch (TacticNotFoundException)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] SubmitCreativeArtwork failed: Tactic not found. TacticId: {TacticId}",
                    correlationId, id);
                
                return NotFound();
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] SubmitCreativeArtwork failed: Unauthorized. TacticId: {TacticId}, UserId: {UserId}, Reason: {Reason}",
                    correlationId, id, userId, ex.Message);
                
                return Forbid();
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] SubmitCreativeArtwork failed: Invalid operation. TacticId: {TacticId}, Reason: {Reason}",
                    correlationId, id, ex.Message);
                
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Submits digital proofs for a tactic (Digital Provider action)
        /// </summary>
        /// <param name="id">The tactic ID</param>
        /// <returns>200 OK if successful</returns>
        /// <response code="200">Digital proofs submitted successfully</response>
        /// <response code="400">Invalid status or missing digital proof attachments</response>
        /// <response code="403">User does not have DigitalProvider role</response>
        /// <response code="404">Tactic not found</response>
        [HttpPost("{id}/submit-digital-proofs")]
        [Authorize(Roles = "DigitalProvider")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> SubmitDigitalProofs(Guid id)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();

            _logger.LogInformation(
                "[{CorrelationId}] SubmitDigitalProofs request started. TacticId: {TacticId}, UserId: {UserId}",
                correlationId, id, userId);

            try
            {
                var command = new SubmitDigitalProofsCommand(id, userId);
                await _mediator.Send(command);

                _logger.LogInformation(
                    "[{CorrelationId}] SubmitDigitalProofs completed successfully. TacticId: {TacticId}, UserId: {UserId}",
                    correlationId, id, userId);

                return Ok();
            }
            catch (TacticNotFoundException)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] SubmitDigitalProofs failed: Tactic not found. TacticId: {TacticId}",
                    correlationId, id);
                
                return NotFound();
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] SubmitDigitalProofs failed: Unauthorized. TacticId: {TacticId}, UserId: {UserId}, Reason: {Reason}",
                    correlationId, id, userId, ex.Message);
                
                return Forbid();
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] SubmitDigitalProofs failed: Invalid operation. TacticId: {TacticId}, Reason: {Reason}",
                    correlationId, id, ex.Message);
                
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Requests vendor review for a digital tactic (Clearinghouse Agent action)
        /// </summary>
        /// <param name="id">The tactic ID</param>
        /// <param name="request">Request containing the review comment</param>
        /// <returns>200 OK if successful</returns>
        /// <response code="200">Vendor review requested successfully</response>
        /// <response code="400">Invalid status or empty comment</response>
        /// <response code="403">User does not have ClearinghouseAgent role</response>
        /// <response code="404">Tactic not found</response>
        [HttpPost("{id}/request-vendor-review")]
        [Authorize(Roles = "ClearinghouseAgent")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> RequestVendorReview(Guid id, [FromBody] RequestVendorReviewRequest request)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();

            _logger.LogInformation(
                "[{CorrelationId}] RequestVendorReview request started. TacticId: {TacticId}, UserId: {UserId}",
                correlationId, id, userId);

            try
            {
                var command = new RequestVendorReviewCommand(id, userId, request.Comment);
                await _mediator.Send(command);

                _logger.LogInformation(
                    "[{CorrelationId}] RequestVendorReview completed successfully. TacticId: {TacticId}, UserId: {UserId}",
                    correlationId, id, userId);

                return Ok();
            }
            catch (TacticNotFoundException)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] RequestVendorReview failed: Tactic not found. TacticId: {TacticId}",
                    correlationId, id);
                
                return NotFound();
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] RequestVendorReview failed: Unauthorized. TacticId: {TacticId}, UserId: {UserId}, Reason: {Reason}",
                    correlationId, id, userId, ex.Message);
                
                return Forbid();
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] RequestVendorReview failed: Invalid operation. TacticId: {TacticId}, Reason: {Reason}",
                    correlationId, id, ex.Message);
                
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Approves digital proof as Requester/Owner (parallel approval with Clearinghouse)
        /// </summary>
        /// <param name="id">The tactic ID</param>
        /// <returns>200 OK if successful</returns>
        /// <response code="200">Digital proof approved successfully</response>
        /// <response code="400">Invalid status or missing digital proof attachments</response>
        /// <response code="404">Tactic not found or user not authorized</response>
        [HttpPost("{id}/requester-approve-final-proof")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> RequesterApproveFinalProof(Guid id)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();

            _logger.LogInformation(
                "[{CorrelationId}] RequesterApproveFinalProof request started. TacticId: {TacticId}, UserId: {UserId}",
                correlationId, id, userId);

            try
            {
                var command = new RequesterApproveFinalProofCommand(id, userId);
                await _mediator.Send(command);

                _logger.LogInformation(
                    "[{CorrelationId}] RequesterApproveFinalProof completed successfully. TacticId: {TacticId}, UserId: {UserId}",
                    correlationId, id, userId);

                return Ok();
            }
            catch (TacticNotFoundException)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] RequesterApproveFinalProof failed: Tactic not found. TacticId: {TacticId}",
                    correlationId, id);
                
                return NotFound();
            }
            catch (KeyNotFoundException)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] RequesterApproveFinalProof failed: User not authorized. TacticId: {TacticId}, UserId: {UserId}",
                    correlationId, id, userId);
                
                return NotFound();
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] RequesterApproveFinalProof failed: Invalid operation. TacticId: {TacticId}, UserId: {UserId}, Reason: {Reason}",
                    correlationId, id, userId, ex.Message);
                
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Rejects digital proof as Requester/Owner and returns to drafting
        /// </summary>
        /// <param name="id">The tactic ID</param>
        /// <param name="request">Rejection request containing DigitalProviderComments</param>
        /// <returns>200 OK if successful</returns>
        /// <response code="200">Digital proof rejected successfully</response>
        /// <response code="400">Invalid status or missing rejection comments</response>
        /// <response code="404">Tactic not found or user not authorized</response>
        [HttpPost("{id}/requester-reject-final-proof")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> RequesterRejectFinalProof(Guid id, [FromBody] RequesterRejectFinalProofRequest request)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();

            _logger.LogInformation(
                "[{CorrelationId}] RequesterRejectFinalProof request started. TacticId: {TacticId}, UserId: {UserId}",
                correlationId, id, userId);

            try
            {
                var command = new RequesterRejectFinalProofCommand(id, userId, request.DigitalProviderComments);
                await _mediator.Send(command);

                _logger.LogInformation(
                    "[{CorrelationId}] RequesterRejectFinalProof completed successfully. TacticId: {TacticId}, UserId: {UserId}",
                    correlationId, id, userId);

                return Ok();
            }
            catch (TacticNotFoundException)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] RequesterRejectFinalProof failed: Tactic not found. TacticId: {TacticId}",
                    correlationId, id);
                
                return NotFound();
            }
            catch (KeyNotFoundException)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] RequesterRejectFinalProof failed: User not authorized. TacticId: {TacticId}, UserId: {UserId}",
                    correlationId, id, userId);
                
                return NotFound();
            }
            catch (ArgumentException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] RequesterRejectFinalProof failed: Invalid argument. TacticId: {TacticId}, UserId: {UserId}, Reason: {Reason}",
                    correlationId, id, userId, ex.Message);
                
                return BadRequest(ex.Message);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] RequesterRejectFinalProof failed: Invalid operation. TacticId: {TacticId}, UserId: {UserId}, Reason: {Reason}",
                    correlationId, id, userId, ex.Message);
                
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Approves digital proof for Clearinghouse Agent, transitioning tactic status appropriately
        /// </summary>
        /// <param name="id">The tactic ID</param>
        /// <returns>200 OK if successful</returns>
        /// <response code="200">Digital proof approved successfully</response>
        /// <response code="400">Invalid status or missing attachments</response>
        /// <response code="403">User does not have ClearinghouseAgent role</response>
        /// <response code="404">Tactic not found</response>
        [HttpPost("{id}/approve-digital-proof-clearinghouse")]
        [Authorize(Roles = "ClearinghouseAgent")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> ApproveDigitalProofClearinghouse(Guid id)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();

            _logger.LogInformation(
                "[{CorrelationId}] ApproveDigitalProofClearinghouse request started. TacticId: {TacticId}, UserId: {UserId}",
                correlationId, id, userId);

            try
            {
                var command = new ApproveDigitalProofClearinghouseCommand(id, userId);
                await _mediator.Send(command);

                _logger.LogInformation(
                    "[{CorrelationId}] ApproveDigitalProofClearinghouse completed successfully. TacticId: {TacticId}, UserId: {UserId}",
                    correlationId, id, userId);

                return Ok();
            }
            catch (TacticNotFoundException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] ApproveDigitalProofClearinghouse failed: Tactic not found. TacticId: {TacticId}",
                    correlationId, id);
                
                return NotFound(new { error = ex.Message });
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] ApproveDigitalProofClearinghouse failed: Unauthorized. TacticId: {TacticId}, UserId: {UserId}, Reason: {Reason}",
                    correlationId, id, userId, ex.Message);
                
                return StatusCode(StatusCodes.Status403Forbidden, new { error = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] ApproveDigitalProofClearinghouse failed: Invalid operation. TacticId: {TacticId}, Reason: {Reason}",
                    correlationId, id, ex.Message);
                
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Rejects digital proof for Clearinghouse Agent with comments, transitioning back to DRAFTING_PROOF
        /// </summary>
        /// <param name="id">The tactic ID</param>
        /// <param name="request">Request containing rejection comments</param>
        /// <returns>200 OK if successful</returns>
        /// <response code="200">Digital proof rejected successfully</response>
        /// <response code="400">Invalid status or empty comments</response>
        /// <response code="403">User does not have ClearinghouseAgent role</response>
        /// <response code="404">Tactic not found</response>
        [HttpPost("{id}/reject-digital-proof-clearinghouse")]
        [Authorize(Roles = "ClearinghouseAgent")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> RejectDigitalProofClearinghouse(Guid id, [FromBody] RejectDigitalProofRequest request)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();

            _logger.LogInformation(
                "[{CorrelationId}] RejectDigitalProofClearinghouse request started. TacticId: {TacticId}, UserId: {UserId}",
                correlationId, id, userId);

            if (request == null)
            {
                return BadRequest(new { error = "Request body is required" });
            }

            try
            {
                var command = new RejectDigitalProofClearinghouseCommand(id, userId, request.DigitalProviderComments);
                await _mediator.Send(command);

                _logger.LogInformation(
                    "[{CorrelationId}] RejectDigitalProofClearinghouse completed successfully. TacticId: {TacticId}, UserId: {UserId}",
                    correlationId, id, userId);

                return Ok();
            }
            catch (TacticNotFoundException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] RejectDigitalProofClearinghouse failed: Tactic not found. TacticId: {TacticId}",
                    correlationId, id);
                
                return NotFound(new { error = ex.Message });
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] RejectDigitalProofClearinghouse failed: Unauthorized. TacticId: {TacticId}, UserId: {UserId}, Reason: {Reason}",
                    correlationId, id, userId, ex.Message);
                
                return StatusCode(StatusCodes.Status403Forbidden, new { error = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] RejectDigitalProofClearinghouse failed: Invalid operation. TacticId: {TacticId}, Reason: {Reason}",
                    correlationId, id, ex.Message);
                
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Submits rescheduled tactic with new dates, transitioning from AWAITING_START to RESCHEDULE_SUBMITTED
        /// </summary>
        /// <param name="id">The tactic ID</param>
        /// <param name="request">Request containing new Start, End, and Expiry dates</param>
        /// <returns>200 OK if successful</returns>
        /// <response code="200">Tactic rescheduled successfully</response>
        /// <response code="400">Invalid status or invalid dates</response>
        /// <response code="404">Tactic not found or user doesn't have access</response>
        [HttpPost("{id}/submit-reschedule")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> SubmitRescheduledTactic(Guid id, [FromBody] SubmitRescheduleRequest request)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();

            _logger.LogInformation(
                "[{CorrelationId}] SubmitRescheduledTactic request started. TacticId: {TacticId}, UserId: {UserId}",
                correlationId, id, userId);

            if (request == null)
            {
                return BadRequest(new { error = "Request body is required" });
            }

            try
            {
                var command = new SubmitRescheduledTacticCommand(
                    id, 
                    userId, 
                    request.StartDate, 
                    request.EndDate, 
                    request.ExpiryDate);
                await _mediator.Send(command);

                _logger.LogInformation(
                    "[{CorrelationId}] SubmitRescheduledTactic completed successfully. TacticId: {TacticId}, UserId: {UserId}",
                    correlationId, id, userId);

                return Ok();
            }
            catch (TacticNotFoundException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] SubmitRescheduledTactic failed: Tactic not found. TacticId: {TacticId}",
                    correlationId, id);
                
                return NotFound(new { error = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] SubmitRescheduledTactic failed: Access denied. TacticId: {TacticId}, UserId: {UserId}",
                    correlationId, id, userId);
                
                return NotFound(new { error = ex.Message });
            }
            catch (ValidationException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] SubmitRescheduledTactic failed: Validation error. TacticId: {TacticId}, Reason: {Reason}",
                    correlationId, id, ex.Message);
                
                return BadRequest(new { error = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] SubmitRescheduledTactic failed: Invalid operation. TacticId: {TacticId}, Reason: {Reason}",
                    correlationId, id, ex.Message);
                
                return BadRequest(new { error = ex.Message });
            }
        }

        /// <summary>
        /// Submit reschedule for a LIVE tactic with new End and Expiry dates.
        /// Start date is preserved from the database.
        /// Transitions tactic from LIVE to RESCHEDULE_SUBMITTED status.
        /// </summary>
        /// <param name="id">The tactic ID</param>
        /// <param name="request">Request containing new End and Expiry dates (Start date is preserved)</param>
        /// <returns>200 OK if successful</returns>
        /// <response code="200">Tactic rescheduled successfully</response>
        /// <response code="400">Invalid status, expired tactic, or invalid dates</response>
        /// <response code="404">Tactic not found or user doesn't have access</response>
        [HttpPost("{id}/submit-reschedule-from-live")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> SubmitRescheduledTacticFromLive(Guid id, [FromBody] SubmitRescheduleFromLiveRequest request)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            var userId = GetUserIdFromClaims();

            _logger.LogInformation(
                "[{CorrelationId}] SubmitRescheduledTacticFromLive request started. TacticId: {TacticId}, UserId: {UserId}",
                correlationId, id, userId);

            if (request == null)
            {
                return BadRequest(new { error = "Request body is required" });
            }

            try
            {
                var command = new SubmitRescheduledTacticFromLiveCommand(
                    id, 
                    userId, 
                    request.EndDate, 
                    request.ExpiryDate);
                await _mediator.Send(command);

                _logger.LogInformation(
                    "[{CorrelationId}] SubmitRescheduledTacticFromLive completed successfully. TacticId: {TacticId}, UserId: {UserId}",
                    correlationId, id, userId);

                return Ok();
            }
            catch (TacticNotFoundException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] SubmitRescheduledTacticFromLive failed: Tactic not found. TacticId: {TacticId}",
                    correlationId, id);
                
                return NotFound(new { error = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] SubmitRescheduledTacticFromLive failed: Access denied. TacticId: {TacticId}, UserId: {UserId}",
                    correlationId, id, userId);
                
                return NotFound(new { error = ex.Message });
            }
            catch (ValidationException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] SubmitRescheduledTacticFromLive failed: Validation error. TacticId: {TacticId}, Reason: {Reason}",
                    correlationId, id, ex.Message);
                
                return BadRequest(new { error = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] SubmitRescheduledTacticFromLive failed: Invalid operation. TacticId: {TacticId}, Reason: {Reason}",
                    correlationId, id, ex.Message);
                
                return BadRequest(new { error = ex.Message });
            }
        }

        private string GetUserIdFromClaims()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim))
            {
                throw new UnauthorizedAccessException("Invalid user identifier in claims");
            }
            return userIdClaim;
        }
    }
}

/// <summary>
/// Request model for rejecting digital proof
/// </summary>
public class RequesterRejectFinalProofRequest
{
    /// <summary>
    /// Comments explaining why the digital proof is being rejected
    /// </summary>
    public string DigitalProviderComments { get; set; } = string.Empty;
}

/// <summary>
/// Request model for submitting rescheduled tactic with new dates
/// </summary>
public class SubmitRescheduleRequest
{
    /// <summary>
    /// New start date for the tactic (must be tomorrow or later)
    /// </summary>
    public DateTime StartDate { get; set; }

    /// <summary>
    /// New end date for the tactic (must be on or after start date)
    /// </summary>
    public DateTime EndDate { get; set; }

    /// <summary>
    /// New expiry date for the tactic (must be on or after end date)
    /// </summary>
    public DateTime ExpiryDate { get; set; }
}

/// <summary>
/// Request model for changing tactic owner
/// </summary>
public class ChangeOwnerRequest
{
    /// <summary>
    /// ID of the new owner (must be active requester in same OpCo)
    /// </summary>
    public string NewOwnerId { get; set; } = string.Empty;
}

/// <summary>
/// Request model for submitting rescheduled tactic from LIVE status with new End and Expiry dates.
/// Start date is preserved from the database.
/// </summary>
public class SubmitRescheduleFromLiveRequest
{
    /// <summary>
    /// New end date for the tactic (must be tomorrow or later)
    /// </summary>
    public DateTime EndDate { get; set; }

    /// <summary>
    /// New expiry date for the tactic (must be on or after end date)
    /// </summary>
    public DateTime ExpiryDate { get; set; }
}