using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using TacticManagement.Domain.Enums;
using TacticManagement.Domain.Models;

namespace TacticManagement.Infrastructure.Repositories.Filters;

/// <summary>
/// Contains all possible filter criteria for tactic queries.
/// Passed to strategies to determine applicability and filter logic.
/// </summary>
public class TacticFilterCriteria
{
    /// <summary>
    /// Role-based filter expressions from TacticReadAuthorizationService.
    /// Combined with OR logic by RoleBasedFilterStrategy.
    /// </summary>
    public List<Expression<Func<Tactic, bool>>>? RoleFilters { get; set; }

    /// <summary>
    /// Search term for multi-field text search.
    /// Numeric values match OfferCode exactly; text searches Description, Notes, OfferVerbiage, etc.
    /// </summary>
    public string? SearchTerm { get; set; }

    /// <summary>
    /// Single status enum filter.
    /// </summary>
    public TacticStatusEnum? Status { get; set; }

    /// <summary>
    /// List of tactic type IDs to filter by.
    /// </summary>
    public List<int>? TacticTypeIds { get; set; }

    /// <summary>
    /// List of status code strings to filter by.
    /// Converted to enum values by StatusCodesFilterStrategy.
    /// </summary>
    public List<string>? StatusCodes { get; set; }
}
