using System;
using System.Linq;
using TacticManagement.Domain.Models;

namespace TacticManagement.Infrastructure.Repositories.Filters.Strategies;

/// <summary>
/// Filters tactics by search term across multiple fields.
/// - Numeric search terms match OfferCode exactly
/// - Text search terms search Description, Notes, OfferVerbiage, etc.
/// - All field searches are combined with OR logic
/// </summary>
public class SearchTermFilterStrategy : ITacticFilterStrategy
{
    /// <summary>
    /// Determines if search term filtering should be applied.
    /// Returns true if SearchTerm is not null, empty, or whitespace.
    /// </summary>
    public bool ShouldApply(TacticFilterCriteria criteria)
    {
        return !string.IsNullOrWhiteSpace(criteria.SearchTerm);
    }

    /// <summary>
    /// Applies multi-field search with OR logic.
    /// Numeric search terms match OfferCode exactly.
    /// Text search terms search across Description, Notes, OfferVerbiage, and related entities.
    /// </summary>
    public IQueryable<Tactic> Apply(IQueryable<Tactic> query, TacticFilterCriteria criteria)
    {
        if (string.IsNullOrWhiteSpace(criteria.SearchTerm))
        {
            return query;
        }

        var searchTerm = criteria.SearchTerm.Trim();

        // Check if search term is numeric (for OfferCode exact match)
        if (int.TryParse(searchTerm, out var offerCode))
        {
            return query.Where(t => t.OfferCode == offerCode);
        }

        // Text search across multiple fields with OR logic
        var lowerSearchTerm = searchTerm.ToLower();
        
        return query.Where(t =>
            (t.Description != null && t.Description.ToLower().Contains(lowerSearchTerm)) ||
            (t.Notes != null && t.Notes.ToLower().Contains(lowerSearchTerm)) ||
            (t.OfferVerbiage != null && t.OfferVerbiage.ToLower().Contains(lowerSearchTerm)) ||
            (t.Comments != null && t.Comments.ToLower().Contains(lowerSearchTerm))
        );
    }
}
