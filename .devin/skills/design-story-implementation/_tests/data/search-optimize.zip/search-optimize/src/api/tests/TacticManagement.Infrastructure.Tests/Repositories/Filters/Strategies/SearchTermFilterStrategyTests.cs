using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using TacticManagement.Domain.Models;
using TacticManagement.Infrastructure.Repositories.Filters;
using TacticManagement.Infrastructure.Repositories.Filters.Strategies;
using Xunit;

namespace TacticManagement.Infrastructure.Tests.Repositories.Filters.Strategies;

public class SearchTermFilterStrategyTests
{
    [Fact]
    public void ShouldApply_WhenSearchTermIsNull_ReturnsFalse()
    {
        // Arrange
        var strategy = new SearchTermFilterStrategy();
        var criteria = new TacticFilterCriteria
        {
            SearchTerm = null
        };

        // Act
        var result = strategy.ShouldApply(criteria);

        // Assert
        result.Should().BeFalse();
    }

    [Fact]
    public void ShouldApply_WhenSearchTermIsEmpty_ReturnsFalse()
    {
        // Arrange
        var strategy = new SearchTermFilterStrategy();
        var criteria = new TacticFilterCriteria
        {
            SearchTerm = ""
        };

        // Act
        var result = strategy.ShouldApply(criteria);

        // Assert
        result.Should().BeFalse();
    }

    [Fact]
    public void ShouldApply_WhenSearchTermIsWhitespace_ReturnsFalse()
    {
        // Arrange
        var strategy = new SearchTermFilterStrategy();
        var criteria = new TacticFilterCriteria
        {
            SearchTerm = "   "
        };

        // Act
        var result = strategy.ShouldApply(criteria);

        // Assert
        result.Should().BeFalse();
    }

    [Fact]
    public void ShouldApply_WhenSearchTermIsProvided_ReturnsTrue()
    {
        // Arrange
        var strategy = new SearchTermFilterStrategy();
        var criteria = new TacticFilterCriteria
        {
            SearchTerm = "test"
        };

        // Act
        var result = strategy.ShouldApply(criteria);

        // Assert
        result.Should().BeTrue();
    }

    [Fact]
    public void Apply_WithNumericSearchTerm_MatchesOfferCodeExactly()
    {
        // Arrange
        var strategy = new SearchTermFilterStrategy();
        var now = DateTime.UtcNow;
        var tactics = new List<Tactic>
        {
            new Tactic("Test 1", "user-1", now, now.AddDays(30), now.AddDays(60)) { OfferCode = 123456 },
            new Tactic("Test 2", "user-1", now, now.AddDays(30), now.AddDays(60)) { OfferCode = 789012 },
            new Tactic("Test 3", "user-1", now, now.AddDays(30), now.AddDays(60)) { OfferCode = 345678 }
        };
        var query = tactics.AsQueryable();
        
        var criteria = new TacticFilterCriteria
        {
            SearchTerm = "123456"
        };

        // Act
        var result = strategy.Apply(query, criteria);

        // Assert
        var filtered = result.ToList();
        filtered.Should().HaveCount(1);
        filtered[0].OfferCode.Should().Be(123456);
    }

    [Fact]
    public void Apply_WithTextSearchTerm_SearchesDescription()
    {
        // Arrange
        var strategy = new SearchTermFilterStrategy();
        var now = DateTime.UtcNow;
        var tactics = new List<Tactic>
        {
            new Tactic("Summer Promotion", "user-1", now, now.AddDays(30), now.AddDays(60)),
            new Tactic("Winter Sale", "user-1", now, now.AddDays(30), now.AddDays(60)),
            new Tactic("Spring Offer", "user-1", now, now.AddDays(30), now.AddDays(60))
        };
        var query = tactics.AsQueryable();
        
        var criteria = new TacticFilterCriteria
        {
            SearchTerm = "summer"
        };

        // Act
        var result = strategy.Apply(query, criteria);

        // Assert
        var filtered = result.ToList();
        filtered.Should().HaveCount(1);
        filtered[0].Description.Should().Be("Summer Promotion");
    }

    [Fact]
    public void Apply_WithTextSearchTerm_SearchesNotes()
    {
        // Arrange
        var strategy = new SearchTermFilterStrategy();
        var now = DateTime.UtcNow;
        var tactics = new List<Tactic>
        {
            new Tactic("Test 1", "user-1", now, now.AddDays(30), now.AddDays(60)) { Notes = "Important deadline" },
            new Tactic("Test 2", "user-1", now, now.AddDays(30), now.AddDays(60)) { Notes = "Regular promo" },
            new Tactic("Test 3", "user-1", now, now.AddDays(30), now.AddDays(60)) { Notes = "Standard offer" }
        };
        var query = tactics.AsQueryable();
        
        var criteria = new TacticFilterCriteria
        {
            SearchTerm = "deadline"
        };

        // Act
        var result = strategy.Apply(query, criteria);

        // Assert
        var filtered = result.ToList();
        filtered.Should().HaveCount(1);
        filtered[0].Notes.Should().Be("Important deadline");
    }

    [Fact]
    public void Apply_CombinesMultiFieldSearchWithOrLogic()
    {
        // Arrange
        var strategy = new SearchTermFilterStrategy();
        var now = DateTime.UtcNow;
        var tactics = new List<Tactic>
        {
            new Tactic("Summer Sale", "user-1", now, now.AddDays(30), now.AddDays(60)) { Notes = "Regular" },
            new Tactic("Winter Promo", "user-1", now, now.AddDays(30), now.AddDays(60)) { Notes = "Special discount" },
            new Tactic("Spring Offer", "user-1", now, now.AddDays(30), now.AddDays(60)) { OfferVerbiage = "Great discount" }
        };
        var query = tactics.AsQueryable();
        
        var criteria = new TacticFilterCriteria
        {
            SearchTerm = "discount"
        };

        // Act
        var result = strategy.Apply(query, criteria);

        // Assert
        var filtered = result.ToList();
        filtered.Should().HaveCount(2); // Winter (Notes) and Spring (OfferVerbiage)
        filtered.Should().Contain(t => t.Description == "Winter Promo");
        filtered.Should().Contain(t => t.Description == "Spring Offer");
    }
}
