using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.Extensions.Logging;
using TacticManagement.Application.Common.Extensions;
using TacticManagement.Application.Tactics.DTOs;
using TacticManagement.Domain.Models;
using TacticManagement.Application.Tactics.Queries;
using TacticStatusEnum = TacticManagement.Domain.Enums.TacticStatusEnum;
using TacticManagement.Application.Interfaces;
using TacticManagement.Application.Common.Interfaces;
using TacticManagement.Application.Repositories;

namespace TacticManagement.Application.Queries
{
    public class GetUserTacticsQueryHandler : IRequestHandler<GetUserTacticsQuery, PaginatedResponseDto<TacticListItemDto>>
    {
        private readonly ITacticRepository _tacticRepository;
        private readonly IUserContextService _userContextService;
        private readonly IUserEntityRepository _userEntityRepository;
        private readonly ITacticReadAuthorizationService _tacticReadAuthorizationService;
        private readonly IUserOpCoRepository _userOpCoRepository;
        private readonly ILogger<GetUserTacticsQueryHandler> _logger;
        private const int DefaultPageSize = 20;
        private const int MaxPageSize = 100;

        public GetUserTacticsQueryHandler(
            ITacticRepository tacticRepository,
            IUserContextService userContextService,
            IUserEntityRepository userEntityRepository,
            ITacticReadAuthorizationService tacticReadAuthorizationService,
            IUserOpCoRepository userOpCoRepository,
            ILogger<GetUserTacticsQueryHandler> logger)
        {
            _tacticRepository = tacticRepository ?? throw new ArgumentNullException(nameof(tacticRepository));
            _userContextService = userContextService ?? throw new ArgumentNullException(nameof(userContextService));
            _userEntityRepository = userEntityRepository ?? throw new ArgumentNullException(nameof(userEntityRepository));
            _tacticReadAuthorizationService = tacticReadAuthorizationService ?? throw new ArgumentNullException(nameof(tacticReadAuthorizationService));
            _userOpCoRepository = userOpCoRepository ?? throw new ArgumentNullException(nameof(userOpCoRepository));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<PaginatedResponseDto<TacticListItemDto>> Handle(
            GetUserTacticsQuery request, 
            CancellationToken cancellationToken)
        {
            if (request == null)
                throw new ArgumentNullException(nameof(request));

            _logger.LogDebug(
                "GetUserTacticsQueryHandler started - UserId: {UserId}, Term: {Term}, Status: {Status}, Page: {Page}, PageSize: {PageSize}",
                request.UserId, request.Term ?? "null", request.Status ?? "null", request.Page, request.PageSize);

            // Validate and normalize pagination parameters
            var pageSize = request.PageSize <= 0 || request.PageSize > MaxPageSize 
                ? DefaultPageSize 
                : request.PageSize;

            var pageNumber = request.Page < 1 ? 1 : request.Page;
            
            if (pageSize != request.PageSize || pageNumber != request.Page)
            {
                _logger.LogDebug(
                    "Normalized pagination parameters - Original Page: {OriginalPage}, Normalized Page: {Page}, Original PageSize: {OriginalPageSize}, Normalized PageSize: {PageSize}",
                    request.Page, pageNumber, request.PageSize, pageSize);
            }
            
            // Normalize sort parameters
            var sortBy = string.IsNullOrWhiteSpace(request.SortBy) 
                ? "offercode" 
                : request.SortBy.Trim().ToLower();

            var sortOrder = string.IsNullOrWhiteSpace(request.SortOrder) || 
                           !(request.SortOrder.Equals("asc", StringComparison.OrdinalIgnoreCase) || 
                             request.SortOrder.Equals("desc", StringComparison.OrdinalIgnoreCase))
                ? "desc" 
                : request.SortOrder.ToLower();

            // Get user context with roles and organizational assignments
            var userContext = await _userContextService.GetUserContextAsync(request.UserId, cancellationToken);
            var roles = userContext?.Roles ?? new List<string>();

            _logger.LogDebug(
                "Building authorization filters - UserId: {UserId}, Roles: {Roles}",
                request.UserId, string.Join(", ", roles));

            // CRITICAL SECURITY: OpCo boundary verification for RequesterUserIds
            if (request.RequesterUserIds != null && request.RequesterUserIds.Any())
            {
                _logger.LogInformation(
                    "User {UserId} filtering by {Count} requesters: {RequesterUserIds}",
                    request.UserId, request.RequesterUserIds.Count, 
                    string.Join(", ", request.RequesterUserIds));

                // STEP 1: Get caller's OpCo assignments
                var callerOpCos = userContext?.OpCos?.Select(o => o.Id).ToList() ?? new List<Guid>();
                
                if (!callerOpCos.Any())
                {
                    _logger.LogWarning(
                        "User {UserId} has no OpCo assignments, cannot filter by requesters",
                        request.UserId);
                    
                    // Return empty result (user has no OpCo access)
                    return new PaginatedResponseDto<TacticListItemDto>
                    {
                        Items = Enumerable.Empty<TacticListItemDto>(),
                        Page = pageNumber,
                        PageSize = pageSize,
                        TotalCount = 0
                    };
                }

                // STEP 2: Get OpCo assignments for requested users (single query)
                var requestedUserOpCos = await _userOpCoRepository
                    .GetOpCosForUsersAsync(request.RequesterUserIds, cancellationToken);

                // STEP 3: Verify ALL requested users share at least one OpCo with caller
                var unauthorizedUsers = new List<string>();
                foreach (var requestedUserId in request.RequesterUserIds)
                {
                    if (!requestedUserOpCos.ContainsKey(requestedUserId))
                    {
                        // User has no OpCo assignments (or doesn't exist)
                        unauthorizedUsers.Add(requestedUserId);
                        continue;
                    }

                    var userOpCos = requestedUserOpCos[requestedUserId];
                    var hasSharedOpCo = userOpCos.Any(opco => callerOpCos.Contains(opco));
                    
                    if (!hasSharedOpCo)
                    {
                        // User exists but not in caller's OpCo
                        unauthorizedUsers.Add(requestedUserId);
                    }
                }

                // STEP 4: If any unauthorized users, reject request
                if (unauthorizedUsers.Any())
                {
                    _logger.LogWarning(
                        "[SECURITY] User {UserId} attempted to filter by requesters outside their OpCo: {UnauthorizedUsers}",
                        request.UserId, string.Join(", ", unauthorizedUsers));
                    
                    // Return 403 Forbidden (don't reveal which users are unauthorized)
                    throw new UnauthorizedAccessException("Access denied");
                }

                _logger.LogDebug(
                    "OpCo verification passed for {Count} requesters",
                    request.RequesterUserIds.Count);
            }

            List<Tactic> result;
            int totalCount;

            // Admin sees all tactics (no filtering)
            if (roles.Contains("Admin", StringComparer.OrdinalIgnoreCase))
            {
                _logger.LogDebug(
                    "Querying repository for ALL tactics (Admin) - UserId: {UserId}",
                    request.UserId);
                
                var statusEnum = request.Status == null ? (TacticStatusEnum?)null : Enum.Parse<TacticStatusEnum>(request.Status);
                
                // Get total count before pagination
                totalCount = await _tacticRepository.GetAllTacticsCountAsync(
                    request.Term?.Trim(),
                    statusEnum,
                    request.TacticTypeIds,
                    request.StatusCodes,
                    cancellationToken);
                
                result = await _tacticRepository.GetAllTacticsAsync(
                    request.Term?.Trim(),
                    statusEnum,
                    request.TacticTypeIds,
                    request.StatusCodes,
                    pageNumber,
                    pageSize,
                    sortBy,
                    sortOrder,
                    cancellationToken);
            }
            else
            {
                // Use authorization service for role-based filtering (includes Requester OpCo-scoped access)
                var roleFilters = await _tacticReadAuthorizationService.BuildReadAuthorizationFiltersAsync(
                    request.UserId,
                    userContext,
                    request.RequesterUserIds,
                    "GetUserTactics",
                    cancellationToken);

                if (roleFilters == null || !roleFilters.Any())
                {
                    _logger.LogWarning(
                        "No authorization filters built for user - UserId: {UserId}, Roles: {Roles}. Returning empty result.",
                        request.UserId, string.Join(", ", roles));
                    
                    result = new List<Tactic>();
                    totalCount = 0;
                }
                else
                {
                    _logger.LogDebug(
                        "Querying repository with {FilterCount} role-based filters - UserId: {UserId}",
                        roleFilters.Count, request.UserId);
                    
                    var statusEnum = request.Status == null ? (TacticStatusEnum?)null : Enum.Parse<TacticStatusEnum>(request.Status);
                    
                    // Get total count before pagination
                    totalCount = await _tacticRepository.GetUserTacticsWithFiltersCountAsync(
                        roleFilters,
                        request.Term?.Trim(),
                        statusEnum,
                        request.TacticTypeIds,
                        request.StatusCodes,
                        cancellationToken);
                    
                    result = await _tacticRepository.GetUserTacticsWithFiltersAsync(
                        roleFilters,
                        request.Term?.Trim(),
                        statusEnum,
                        request.TacticTypeIds,
                        request.StatusCodes,
                        pageNumber,
                        pageSize,
                        sortBy,
                        sortOrder,
                        cancellationToken);
                }
            }
            
            _logger.LogInformation(
                "Retrieved {PageCount} tactics (of {TotalCount} total) for UserId: {UserId}",
                result.Count, totalCount, request.UserId);

            // Map to DTO
            var tacticListItems = result.Select(t => new TacticListItemDto
            {
                Id = t.Id,
                Description = t.Description ?? string.Empty,
                OfferCode = t.OfferCode,
                TacticTypeName = t.TacticType?.Name ?? string.Empty,
                Status = ((TacticStatusEnum)t.StatusId).ToString(),
                CampaignStartDate = t.StartDate,
                CampaignEndDate = t.EndDate,
                ExpiryDate = t.ExpiryDate,
                Created = t.CreatedDate,
                LastModifiedBy = t.LastModifiedBy,
                LastModified = t.LastModified,
                OwnerId = t.OwnerId,
                Brand = AggregateBrands(t.ProductRows),
                Vendors = AggregateVendors(t.DigitalProvider?.Name, t.CreativeAgency?.Name, t.Printer?.Name),
                OfferVerbiage = t.OfferVerbiage
            });

            var response = new PaginatedResponseDto<TacticListItemDto>
            {
                Items = tacticListItems,
                Page = pageNumber,
                PageSize = pageSize,
                TotalCount = totalCount,
            };
            
            _logger.LogDebug(
                "GetUserTacticsQueryHandler completed - UserId: {UserId}, TotalCount: {TotalCount}, PageCount: {PageCount}",
                request.UserId, response.TotalCount, response.Items.Count());
            
            return response;
        }

        private static string? AggregateBrands(ICollection<TacticProductRow> productRows)
        {
            if (productRows == null || !productRows.Any())
            {
                return null;
            }

            // Get distinct brand names from product rows
            var brandNames = productRows
                .Where(pr => !string.IsNullOrWhiteSpace(pr.Brand))
                .Select(pr => pr.Brand)
                .Distinct()
                .OrderBy(b => b);

            if (!brandNames.Any())
            {
                return null;
            }

            var aggregated = string.Join(", ", brandNames);

            // Truncate at ~50 characters with "..."
            const int maxLength = 50;
            if (aggregated.Length > maxLength)
            {
                return aggregated.Substring(0, maxLength) + "...";
            }

            return aggregated;
        }

        private static string? AggregateVendors(string? digitalProvider, string? creativeAgency, string? printer)
        {
            // Collect all non-null, non-empty vendor names, excluding "None"
            var vendors = new List<string>();

            if (!string.IsNullOrWhiteSpace(digitalProvider) && 
                !digitalProvider.Equals("None", StringComparison.OrdinalIgnoreCase))
            {
                vendors.Add(digitalProvider);
            }

            if (!string.IsNullOrWhiteSpace(creativeAgency) && 
                !creativeAgency.Equals("None", StringComparison.OrdinalIgnoreCase))
            {
                vendors.Add(creativeAgency);
            }

            if (!string.IsNullOrWhiteSpace(printer) && 
                !printer.Equals("None", StringComparison.OrdinalIgnoreCase))
            {
                vendors.Add(printer);
            }

            if (!vendors.Any())
            {
                return null;
            }

            var aggregated = string.Join(", ", vendors);

            // Truncate at ~50 characters with "..."
            const int maxLength = 50;
            if (aggregated.Length > maxLength)
            {
                return aggregated.Substring(0, maxLength) + "...";
            }

            return aggregated;
        }

        /// <summary>
        /// Builds role-based authorization filters for entity-based access control.
        /// Filters are combined with OR logic (union).
        /// </summary>
        private async Task<List<Expression<Func<Tactic, bool>>>> BuildRoleFiltersAsync(
            string userId,
            Common.Models.UserContext? userContext,
            CancellationToken cancellationToken)
        {
            var filters = new List<Expression<Func<Tactic, bool>>>();
            var roles = userContext?.Roles ?? new List<string>();

            // Requester: See tactics they own OR requested
            if (roles.Contains("Requester", StringComparer.OrdinalIgnoreCase))
            {
                filters.Add(t => t.OwnerId == userId || t.RequesterId == userId);
                _logger.LogDebug("Added Requester filter for UserId: {UserId}", userId);
            }

            // ProofReader: See tactics from their assigned OpCos (same as Clearinghouse Agent)
            if (roles.Contains("ProofReader", StringComparer.OrdinalIgnoreCase))
            {
                var opCoIds = userContext?.OpCos?.Select(o => o.Id).ToList() ?? new List<Guid>();
                if (opCoIds.Any())
                {
                    filters.Add(t => t.OpCoId.HasValue && opCoIds.Contains(t.OpCoId.Value));
                    _logger.LogDebug(
                        "Added ProofReader filter for UserId: {UserId}, OpCoCount: {OpCoCount}",
                        userId, opCoIds.Count);
                }
                else
                {
                    _logger.LogWarning(
                        "ProofReader has no OpCo assignments - UserId: {UserId}",
                        userId);
                }
            }

            // Clearinghouse Agent: See tactics from their assigned OpCos
            if (roles.Contains("ClearinghouseAgent", StringComparer.OrdinalIgnoreCase))
            {
                var opCoIds = userContext?.OpCos?.Select(o => o.Id).ToList() ?? new List<Guid>();
                if (opCoIds.Any())
                {
                    filters.Add(t => t.OpCoId.HasValue && opCoIds.Contains(t.OpCoId.Value));
                    _logger.LogDebug(
                        "Added ClearinghouseAgent filter for UserId: {UserId}, OpCoCount: {OpCoCount}",
                        userId, opCoIds.Count);
                }
                else
                {
                    _logger.LogWarning(
                        "ClearinghouseAgent has no OpCo assignments - UserId: {UserId}",
                        userId);
                }
            }

            // Creative Agent: See tactics assigned to their agency entities
            if (roles.Contains("CreativeAgent", StringComparer.OrdinalIgnoreCase))
            {
                var entityIds = await _userEntityRepository.GetEntityIdsForUserAsync(userId, cancellationToken);
                if (entityIds != null && entityIds.Any())
                {
                    filters.Add(t => t.CreativeAgencyId.HasValue && entityIds.Contains(t.CreativeAgencyId.Value));
                    _logger.LogDebug(
                        "Added CreativeAgent filter for UserId: {UserId}, EntityCount: {EntityCount}",
                        userId, entityIds.Count);
                }
                else
                {
                    _logger.LogWarning(
                        "CreativeAgent has no entity assignments - UserId: {UserId}",
                        userId);
                }
            }

            // Digital Provider: See tactics assigned to their provider entities
            if (roles.Contains("DigitalProvider", StringComparer.OrdinalIgnoreCase))
            {
                var entityIds = await _userEntityRepository.GetEntityIdsForUserAsync(userId, cancellationToken);
                if (entityIds != null && entityIds.Any())
                {
                    filters.Add(t => t.DigitalProviderId.HasValue && entityIds.Contains(t.DigitalProviderId.Value));
                    _logger.LogDebug(
                        "Added DigitalProvider filter for UserId: {UserId}, EntityCount: {EntityCount}",
                        userId, entityIds.Count);
                }
                else
                {
                    _logger.LogWarning(
                        "DigitalProvider has no entity assignments - UserId: {UserId}",
                        userId);
                }
            }

            return filters;
        }
    }
}
