import { useState, useEffect, useReducer, useRef } from "react";
import { logger } from "../../../shared/utils/logger.util";
import type { TacticListItemDTO } from "@coupon-builder/models";
import tacticsApi from "../../../shared/apis/tactics-api";
import { useNavigate } from "react-router-dom";
import { 
  getPrefiltersFromCache, 
  setPrefiltersInCache 
} from "../../../shared/utils/filter-presets-cache";
import { useUser } from "../../../shared/hooks/use-user";
import { 
  paginationReducer, 
  initialPaginationState 
} from "./pagination-reducer";

export function useTacticTable() {
  const [tactics, setTactics] = useState<TacticListItemDTO[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const [tacticTypeIds, setTacticTypeIds] = useState<number[]>([]);
  const [statusCodes, setStatusCodes] = useState<string[]>([]);
  const [requesterUserIds, setRequesterUserIds] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState("");
  const [presetsLoaded, setPresetsLoaded] = useState(false);
  const [paginationState, dispatch] = useReducer(paginationReducer, initialPaginationState);
  const tableRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const user = useUser();

  // Fetch and apply filter presets on mount (with caching)
  useEffect(() => {
    // Wait for user to be loaded
    if (!user?.userId) {
      return;
    }

    const applyPresets = async () => {
      try {
        // Check cache first (user-specific)
        const cachedPresets = getPrefiltersFromCache(user.userId);
        if (cachedPresets !== null) {
          setStatusCodes(cachedPresets);
          logger.info("Filter presets applied from cache", { userId: user.userId, statusCodes: cachedPresets });
          setPresetsLoaded(true);
          return;
        }

        // Fetch from API if not cached
        const presets = await tacticsApi.getDefaultFilterPresets();
        setStatusCodes(presets.defaultStatuses);
        setPrefiltersInCache(user.userId, presets.defaultStatuses);
        logger.info("Filter presets fetched and cached", { userId: user.userId, statusCodes: presets.defaultStatuses });
      } catch (err) {
        logger.error("Failed to apply filter presets, showing all tactics", { userId: user.userId, error: err });
        // Graceful degradation - show all tactics (don't set statusCodes)
      } finally {
        // Always set presetsLoaded to true, even on error (graceful degradation)
        setPresetsLoaded(true);
      }
    };

    applyPresets();
  }, [user?.userId]); // Re-run when user changes

  // Debounce search term with 300ms delay
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 300);

    return () => {
      clearTimeout(timer);
    };
  }, [searchTerm]);

  useEffect(() => {
    // Wait for filter presets to load before fetching tactics
    if (!presetsLoaded) {
      logger.debug("Waiting for filter presets to load before fetching tactics");
      return;
    }

    const fetchTactics = async () => {
      try {
        setIsLoading(true);
        
        // Build params object with pagination and sort
        const params: { 
          tacticTypeIds?: number[]; 
          statusCodes?: string[]; 
          requesterUserIds?: string[]; 
          term?: string;
          sortBy?: string;
          sortOrder?: "asc" | "desc";
          page?: number;
          pageSize?: number;
        } = {
          sortBy: paginationState.sortBy,
          sortOrder: paginationState.sortOrder,
          page: paginationState.page,
          pageSize: paginationState.pageSize
        };
        
        if (tacticTypeIds.length > 0) {
          params.tacticTypeIds = tacticTypeIds;
        }
        if (statusCodes.length > 0) {
          params.statusCodes = statusCodes;
        }
        if (requesterUserIds.length > 0) {
          params.requesterUserIds = requesterUserIds;
        }
        if (debouncedSearchTerm) {
          params.term = debouncedSearchTerm;
        }
        
        logger.info("Fetching tactics with params", { 
          params,
          presetsLoaded,
          statusCodesCount: statusCodes.length,
          statusCodes: statusCodes
        });
        
        const data = await tacticsApi.getTactics(params);

        setTactics(data.items || []);
        dispatch({ 
          type: 'SET_PAGINATION_METADATA', 
          totalCount: data.totalCount || 0, 
          totalPages: data.totalPages || 0 
        });
        logger.info("Tactics loaded successfully", {
          count: data.items?.length,
          totalCount: data.totalCount,
          totalPages: data.totalPages,
          filters: params,
        });
      } catch (err) {
        setError(
          err instanceof Error ? err : new Error("Unknown error occurred"),
        );
        logger.error("Failed to load tactics", { error: err });
      } finally {
        setIsLoading(false);
      }
    };

    fetchTactics();
  }, [presetsLoaded, tacticTypeIds, statusCodes, requesterUserIds, debouncedSearchTerm, paginationState.page, paginationState.pageSize, paginationState.sortBy, paginationState.sortOrder]);

  // Reset to page 1 when filters change
  useEffect(() => {
    dispatch({ type: 'RESET_TO_PAGE_ONE' });
  }, [tacticTypeIds, statusCodes, requesterUserIds, debouncedSearchTerm]);

  const handleRowClick = (tactic: TacticListItemDTO) => {
    logger.info("Tactic selected", { tacticId: tactic.id });
    navigate(`/tactic/${tactic.id}`);
    // Additional logic for row click can be added here
  };

  const clearFilters = () => {
    setTacticTypeIds([]);
    setStatusCodes([]);
    setRequesterUserIds([]);
    setSearchTerm("");
    dispatch({ type: 'RESET_TO_PAGE_ONE' });
    logger.info("Filters cleared");
  };

  const handlePageChange = (newPage: number) => {
    dispatch({ type: 'SET_PAGE', page: newPage });
    tableRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const handlePageSizeChange = (newPageSize: number) => {
    if (newPageSize !== paginationState.pageSize) {
      dispatch({ type: 'SET_PAGE_SIZE', pageSize: newPageSize });
    }
  };

  const handleSortChange = (field: string, order: 'asc' | 'desc') => {
    dispatch({ type: 'SET_SORT', sortBy: field, sortOrder: order });
  };

  const tableProps = {
    data: tactics,
    onRowClick: handleRowClick,
  };

  return { 
    tableProps, 
    tactics, 
    isLoading, 
    error,
    tacticTypeIds,
    setTacticTypeIds,
    statusCodes,
    setStatusCodes,
    requesterUserIds,
    setRequesterUserIds,
    searchTerm,
    setSearchTerm,
    clearFilters,
    // Pagination state and handlers
    page: paginationState.page,
    pageSize: paginationState.pageSize,
    totalCount: paginationState.totalCount,
    totalPages: paginationState.totalPages,
    sortBy: paginationState.sortBy,
    sortOrder: paginationState.sortOrder,
    handlePageChange,
    handlePageSizeChange,
    handleSortChange,
    tableRef,
  };
}
