import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button, TacticTable, TacticTypeFilter, StatusFilter, RequesterFilter, SkipLinks, TopPaginationBar, BottomPaginationBar } from "@coupon-builder/ui";
import { useTacticTable } from "./hooks/use-tactic-table";
import { LandingTestIds } from "./Landing.testids";
import referenceApi from "../../shared/apis/reference-api";
import { useUser } from "../../shared/hooks/use-user";
import { getOpCoRequesters } from "../../shared/apis/user-api";

function TacticList() {
  const navigate = useNavigate();
  const user = useUser();
  const { 
    tableProps, 
    isLoading,
    tacticTypeIds, 
    setTacticTypeIds,
    statusCodes,
    setStatusCodes,
    requesterUserIds,
    setRequesterUserIds,
    searchTerm, 
    setSearchTerm, 
    clearFilters,
    // Pagination state and handlers
    page,
    pageSize,
    totalCount,
    totalPages,
    handlePageChange,
    handlePageSizeChange,
    // Sort state and handlers
    sortBy,
    sortOrder,
    handleSortChange,
    tableRef,
  } = useTacticTable();

  const isRequester = user?.roles?.some(
    (role) => role.toLowerCase() === "requester"
  ) ?? false;

  // Keyboard navigation state
  const [focusedRowIndex, setFocusedRowIndex] = useState<number>(-1);
  const tableContainerRef = useRef<HTMLDivElement>(null);

  // Get filtered tactics from tableProps
  const filteredTactics = tableProps.data || [];

  // Keyboard navigation handlers
  const handleTableKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      const newIndex = focusedRowIndex === -1 ? 0 : Math.min(focusedRowIndex + 1, filteredTactics.length - 1);
      setFocusedRowIndex(newIndex);
      scrollRowIntoView(newIndex);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      const newIndex = Math.max(focusedRowIndex - 1, 0);
      setFocusedRowIndex(newIndex);
      scrollRowIntoView(newIndex);
    } else if (e.key === 'Enter' && focusedRowIndex >= 0) {
      const tactic = filteredTactics[focusedRowIndex];
      if (tactic && 'id' in tactic) {
        navigate(`/tactic/${tactic.id}`);
      }
    } else if (e.key === 'Escape') {
      setFocusedRowIndex(-1);
    }
  };

  const scrollRowIntoView = (index: number) => {
    const row = document.querySelector(`[data-row-index="${index}"]`);
    row?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  };

  const handleClickOutside = (e: MouseEvent) => {
    if (tableContainerRef.current && !tableContainerRef.current.contains(e.target as Node)) {
      setFocusedRowIndex(-1);
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div className="min-h-screen">
      <SkipLinks 
        links={[
          { 
            href: "#main-content", 
            label: "Skip to Content",
            testId: "skip-to-content"
          }
        ]} 
      />
      <div className="max-w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header Section */}
        <div className="mb-6">
          <h1
            className="text-2xl font-semibold text-gray-900 mb-1"
            data-testid={LandingTestIds.Header.Title}
          >
            Tactic Management
          </h1>
          <p
            className="text-sm text-gray-600"
            data-testid={LandingTestIds.Header.Subtitle}
          >
            Manage your promotional campaign tactics
          </p>
        </div>

        {/* Action Bar */}
        <div className="mb-6 flex justify-between items-center">
          <div className="text-sm text-gray-600">
            {/* Placeholder for tactic count - can be populated later */}
          </div>
          <Button
            variant="primary"
            size="md"
            onClick={() => navigate("/tactic/create")}
            data-testid={LandingTestIds.Header.CreateButton}
          >
            + New Tactic
          </Button>
        </div>

        {/* Filter Bar */}
        <div className="sticky top-0 z-10 mb-6">
          <div 
            className="bg-white rounded-lg shadow p-4"
            data-testid="filter-bar"
          >
          <div className="flex flex-wrap gap-4 items-end">
            {/* Search Input */}
            <div className="flex-1 min-w-[200px]">
              <label 
                htmlFor="search-input" 
                className="block text-sm font-medium text-gray-700 mb-1"
              >
                Search
              </label>
              <input
                id="search-input"
                type="text"
                placeholder="Search tactics..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            {/* Tactic Type Filter */}
            <div className="flex-1 min-w-[200px]">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Tactic Type
              </label>
              <TacticTypeFilter
                value={tacticTypeIds}
                onChange={setTacticTypeIds}
                fetchTacticTypes={async () => {
                  const types = await referenceApi.getTacticDistMethods();
                  return types.map(t => ({ id: t.id, name: t.name }));
                }}
                testId="tactic-type-filter"
              />
            </div>

            {/* Status Filter */}
            <div className="flex-1 min-w-[200px]">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Status
              </label>
              <StatusFilter
                value={statusCodes}
                onChange={setStatusCodes}
                fetchStatuses={referenceApi.getTacticStatuses}
                testId="status-filter"
              />
            </div>

            {/* Requester Filter - Only visible to Requester role */}
            {isRequester && (
              <div className="flex-1 min-w-[200px]">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Requester
                </label>
                <RequesterFilter
                  value={requesterUserIds}
                  onChange={setRequesterUserIds}
                  fetchRequesters={getOpCoRequesters}
                  testId="requester-filter"
                />
              </div>
            )}

            {/* Clear Filters Button */}
            <div>
              <Button
                variant="secondary"
                size="md"
                onClick={clearFilters}
                disabled={tacticTypeIds.length === 0 && statusCodes.length === 0 && requesterUserIds.length === 0 && searchTerm === ""}
              >
                Clear Filters
              </Button>
            </div>
          </div>
          </div>
        </div>

        {/* Top Pagination Bar */}
        <TopPaginationBar
          page={page}
          pageSize={pageSize}
          totalCount={totalCount}
          totalPages={totalPages}
          onPageChange={handlePageChange}
          onPageSizeChange={handlePageSizeChange}
          isLoading={isLoading}
        />

        {/* Table Section */}
        <div
          ref={tableRef}
          id="main-content"
          tabIndex={0}
          role="region"
          aria-label="Tactic search results"
          onKeyDown={handleTableKeyDown}
          className="bg-white rounded-lg shadow overflow-y-scroll max-h-[calc(100vh-300px)] focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-inset focus:bg-blue-50/30 transition-all duration-200 [&::-webkit-scrollbar]:w-3 [&::-webkit-scrollbar-track]:bg-gray-100 [&::-webkit-scrollbar-thumb]:bg-gray-400 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:border-2 [&::-webkit-scrollbar-thumb]:border-gray-100 hover:[&::-webkit-scrollbar-thumb]:bg-gray-500"
          data-testid={LandingTestIds.Table.Root}
        >
          <TacticTable 
            {...tableProps} 
            isLoading={isLoading}
            testId={LandingTestIds.Table.Root}
            focusedRowIndex={focusedRowIndex}
            onSortChange={handleSortChange}
            sortBy={sortBy}
            sortOrder={sortOrder}
          />
        </div>

        {/* Bottom Pagination Bar */}
        <BottomPaginationBar
          page={page}
          pageSize={pageSize}
          totalCount={totalCount}
          totalPages={totalPages}
          onPageChange={handlePageChange}
          isLoading={isLoading}
        />

        {/* Status announcer for screen readers */}
        <div 
          role="status" 
          aria-live="polite" 
          aria-atomic="true"
          className="sr-only"
        >
          {isLoading && "Loading tactics..."}
          {!isLoading && totalCount > 0 && `Loaded ${totalCount} tactics. Viewing page ${page} of ${totalPages}.`}
          {!isLoading && totalCount === 0 && "No tactics found."}
        </div>
      </div>
    </div>
  );
}

export default TacticList;
