using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using TacticManagement.Application.Common.Extensions;
using TacticManagement.Application.Common.Interfaces;
using TacticManagement.Application.Common.Models;
using TacticManagement.Domain.Models;
using TacticManagement.Domain.Exceptions;
using TacticManagement.Application.Interfaces;
using TacticManagement.Infrastructure.Data;
using TacticManagement.Infrastructure.Repositories.Filters;
using TacticManagement.Infrastructure.Repositories.Sorting;
using TacticStatus = TacticManagement.Domain.Enums.TacticStatusEnum;

namespace TacticManagement.Infrastructure.Repositories
{
    public class TacticRepository : ITacticRepository
    {
        private readonly TacticDbContext _dbContext;
        private readonly ITacticReadAuthorizationService? _authService;
        private readonly TacticFilterStrategyFactory? _filterFactory;
        private readonly TacticSortStrategyFactory? _sortFactory;

        public TacticRepository(TacticDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public TacticRepository(TacticDbContext dbContext, ITacticReadAuthorizationService authService)
        {
            _dbContext = dbContext;
            _authService = authService;
        }

        public TacticRepository(
            TacticDbContext dbContext,
            ITacticReadAuthorizationService authService,
            TacticFilterStrategyFactory filterFactory,
            TacticSortStrategyFactory sortFactory)
        {
            _dbContext = dbContext;
            _authService = authService;
            _filterFactory = filterFactory;
            _sortFactory = sortFactory;
        }

        public async Task<Tactic?> GetByIdAsync(Guid id, CancellationToken cancellationToken)
        {
            return await _dbContext.Tactics
                .FirstOrDefaultAsync(t => t.Id == id, cancellationToken);
        }

        public async Task<Tactic?> GetByIdWithNavigationPropertiesAsync(Guid id, CancellationToken cancellationToken)
        {
            return await _dbContext.Tactics
                .Include(t => t.Status)
                .Include(t => t.Allocations)
                .Include(t => t.TacticType)
                .FirstOrDefaultAsync(t => t.Id == id, cancellationToken);
        }

        /// <summary>
        /// Applies authorization-required includes to a query based on user context.
        /// Calls the authorization service to determine which navigation properties need to be loaded.
        /// </summary>
        /// <param name="query">The base query to apply includes to</param>
        /// <param name="userId">The user ID requesting access</param>
        /// <param name="userContext">The user's context including roles and OpCo assignments</param>
        /// <param name="correlationId">Correlation ID for request tracing</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Query with authorization-required includes applied</returns>
        public async Task<IQueryable<Tactic>> ApplyAuthorizationIncludesAsync(
            IQueryable<Tactic> query,
            string userId,
            UserContext? userContext,
            string correlationId,
            CancellationToken cancellationToken)
        {
            if (_authService == null)
            {
                throw new InvalidOperationException(
                    "TacticReadAuthorizationService is required for ApplyAuthorizationIncludesAsync. " +
                    "Use the constructor that accepts ITacticReadAuthorizationService.");
            }

            var requiredIncludes = await _authService.GetRequiredIncludesAsync(
                userId,
                userContext,
                correlationId,
                cancellationToken);

            var queryWithIncludes = query;
            foreach (var includePath in requiredIncludes)
            {
                queryWithIncludes = queryWithIncludes.Include(includePath);
            }

            return queryWithIncludes;
        }

        public async Task<List<Tactic>> GetUserTacticsAsync(
            string userId,
            string? searchTerm,
            TacticStatus? status,
            List<int>? tacticTypeIds,
            List<string>? statusCodes,
            int? userIdFilter,
            int pageNumber,
            int pageSize,
            string sortBy,
            string sortOrder,
            CancellationToken cancellationToken)
        {
            var query = _dbContext.Tactics
                .Include(t => t.Status)
                .Include(t => t.TacticType)
                .Include(t => t.ProductRows)
                    .ThenInclude(pr => pr.BrandNavigation)
                .Include(t => t.DigitalProvider)
                .Include(t => t.CreativeAgency)
                .Include(t => t.Printer)
                .Where(t => t.OwnerId == userId || t.RequesterId == userId);

            if (status.HasValue)
            {
                query = query.Where(t => t.StatusId == (int)status);
            }

            if (tacticTypeIds != null && tacticTypeIds.Any())
            {
                query = query.Where(t => tacticTypeIds.Contains(t.TacticTypeId));
            }

            if (statusCodes != null && statusCodes.Any())
            {
                // Convert status code strings to TacticStatus enum values
                var statusEnums = statusCodes
                    .Select(code => Enum.TryParse<TacticStatus>(code, out var status) ? status : (TacticStatus?)null)
                    .Where(s => s.HasValue)
                    .Select(s => s!.Value)
                    .ToList();
                
                if (statusEnums.Any())
                {
                    var statusIds = statusEnums.Select(s => (int)s).ToList();
                    query = query.Where(t => statusIds.Contains(t.StatusId));
                }
            }

            if (userIdFilter.HasValue)
            {
                // Note: userIdFilter is an int but OwnerId/RequesterId are strings
                // This filter would need to be implemented based on actual user ID mapping
                // For now, this is a placeholder that needs business logic clarification
                var userIdString = userIdFilter.Value.ToString();
                query = query.Where(t => t.OwnerId == userIdString || t.RequesterId == userIdString);
            }

            if (!string.IsNullOrEmpty(searchTerm))
            {
                // Check if searchTerm is a valid integer for OfferCode exact match
                var isOfferCode = int.TryParse(searchTerm, out var offerCodeValue);
                
#pragma warning disable CS8602 // Dereference of a possibly null reference - false positive, null check protects Contains call
                query = query.Where(t => 
                    (isOfferCode && t.OfferCode == offerCodeValue) ||
                    (t.Description != null && t.Description.Contains(searchTerm)) || 
                    (t.Notes != null && t.Notes.Contains(searchTerm)) ||
                    (t.OfferVerbiage != null && t.OfferVerbiage.Contains(searchTerm)) ||
                    (t.DigitalProvider != null && t.DigitalProvider.Name.Contains(searchTerm)) ||
                    t.ProductRows.Any(pr => pr.Brand != null && pr.Brand.Contains(searchTerm)));
#pragma warning restore CS8602
            }

            // Apply sorting
            query = ApplySorting(query, sortBy, sortOrder);

            return await query
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync(cancellationToken);
        }

        public async Task<List<Tactic>> GetUserTacticsWithFiltersAsync(
            List<Expression<Func<Tactic, bool>>> roleFilters,
            string? searchTerm,
            TacticStatus? status,
            List<int>? tacticTypeIds,
            List<string>? statusCodes,
            int pageNumber,
            int pageSize,
            string sortBy,
            string sortOrder,
            CancellationToken cancellationToken)
        {
            var query = _dbContext.Tactics
                .Include(t => t.Status)
                .Include(t => t.TacticType)
                .Include(t => t.ProductRows)
                    .ThenInclude(pr => pr.BrandNavigation)
                .Include(t => t.DigitalProvider)
                .Include(t => t.CreativeAgency)
                .Include(t => t.Printer)
                .AsQueryable();

            // Combine role filters with OR logic
            if (roleFilters != null && roleFilters.Any())
            {
                var combinedFilter = roleFilters.Aggregate(
                    (Expression<Func<Tactic, bool>>)(t => false),
                    (acc, filter) => acc.Or(filter));
                query = query.Where(combinedFilter);
            }

            // Apply status filter
            if (status.HasValue)
            {
                query = query.Where(t => t.StatusId == (int)status);
            }

            // Apply tactic type filter
            if (tacticTypeIds != null && tacticTypeIds.Any())
            {
                query = query.Where(t => tacticTypeIds.Contains(t.TacticTypeId));
            }

            // Apply status codes filter
            if (statusCodes != null && statusCodes.Any())
            {
                // Convert status code strings to TacticStatus enum values
                var statusEnums = statusCodes
                    .Select(code => Enum.TryParse<TacticStatus>(code, out var status) ? status : (TacticStatus?)null)
                    .Where(s => s.HasValue)
                    .Select(s => s!.Value)
                    .ToList();
                
                if (statusEnums.Any())
                {
                    var statusIds = statusEnums.Select(s => (int)s).ToList();
                    query = query.Where(t => statusIds.Contains(t.StatusId));
                }
            }

            // Apply search term
            if (!string.IsNullOrEmpty(searchTerm))
            {
                // Check if searchTerm is a valid integer for OfferCode exact match
                var isOfferCode = int.TryParse(searchTerm, out var offerCodeValue);
                
#pragma warning disable CS8602 // Dereference of a possibly null reference - false positive, null check protects Contains call
                query = query.Where(t => 
                    (isOfferCode && t.OfferCode == offerCodeValue) ||
                    (t.Description != null && t.Description.Contains(searchTerm)) || 
                    (t.Notes != null && t.Notes.Contains(searchTerm)) ||
                    (t.OfferVerbiage != null && t.OfferVerbiage.Contains(searchTerm)) ||
                    (t.DigitalProvider != null && t.DigitalProvider.Name.Contains(searchTerm)) ||
                    t.ProductRows.Any(pr => pr.Brand != null && pr.Brand.Contains(searchTerm)));
#pragma warning restore CS8602
            }

            // Apply sorting
            query = ApplySorting(query, sortBy, sortOrder);

            return await query
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync(cancellationToken);
        }

        public async Task<int> GetUserTacticsWithFiltersCountAsync(
            List<Expression<Func<Tactic, bool>>> roleFilters,
            string? searchTerm,
            TacticStatus? status,
            List<int>? tacticTypeIds,
            List<string>? statusCodes,
            CancellationToken cancellationToken)
        {
            var query = _dbContext.Tactics.AsQueryable();

            // Combine role filters with OR logic
            if (roleFilters != null && roleFilters.Any())
            {
                var combinedFilter = roleFilters.Aggregate(
                    (Expression<Func<Tactic, bool>>)(t => false),
                    (acc, filter) => acc.Or(filter));
                query = query.Where(combinedFilter);
            }

            // Apply status filter
            if (status.HasValue)
            {
                query = query.Where(t => t.StatusId == (int)status);
            }

            // Apply tactic type filter
            if (tacticTypeIds != null && tacticTypeIds.Any())
            {
                query = query.Where(t => tacticTypeIds.Contains(t.TacticTypeId));
            }

            // Apply status codes filter
            if (statusCodes != null && statusCodes.Any())
            {
                var statusEnums = statusCodes
                    .Select(code => Enum.TryParse<TacticStatus>(code, out var status) ? status : (TacticStatus?)null)
                    .Where(s => s.HasValue)
                    .Select(s => s!.Value)
                    .ToList();
                
                if (statusEnums.Any())
                {
                    var statusIds = statusEnums.Select(s => (int)s).ToList();
                    query = query.Where(t => statusIds.Contains(t.StatusId));
                }
            }

            // Apply search term
            if (!string.IsNullOrEmpty(searchTerm))
            {
                var isOfferCode = int.TryParse(searchTerm, out var offerCodeValue);
                
#pragma warning disable CS8602
                query = query.Where(t => 
                    (isOfferCode && t.OfferCode == offerCodeValue) ||
                    (t.Description != null && t.Description.Contains(searchTerm)) || 
                    (t.Notes != null && t.Notes.Contains(searchTerm)) ||
                    (t.OfferVerbiage != null && t.OfferVerbiage.Contains(searchTerm)) ||
                    (t.DigitalProvider != null && t.DigitalProvider.Name.Contains(searchTerm)) ||
                    t.ProductRows.Any(pr => pr.Brand != null && pr.Brand.Contains(searchTerm)));
#pragma warning restore CS8602
            }

            return await query.CountAsync(cancellationToken);
        }

        // Used by Admin role only (sees all tactics without filtering)
        // Other roles use GetUserTacticsWithFiltersAsync for entity-based authorization
        public async Task<List<Tactic>> GetAllTacticsAsync(
            string? searchTerm,
            TacticStatus? status,
            List<int>? tacticTypeIds,
            List<string>? statusCodes,
            int pageNumber,
            int pageSize,
            string sortBy,
            string sortOrder,
            CancellationToken cancellationToken)
        {
            var query = _dbContext.Tactics
                .Include(t => t.Status)
                .Include(t => t.TacticType)
                .Include(t => t.ProductRows)
                    .ThenInclude(pr => pr.BrandNavigation)
                .Include(t => t.DigitalProvider)
                .Include(t => t.CreativeAgency)
                .Include(t => t.Printer)
                .AsQueryable();

            if (status.HasValue)
            {
                query = query.Where(t => t.StatusId == (int)status);
            }

            if (tacticTypeIds != null && tacticTypeIds.Any())
            {
                query = query.Where(t => tacticTypeIds.Contains(t.TacticTypeId));
            }

            if (statusCodes != null && statusCodes.Any())
            {
                // Convert status code strings to TacticStatus enum values
                var statusEnums = statusCodes
                    .Select(code => Enum.TryParse<TacticStatus>(code, out var status) ? status : (TacticStatus?)null)
                    .Where(s => s.HasValue)
                    .Select(s => s!.Value)
                    .ToList();
                
                if (statusEnums.Any())
                {
                    var statusIds = statusEnums.Select(s => (int)s).ToList();
                    query = query.Where(t => statusIds.Contains(t.StatusId));
                }
            }

            if (!string.IsNullOrEmpty(searchTerm))
            {
                // Check if searchTerm is a valid integer for OfferCode exact match
                var isOfferCode = int.TryParse(searchTerm, out var offerCodeValue);
                
#pragma warning disable CS8602 // Dereference of a possibly null reference - false positive, null check protects Contains call
                query = query.Where(t => 
                    (isOfferCode && t.OfferCode == offerCodeValue) ||
                    (t.Description != null && t.Description.Contains(searchTerm)) || 
                    (t.Notes != null && t.Notes.Contains(searchTerm)) ||
                    (t.OfferVerbiage != null && t.OfferVerbiage.Contains(searchTerm)) ||
                    (t.DigitalProvider != null && t.DigitalProvider.Name.Contains(searchTerm)) ||
                    t.ProductRows.Any(pr => pr.Brand != null && pr.Brand.Contains(searchTerm)));
#pragma warning restore CS8602
            }

            // Apply sorting
            query = ApplySorting(query, sortBy, sortOrder);

            return await query
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync(cancellationToken);
        }

        public async Task<int> GetAllTacticsCountAsync(
            string? searchTerm,
            TacticStatus? status,
            List<int>? tacticTypeIds,
            List<string>? statusCodes,
            CancellationToken cancellationToken)
        {
            var query = _dbContext.Tactics.AsQueryable();

            if (status.HasValue)
            {
                query = query.Where(t => t.StatusId == (int)status);
            }

            if (tacticTypeIds != null && tacticTypeIds.Any())
            {
                query = query.Where(t => tacticTypeIds.Contains(t.TacticTypeId));
            }

            if (statusCodes != null && statusCodes.Any())
            {
                var statusEnums = statusCodes
                    .Select(code => Enum.TryParse<TacticStatus>(code, out var status) ? status : (TacticStatus?)null)
                    .Where(s => s.HasValue)
                    .Select(s => s!.Value)
                    .ToList();
                
                if (statusEnums.Any())
                {
                    var statusIds = statusEnums.Select(s => (int)s).ToList();
                    query = query.Where(t => statusIds.Contains(t.StatusId));
                }
            }

            if (!string.IsNullOrEmpty(searchTerm))
            {
                var isOfferCode = int.TryParse(searchTerm, out var offerCodeValue);
                
#pragma warning disable CS8602
                query = query.Where(t => 
                    (isOfferCode && t.OfferCode == offerCodeValue) ||
                    (t.Description != null && t.Description.Contains(searchTerm)) || 
                    (t.Notes != null && t.Notes.Contains(searchTerm)) ||
                    (t.OfferVerbiage != null && t.OfferVerbiage.Contains(searchTerm)) ||
                    (t.DigitalProvider != null && t.DigitalProvider.Name.Contains(searchTerm)) ||
                    t.ProductRows.Any(pr => pr.Brand != null && pr.Brand.Contains(searchTerm)));
#pragma warning restore CS8602
            }

            return await query.CountAsync(cancellationToken);
        }

        public async Task<Tactic> AddAsync(Tactic tactic, CancellationToken cancellationToken)
        {
            try
            {
                await _dbContext.AddAsync(tactic, cancellationToken);
                await _dbContext.SaveChangesAsync(cancellationToken);
                return tactic;
            }
            catch (DbUpdateException ex) when (IsUniqueConstraintViolation(ex))
            {
                // Translate infrastructure exception to domain exception
                throw new DuplicateOfferCodeException(tactic.OfferCode, ex);
            }
        }

        private static bool IsUniqueConstraintViolation(DbUpdateException ex)
        {
            // Check if the inner exception is a SQL unique constraint violation
            return ex.InnerException is SqlException sqlEx &&
                   (sqlEx.Number == 2627 || sqlEx.Number == 2601); // Unique constraint violation codes
        }

        public async Task UpdateAsync(Tactic tactic, CancellationToken cancellationToken)
        {
            _dbContext.Update(tactic);
            await _dbContext.SaveChangesAsync(cancellationToken);
        }

        public async Task UpdateStatusAsync(Guid tacticId, TacticStatus newStatus, DateTime lastModified, CancellationToken cancellationToken)
        {
            var tactic = await _dbContext.Tactics.FindAsync(new object[] { tacticId }, cancellationToken);
            if (tactic == null)
            {
                throw new KeyNotFoundException($"Tactic with ID {tacticId} not found");
            }

            // Surgical update - only modify StatusId and LastModified
            tactic.StatusId = (int)newStatus;
            tactic.LastModified = lastModified;

            // EF Core will only track these two properties as modified
            await _dbContext.SaveChangesAsync(cancellationToken);
        }

        public async Task UpdateStatusAsync(Guid tacticId, TacticStatus newStatus, DateTime lastModified, string lastModifiedBy, CancellationToken cancellationToken)
        {
            var tactic = await _dbContext.Tactics.FindAsync(new object[] { tacticId }, cancellationToken);
            if (tactic == null)
            {
                throw new KeyNotFoundException($"Tactic with ID {tacticId} not found");
            }

            // Surgical update - only modify StatusId, LastModified, and LastModifiedBy
            tactic.StatusId = (int)newStatus;
            tactic.LastModified = lastModified;
            tactic.LastModifiedBy = lastModifiedBy;

            // EF Core will only track these three properties as modified
            await _dbContext.SaveChangesAsync(cancellationToken);
        }

        public async Task UpdateTacticDatesAndStatusAsync(Guid tacticId, DateTime startDate, DateTime endDate, DateTime expiryDate, TacticStatus newStatus, DateTime lastModified, string lastModifiedBy, CancellationToken cancellationToken)
        {
            var tactic = await _dbContext.Tactics.FindAsync(new object[] { tacticId }, cancellationToken);
            if (tactic == null)
            {
                throw new KeyNotFoundException($"Tactic with ID {tacticId} not found");
            }

            // Update dates, status, and metadata
            tactic.StartDate = startDate;
            tactic.EndDate = endDate;
            tactic.ExpiryDate = expiryDate;
            tactic.StatusId = (int)newStatus;
            tactic.LastModified = lastModified;
            tactic.LastModifiedBy = lastModifiedBy;

            await _dbContext.SaveChangesAsync(cancellationToken);
        }

        public async Task<IEnumerable<Tactic>> GetTacticsAwaitingStartByDateAsync(DateTime startDate, CancellationToken cancellationToken)
        {
            var startDateOnly = startDate.Date;
            
            return await _dbContext.Tactics
                .Where(t => t.StatusId == (int)TacticStatus.AWAITING_START 
                         && t.StartDate.Date == startDateOnly)
                .ToListAsync(cancellationToken);
        }

        public async Task<IEnumerable<Tactic>> GetTacticsAwaitingStartByDateRangeAsync(DateTime fromDate, DateTime toDate, CancellationToken cancellationToken)
        {
            var fromDateOnly = fromDate.Date;
            var toDateOnly = toDate.Date;
            
            return await _dbContext.Tactics
                .Where(t => t.StatusId == (int)TacticStatus.AWAITING_START 
                         && t.StartDate.Date >= fromDateOnly
                         && t.StartDate.Date <= toDateOnly)
                .ToListAsync(cancellationToken);
        }

        public async Task<IEnumerable<Tactic>> GetTacticsLiveByEndDateAsync(DateTime currentDate, CancellationToken cancellationToken)
        {
            var currentDateOnly = currentDate.Date;
            
            return await _dbContext.Tactics
                .Where(t => t.StatusId == (int)TacticStatus.LIVE 
                         && t.EndDate.Date < currentDateOnly)
                .ToListAsync(cancellationToken);
        }

        public async Task<IEnumerable<Tactic>> GetTacticsLiveByEndDateRangeAsync(DateTime fromDate, DateTime toDate, CancellationToken cancellationToken)
        {
            var fromDateOnly = fromDate.Date;
            var toDateOnly = toDate.Date;
            
            return await _dbContext.Tactics
                .Where(t => t.StatusId == (int)TacticStatus.LIVE 
                         && t.EndDate.Date >= fromDateOnly
                         && t.EndDate.Date < toDateOnly)
                .ToListAsync(cancellationToken);
        }

        public async Task<IEnumerable<Tactic>> GetTacticsReadyForExpiredTransitionAsync(DateTime currentDate, CancellationToken cancellationToken)
        {
            var currentDateOnly = currentDate.Date;
            
            // Check tactics in AWAITING_START, LIVE, or COMPLETED that have passed their expiry date
            return await _dbContext.Tactics
                .Where(t => (t.StatusId == (int)TacticStatus.AWAITING_START 
                          || t.StatusId == (int)TacticStatus.LIVE 
                          || t.StatusId == (int)TacticStatus.COMPLETED)
                         && t.ExpiryDate.Date < currentDateOnly)
                .ToListAsync(cancellationToken);
        }

        public async Task<IEnumerable<Tactic>> GetTacticsReadyForExpiredTransitionByDateRangeAsync(DateTime fromDate, DateTime toDate, CancellationToken cancellationToken)
        {
            var fromDateOnly = fromDate.Date;
            var toDateOnly = toDate.Date;
            
            // Check tactics in AWAITING_START, LIVE, or COMPLETED that have passed their expiry date within the range
            return await _dbContext.Tactics
                .Where(t => (t.StatusId == (int)TacticStatus.AWAITING_START 
                          || t.StatusId == (int)TacticStatus.LIVE 
                          || t.StatusId == (int)TacticStatus.COMPLETED)
                         && t.ExpiryDate.Date >= fromDateOnly
                         && t.ExpiryDate.Date < toDateOnly)
                .ToListAsync(cancellationToken);
        }

        /// <summary>
        /// Applies sorting to a tactic query based on the specified sort column and order.
        /// For status sorting, uses the StatusProgressionOrder dictionary to sort by workflow progression.
        /// </summary>
        /// <param name="query">The query to apply sorting to</param>
        /// <param name="sortBy">The column to sort by (e.g., "status", "tacticName", "startDate")</param>
        /// <param name="sortOrder">The sort direction ("asc" or "desc")</param>
        /// <returns>The query with sorting applied</returns>
        private IQueryable<Tactic> ApplySorting(IQueryable<Tactic> query, string sortBy, string sortOrder)
        {
            if (string.IsNullOrEmpty(sortBy))
            {
                return query;
            }

            var isDescending = sortOrder?.ToLower() == "desc";

            return sortBy.ToLower() switch
            {
                "status" => isDescending
                    ? query.OrderByDescending(t => t.Status.DisplayOrder)
                    : query.OrderBy(t => t.Status.DisplayOrder),
                
                "description" => isDescending
                    ? query.OrderByDescending(t => t.Description)
                    : query.OrderBy(t => t.Description),
                
                "tacticname" => isDescending
                    ? query.OrderByDescending(t => t.Description)
                    : query.OrderBy(t => t.Description),
                
                "campaignstartdate" => isDescending
                    ? query.OrderByDescending(t => t.StartDate)
                    : query.OrderBy(t => t.StartDate),
                
                "startdate" => isDescending
                    ? query.OrderByDescending(t => t.StartDate)
                    : query.OrderBy(t => t.StartDate),
                
                "campaignenddate" => isDescending
                    ? query.OrderByDescending(t => t.EndDate)
                    : query.OrderBy(t => t.EndDate),
                
                "enddate" => isDescending
                    ? query.OrderByDescending(t => t.EndDate)
                    : query.OrderBy(t => t.EndDate),
                
                "lastmodified" => isDescending
                    ? query.OrderByDescending(t => t.LastModified)
                    : query.OrderBy(t => t.LastModified),
                
                "createddate" => isDescending
                    ? query.OrderByDescending(t => t.CreatedDate)
                    : query.OrderBy(t => t.CreatedDate),
                
                "tactictypename" => isDescending
                    ? query.OrderByDescending(t => t.TacticType.Name)
                    : query.OrderBy(t => t.TacticType.Name),
                
                "offerverbiage" => isDescending
                    ? query.OrderByDescending(t => t.OfferVerbiage)
                    : query.OrderBy(t => t.OfferVerbiage),
                
                "offercode" => isDescending
                    ? query.OrderByDescending(t => t.OfferCode)
                    : query.OrderBy(t => t.OfferCode),
                
                // Note: "brand" and "vendors" cannot be sorted server-side as they are 
                // aggregated/computed fields in the application layer (not direct DB columns)
                
                _ => query // Default: no sorting if column not recognized
            };
        }

        public async Task<List<Tactic>> HydrateTacticsAsync(List<Guid> tacticIds, CancellationToken cancellationToken)
        {
            if (tacticIds == null || !tacticIds.Any())
            {
                return new List<Tactic>();
            }

            // Load tactics with all navigation properties
            // Use AsNoTracking for read-only queries
            var tactics = await _dbContext.Tactics
                .AsNoTracking()
                .Include(t => t.Status)
                .Include(t => t.TacticType)
                .Include(t => t.ProductRows)
                .Include(t => t.DigitalProvider)
                .Include(t => t.CreativeAgency)
                .Include(t => t.Printer)
                .Where(t => tacticIds.Contains(t.Id))
                .ToListAsync(cancellationToken);

            // Preserve the order of input IDs
            var orderedTactics = new List<Tactic>();
            foreach (var id in tacticIds)
            {
                var tactic = tactics.FirstOrDefault(t => t.Id == id);
                if (tactic != null)
                {
                    orderedTactics.Add(tactic);
                }
            }

            return orderedTactics;
        }

        public async Task<PaginatedResult<Tactic>> GetTacticsAsync(
            object filterCriteriaObj,
            object sortCriteriaObj,
            int pageNumber,
            int pageSize,
            CancellationToken cancellationToken)
        {
            if (_filterFactory == null || _sortFactory == null)
            {
                throw new InvalidOperationException(
                    "TacticFilterStrategyFactory and TacticSortStrategyFactory are required for GetTacticsAsync. " +
                    "Use the constructor that accepts both factories.");
            }

            var filterCriteria = (TacticFilterCriteria)filterCriteriaObj;
            var sortCriteria = (TacticSortCriteria)sortCriteriaObj;

            // Phase 1: Build filter query (no navigation properties loaded)
            var baseQuery = _dbContext.Tactics.AsNoTracking();
            var filteredQuery = _filterFactory.Apply(baseQuery, filterCriteria);

            // Phase 2: Get total count for pagination metadata
            var totalCount = await filteredQuery.CountAsync(cancellationToken);

            // Calculate pagination metadata
            var totalPages = totalCount > 0 ? (int)Math.Ceiling(totalCount / (double)pageSize) : 0;

            // Phase 3: Apply sorting
            var sortedQuery = _sortFactory.Apply(filteredQuery, sortCriteria);

            // Phase 4: Apply pagination and get IDs only
            var tacticIds = await sortedQuery
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .Select(t => t.Id)
                .ToListAsync(cancellationToken);

            // Phase 5: Hydrate full entities with navigation properties (preserves order)
            var tactics = await HydrateTacticsAsync(tacticIds, cancellationToken);

            // Return paginated result
            return new PaginatedResult<Tactic>
            {
                Items = tactics,
                TotalCount = totalCount,
                TotalPages = totalPages,
                CurrentPage = pageNumber,
                PageSize = pageSize
            };
        }
    }
}
