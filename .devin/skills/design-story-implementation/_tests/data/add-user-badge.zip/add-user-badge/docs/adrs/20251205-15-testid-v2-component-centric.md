# 20251205-10. TestID v2.0 Component-Centric Pattern

Date: 2025-12-05

## Status

Accepted

## Context

### Problem

The v1.0 testId system has proven problematic during E2E test development and maintenance:

1. **Deep Nesting**: TestIds are excessively verbose (50+ characters)
   - Example: `create-form-root-offer-details-field-productsAtPos-input` (58 chars)
   - Hard to read, error-prone to type, difficult to maintain

2. **Page-Specific Duplication**: Same component has different testIds on different pages
   - Create page: `create-form-root-offer-details-field-productsAtPos-input`
   - Details page: `details-form-root-offer-details-field-productsAtPos-input`
   - E2E tests must handle both variations, creating maintenance burden

3. **Composition Complexity**: Multiple layers of prefix composition
   - Page prefix → Card prefix → Field prefix → Element suffix
   - Hard to predict final testId
   - E2E tests require manual composition logic

4. **Mismatch Between Expected and Actual**: Tests fail due to testId mismatches
   - E2E expects one pattern, component renders another
   - FormField auto-composition adds unexpected prefixes
   - Drawer composition not consistent

5. **Brittle E2E Tests**: Tests break when component hierarchy changes
   - Moving a component to different page breaks testIds
   - Refactoring component structure requires E2E updates
   - High maintenance cost

### v1.0 Architecture

```
Page TestId (e.g., "create-form-root")
  ↓
Card TestId (e.g., "create-form-root-offer-details")
  ↓
Field TestId (e.g., "create-form-root-offer-details-field-productsAtPos")
  ↓
Element TestId (e.g., "create-form-root-offer-details-field-productsAtPos-input")
```

### Proof of Concept

Successfully migrated OfferDetailsCard as PoC:
- **Before**: `create-form-root-offer-details-field-productsAtPos-input` (58 chars)
- **After**: `offer-details-card-field-productsAtPos-input` (45 chars)
- **Result**: 22% shorter, same testId on Create and Details pages
- **E2E Impact**: Direct constant references, no manual composition

## Decision

Adopt **v2.0 Component-Centric TestID Pattern** with the following principles:

### Core Principles

1. **Components Own Their TestIds**: No page-specific prefixes
   - Components define their own testIds independent of page context
   - Same component = same testId everywhere

2. **Minimal Nesting**: Maximum 2-3 levels deep
   - Component → Field → Element
   - Eliminate page-level prefix

3. **Explicit Composition**: All composition visible in component code
   - No hidden auto-composition (except FormField)
   - Clear, predictable testId structure

4. **Reusable Across Pages**: Same component = same testId everywhere
   - OfferDetailsCard uses `offer-details-card-*` on all pages
   - No `create-offer-details-*` vs `details-offer-details-*`

5. **Direct E2E References**: No manual composition in tests
   - E2E page objects use constants directly
   - Example: `OfferDetailsTestIds.ProductsAtPosInput`

### v2.0 Architecture

```
Component TestId (e.g., "offer-details-card")
  ↓
Field TestId (e.g., "offer-details-card-field-productsAtPos")
  ↓
Element TestId (e.g., "offer-details-card-field-productsAtPos-input")
```

### Implementation Pattern

#### Two Patterns Based on Component Location

**When to Use Each Pattern:**

Use **Pattern A** (Own TestIds) when:
- Component lives in application code (`apps/tactic-builder/src`)
- Component is specific to a single application context
- Component should have the same testIds regardless of where it's used
- Examples: OfferDetailsCard, TacticDetailsCard, TacticBudgetCard

Use **Pattern B** (Accept & Compose TestIds) when:
- Component lives in shared UI package (`packages/ui`)
- Component is reusable across multiple applications or contexts
- Parent needs to control the testId namespace
- Examples: CollapsibleCard, Button, StatusBadge, TacticStickyHeader

**Pattern A: Application Components** - Own their testIds
- Components define and use their own constant testIds
- Ignore any testId prop passed from parent
- Same testIds everywhere the component is used

**Pattern B: Shared UI Components** - Accept and compose testIds
- Components accept optional `testId` prop from parent
- Use function-based testIds that append suffixes to the provided base
- Parent controls the testId namespace, component appends suffixes
- TestIds are NOT exported from package index (internal use only)
- Tests import testIds directly from component source files

#### Pattern A: Application Component TestIds File

```typescript
/**
 * Test IDs for OfferDetailsCard component.
 *
 * Note: FormField components automatically append `-field-{name}-{element}`.
 * For example, if testId="offer-details-card" and name="productsAtPos":
 * - offer-details-card-field-productsAtPos-input
 * - offer-details-card-field-productsAtPos-label
 * - offer-details-card-field-productsAtPos-error
 */
export const OfferDetailsTestIds = {
  Container: "offer-details-card",
  ProductsAtPosInput: "offer-details-card-field-productsAtPos-input",
  OfferVerbiageTextarea: "offer-details-card-field-offerVerbiage-input",
  EditButton: "offer-details-card-edit-button",
  OfferVerbiageDrawer: {
    Container: "offer-details-card-offer-verbiage-drawer",
    OfferTypeInput: "offer-details-card-offer-verbiage-drawer-field-offerType-input",
    SaveButton: "offer-details-card-offer-verbiage-drawer-save-button",
  },
} as const;
```

#### Pattern A: Application Component Implementation

```typescript
export function OfferDetailsCard({
  testId, // Accepted but ignored for backward compatibility
  form,
}: Props) {
  // v2.0: Always use component's own testId, ignore prop
  const componentTestId = OfferDetailsTestIds.Container;
  
  return (
    <CollapsibleCard testId={componentTestId}>
      <FormField testId={componentTestId} name="productsAtPos" />
      <button data-testid={`${componentTestId}-edit-button`}>Edit</button>
    </CollapsibleCard>
  );
}
```

#### Pattern B: Shared UI Component TestIds File

```typescript
/**
 * Test IDs for TacticStickyHeader component.
 *
 * Component-centric pattern: Appends suffixes to provided testId.
 * Structure: {testId}-{element}
 */
export const TacticStickyHeaderTestIds = {
  container: (testId: string) => testId,
  backButton: (testId: string) => `${testId}-back-button`,
  title: (testId: string) => `${testId}-title`,
  statusBadge: (testId: string) => `${testId}-status-badge`,
  secondaryButton: (testId: string) => `${testId}-secondary-button`,
  primaryButton: (testId: string) => `${testId}-primary-button`,
  kebabMenuButton: (testId: string) => `${testId}-kebab-menu-button`,
  kebabMenu: (testId: string) => `${testId}-kebab-menu`,
} as const;
```

#### Pattern B: Shared UI Component Implementation

```typescript
export interface TacticStickyHeaderProps {
  title: string;
  status?: TacticStatus;
  // ... other props
  testId?: string; // Optional testId for composition
}

export const TacticStickyHeader: React.FC<TacticStickyHeaderProps> = ({
  title,
  status,
  // ... other props
  testId,
}) => {
  return (
    <div data-testid={testId ? TacticStickyHeaderTestIds.container(testId) : undefined}>
      <button data-testid={testId ? TacticStickyHeaderTestIds.backButton(testId) : undefined}>
        Back
      </button>
      <h1 data-testid={testId ? TacticStickyHeaderTestIds.title(testId) : undefined}>
        {title}
      </h1>
      <StatusBadge 
        status={status}
        testId={testId ? TacticStickyHeaderTestIds.statusBadge(testId) : undefined}
      />
    </div>
  );
};
```

#### Pattern B: Usage in Application

```typescript
// Parent component passes base testId
<TacticStickyHeader
  title="Edit Tactic"
  status="DRAFT"
  testId="details-header"
/>

// Rendered testIds:
// - details-header (container)
// - details-header-back-button
// - details-header-title
// - details-header-status-badge
```

#### Pattern B: E2E Tests

```typescript
// Import testIds from UI package source
import { TacticStickyHeaderTestIds } from "@coupon-builder/ui/src/.../TacticStickyHeader.testids";

// Use with base testId
const kebabButton = screen.getByTestId(
  TacticStickyHeaderTestIds.kebabMenuButton("details-header")
);
```

#### E2E Page Objects

```typescript
// Before (v1.0) - Manual composition
const testId = `${CreateTestIds.Form.Root}-offer-details-field-productsAtPos-input`;

// After (v2.0) - Direct reference
const testId = OfferDetailsTestIds.ProductsAtPosInput;
```

### Migration Strategy: Surgical Fix

**Key Principle**: Migrate one component at a time without breaking other tests.

1. **Component ignores testId prop** and uses its own constant
2. **Parent continues passing testId** for backward compatibility
3. **E2E tests updated** for migrated component only
4. **Other components** continue using v1.0 pattern
5. **Gradual rollout** with verification after each component

### FormField Auto-Composition Pattern

**Critical Note**: FormField component automatically composes testIds:

```typescript
// FormField internal implementation
<input data-testid={`${testId}-field-${name}-input`} />
<label data-testid={`${testId}-field-${name}-label`} />
<span data-testid={`${testId}-field-${name}-error`} />
```

**Pattern**: `{baseTestId}-field-{fieldName}-{element}`

**Important**: FormField ALWAYS uses `-input` suffix, regardless of HTML element type:
- Text input: `card-field-description-input` ✅
- Textarea: `card-field-notes-input` ✅ (NOT `-textarea`)
- Select: `card-field-status-input` ✅ (NOT `-select`)

## Consequences

### Positive

✅ **Shorter TestIds**: 30-50% reduction in character count
- Easier to read and type
- Less prone to typos
- Better developer experience

✅ **Consistent Across Pages**: Same component = same testId
- OfferDetailsCard uses same testIds on Create and Details pages
- Reduces E2E test complexity
- Easier to reason about

✅ **Simpler E2E Tests**: Direct constant references
- No manual composition logic
- IDE autocomplete works
- Less error-prone

✅ **More Maintainable**: Component changes don't break E2E tests
- Moving component to different page doesn't change testIds
- Refactoring component structure is safer
- Lower maintenance cost

✅ **Better Discoverability**: IDE autocomplete shows all testIds
- Type-safe with TypeScript
- Clear documentation in testIds files
- Single source of truth

✅ **Gradual Migration**: Can migrate one component at a time
- Low risk approach
- Easy to verify and rollback
- No breaking changes during migration

### Negative

⚠️ **FormField Pattern Complexity**: Must understand auto-composition
- Developers must know FormField adds `-field-{name}-{element}`
- TestId constants must match actual rendered HTML
- Requires documentation and examples
- Mitigated by: Comprehensive documentation, examples in every testIds file

⚠️ **Migration Effort**: ~28 hours to migrate all components
- 5 shared components + 3 pages
- Must update E2E page objects
- Must verify after each component
- Mitigated by: Surgical fix approach, clear migration guide

⚠️ **Breaking Change After Migration**: Removing testId props
- Final cleanup phase removes testId prop from component interfaces
- Parents must stop passing testId
- One-time breaking change
- Mitigated by: Happens after all components migrated, clear communication

⚠️ **Learning Curve**: Team must learn new pattern
- Different from v1.0 approach
- Must understand component-centric philosophy
- Requires training and documentation
- Mitigated by: Clear guidelines, examples, ADR, migration guide

### Neutral

⚪ **FormField Pattern Unchanged**: Accept existing auto-composition
- Could refactor FormField to remove "field" from pattern
- Decision: Not in scope, accept as-is
- Future enhancement if needed

⚪ **Documentation Overhead**: Must document FormField pattern in every component
- Every testIds file needs documentation comment
- Repetitive but necessary
- Ensures clarity and correctness

## Alternatives Considered

### Alternative 1: Big-Bang Migration

**Approach**: Migrate all components at once

**Rejected Because**:
- High risk of breaking all E2E tests
- Difficult to verify and debug
- Hard to rollback if issues found
- No clear progress tracking

### Alternative 2: Refactor FormField Auto-Composition

**Approach**: Remove "field" from FormField's auto-composition pattern

**Example**:
```typescript
// Current: {testId}-field-{name}-input
// Proposed: {testId}-{name}-input
```

**Benefits**:
- Shorter testIds: `offer-details-card-products-at-pos-input` (40 chars)
- Simpler pattern

**Rejected Because**:
- Requires changes to shared UI component (FormField)
- Affects all applications using the UI package
- Higher risk and broader impact
- Can be revisited as future enhancement

### Alternative 3: Keep v1.0 Pattern

**Approach**: Accept current problems, improve documentation

**Rejected Because**:
- Doesn't solve fundamental issues (deep nesting, page coupling)
- E2E tests remain brittle
- High maintenance cost continues
- PoC proved v2.0 is viable and better

## Implementation Plan

### Phase 1: Foundation & Documentation (4 hours)
- Create TEST_ID_GUIDELINES_V2.md
- Create TESTID_MIGRATION_GUIDE.md
- Create this ADR
- Update E2E_TESTING_GUIDELINES.md

### Phase 2: Shared Components (12 hours)
- Migrate OfferDetailsCard ✅ (PoC complete)
- Migrate TacticDetailsCard
- Migrate TacticBudgetCard
- Migrate TacticDesignCard
- Migrate TacticAccountingSection

### Phase 3: Page Components (8 hours)
- Migrate Create page
- Migrate Details page
- Migrate Landing page

### Phase 4: Cleanup (4 hours)
- Remove testId props from component interfaces
- Remove testId passing from parents
- Update all documentation
- Mark v1.0 docs as deprecated

**Total Effort**: ~28 hours (3.5 days)

## Verification

### Per-Component Checklist
- [ ] Component testIds file updated with v2.0 pattern
- [ ] FormField auto-composition documented
- [ ] Component ignores testId prop, uses own constant
- [ ] E2E page objects updated to use constants
- [ ] Rendered HTML matches constants (browser inspection)
- [ ] Component E2E tests pass
- [ ] Full E2E suite passes (no regressions)
- [ ] Unit tests pass

### Success Metrics
- ✅ TestIds 30-50% shorter than v1.0
- ✅ Same testIds on Create and Details pages
- ✅ Zero manual composition in E2E tests
- ✅ All E2E tests passing
- ✅ All unit tests passing
- ✅ Complete v2.0 documentation

## References

- [Story](../reqs/TestID%20Migration%20v2.0/story.md)
- [Acceptance Criteria](../reqs/TestID%20Migration%20v2.0/acceptance-criteria.md)
- [Analysis](../reqs/TestID%20Migration%20v2.0/analysis.md)
- [Implementation Plan](../reqs/TestID%20Migration%20v2.0/implementation-plan.md)
- [PoC: Lessons Learned](../reqs/07%20-%20Offer%20Details%20Card/testid_v2_lessons_learned.md)
- [PoC: Surgical Fix](../reqs/07%20-%20Offer%20Details%20Card/testid_v2_surgical_fix.md)
- [TEST_ID_GUIDELINES_V2.md](../testing/TEST_ID_GUIDELINES_V2.md) (to be created)
- [TESTID_MIGRATION_GUIDE.md](../testing/TESTID_MIGRATION_GUIDE.md) (to be created)
