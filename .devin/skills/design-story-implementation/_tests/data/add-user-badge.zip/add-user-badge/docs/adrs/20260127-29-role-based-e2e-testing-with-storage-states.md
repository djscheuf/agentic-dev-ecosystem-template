# 20260127-18. Role-Based E2E Testing with Playwright Storage States

Date: 2026-01-27

## Status

Accepted

## Context

Our E2E test suite uses Playwright to test the Tactic Builder application with multiple user roles (REQUESTER, PROOF_READER, ADMIN). Each role has different permissions and sees different UI elements based on their JWT token.

### The Problem

Initially, we attempted to test cross-role workflows by switching roles mid-test using a `switchToRole()` helper that manipulated localStorage:

```typescript
test('cross-role workflow', async ({ page }) => {
  await switchToRole(page, 'REQUESTER');
  // Create tactic as REQUESTER
  
  await switchToRole(page, 'PROOF_READER'); // FAILS
  // Approve as PROOF_READER
});
```

This approach failed because:

1. **Playwright's storage state is immutable** - Once a browser context is created with a storage state, you cannot modify localStorage in a way that persists across page reloads
2. **JWT tokens in localStorage** - Our authentication relies on JWT tokens stored in localStorage with key `tactic_builder_auth_token`
3. **Page reload required** - Changing the token requires a page reload to trigger re-authentication, but the storage state reverts to the original
4. **Race conditions** - Even when localStorage manipulation appeared to work, it created flaky tests due to timing issues

### Why This Matters

We have 48 critical integration tests that verify:
- Single-role workflows (REQUESTER creates/edits tactics)
- Multi-role workflows (REQUESTER creates → PROOF_READER approves)
- Permission-based UI rendering
- Cross-role state transitions

Without a proper solution, we cannot reliably test these critical workflows.

### Constraints

1. **JWT-based authentication** - Backend requires valid JWT tokens with role claims
2. **Multiple roles needed** - Tests must verify REQUESTER, PROOF_READER, and ADMIN behaviors
3. **Shared database** - Tests run against the same database (integration mode)
4. **Docker execution** - Tests run in Docker containers for NixOS compatibility
5. **Parallel execution** - Tests should be parallelizable for fast CI/CD

## Decision

We will restructure our E2E test suite to use **role-based test organization with Playwright storage states**, where:

1. **Each test file runs as a single role** using `test.use({ storageState: '...' })`
2. **Global setup creates multiple storage state files** (one per role)
3. **Tests use API calls to set up prerequisite workflow states**
4. **Cross-role verification happens via API calls, not UI switching**

### Architecture

#### 1. Storage State Files

Global setup (`e2e/global-setup.ts`) creates three storage state files:

```typescript
// test-results/.auth-requester.json
// test-results/.auth-proofreader.json  
// test-results/.auth-admin.json
```

Each file contains the localStorage state with the appropriate JWT token for that role.

#### 2. Role-Based Folder Structure

```
e2e/tests/
├── requester/           # Tests running as REQUESTER
│   ├── create-tactic.spec.ts
│   ├── mark-proof-ready.spec.ts
│   └── duplicate-tactic.spec.ts
├── proofreader/         # Tests running as PROOF_READER
│   ├── approve-verbiage.spec.ts
│   └── request-review.spec.ts
└── shared/              # Role-agnostic tests
    └── navigation.spec.ts
```

#### 3. Test File Pattern

Each test file declares its role at the top:

```typescript
// requester/mark-proof-ready.spec.ts
import { test, expect } from '@playwright/test';

test.use({ storageState: './test-results/.auth-requester.json' });

test.describe('Requester - Mark Proof Ready', () => {
  // All tests run as REQUESTER
});
```

#### 4. API-Driven Test Data Setup

Instead of UI-based setup across roles, use API calls:

```typescript
// OLD (BROKEN): UI setup with role switching
test('approve workflow', async ({ page }) => {
  await switchToRole(page, 'REQUESTER');
  await createTacticViaUI(page);
  await switchToRole(page, 'PROOF_READER'); // FAILS
  await approveViaUI(page);
});

// NEW (WORKING): API setup, single-role UI test
test('approve verbiage', async ({ page }) => {
  // GIVEN: Create tactic in CHECKING_VERBIAGE state via API
  const tacticId = await TacticSetup.createFullyPopulatedDraftTactic(
    process.env.E2E_AUTH_TOKEN_REQUESTER!
  );
  await TacticSetup.markProofReady(
    tacticId,
    process.env.E2E_AUTH_TOKEN_REQUESTER!
  );
  
  // WHEN: Test PROOF_READER's UI interaction
  await page.goto(`/tactic/${tacticId}`);
  await page.getByRole('button', { name: 'Approve' }).click();
  
  // THEN: Verify via UI and API
  await expect(page).toHaveURL('/tactics');
  await TacticSetup.verifyTacticStatus(
    tacticId,
    process.env.E2E_AUTH_TOKEN_PROOFREADER!,
    'INFORMING_VENDORS'
  );
});
```

#### 5. Helper Classes

**`ApiClient`** - Reusable HTTP client with token injection:
```typescript
class ApiClient {
  constructor(token: string);
  get<T>(endpoint: string): Promise<T>;
  post<T>(endpoint: string, data?: unknown): Promise<T>;
  patch<T>(endpoint: string, data: unknown): Promise<T>;
}
```

**`TacticSetup`** - Test data factory with workflow methods:
```typescript
class TacticSetup {
  static createDraftTactic(requesterToken: string): Promise<string>;
  static createFullyPopulatedDraftTactic(requesterToken: string): Promise<string>;
  static markProofReady(tacticId: string, requesterToken: string): Promise<void>;
  static verifyTacticStatus(tacticId: string, token: string, expectedStatus: string): Promise<void>;
}
```

### Workflow Decomposition

Multi-role workflows are decomposed into single-role tests:

**Workflow: Approve Verbiage (REQUESTER → PROOF_READER)**

- **Test 1 (requester/mark-proof-ready.spec.ts):** REQUESTER marks tactic proof-ready
  - Setup: Create tactic via API
  - Test: Mark proof-ready via UI
  - Verify: Status = CHECKING_VERBIAGE (via API)

- **Test 2 (proofreader/approve-verbiage.spec.ts):** PROOF_READER approves verbiage
  - Setup: Create tactic in CHECKING_VERBIAGE state via API (as REQUESTER)
  - Test: Approve via UI (as PROOF_READER)
  - Verify: Status = INFORMING_VENDORS (via API)

Each test focuses on **one role's responsibility** in the workflow.

### Environment Variables

Tests require role-specific JWT tokens:

```bash
export E2E_AUTH_TOKEN_REQUESTER="<requester-jwt>"
export E2E_AUTH_TOKEN_PROOFREADER="<proofreader-jwt>"
export E2E_AUTH_TOKEN_ADMIN="<admin-jwt>"
```

Global setup validates these are set and creates corresponding storage states.

## Consequences

### Positive

✅ **Tests work reliably** - No more localStorage manipulation failures  
✅ **Clear role boundaries** - Each test file has a single, obvious role  
✅ **Easier maintenance** - Tests organized by role, predictable locations  
✅ **Faster execution** - Parallel-friendly (no role-switching conflicts)  
✅ **Better smoke tests** - Each test focuses on one role's critical UI interactions  
✅ **Simpler code** - No complex role-switching logic, fewer lines of code  
✅ **API verification** - Cross-role state changes verified via API (more reliable)  
✅ **Follows Playwright best practices** - Uses storage states as intended  
✅ **Agentic-friendly** - Clear patterns, easy to understand and extend  

### Negative

❌ **More test files** - Workflows split across multiple files (but better organized)  
❌ **API setup required** - Need to build `TacticSetup` helper class  
❌ **Multiple JWT tokens** - Must manage 3 environment variables instead of 1  
❌ **No UI verification of cross-role transitions** - Can't watch REQUESTER → PROOF_READER transition in UI (but API verification is more reliable)

### Migration Impact

- **48 existing tests** need to be reorganized
- **Delete `switchToRole()` helper** - No longer needed
- **Create new helpers** - `ApiClient`, `TacticSetup`
- **Update global-setup.ts** - Create 3 storage states instead of 1
- **Reorganize test files** - Move to role-based folders

### Testing Philosophy

This decision reinforces our E2E testing philosophy:

1. **E2E tests verify integration, not implementation** - Use API for setup, test UI for user-facing interactions
2. **Each test has a single responsibility** - One role, one workflow step
3. **Smoke tests, not comprehensive coverage** - Focus on critical paths that can only be tested end-to-end
4. **Reliable over comprehensive** - Better to have fewer reliable tests than many flaky ones

### Related ADRs

- **ADR-04: Test File Naming and Separation** - E2E tests use `.spec.ts`, unit tests use `.test.ts`
- **ADR-10: TestId v2 Component-Centric** - E2E tests use testIds for stable selectors
- **ADR-13: E2E Test Logging Infrastructure** - Logging patterns for debugging E2E tests

## Implementation

See `/docs/reqs/_tech/0Z - Role Based E2E Testing/ROLE_BASED_TESTING_MIGRATION_PLAN.md` for detailed implementation plan including:

- Complete file structure
- Code examples for all helpers
- Migration strategy (5 phases)
- Test categorization (48 tests → role-based organization)
- Testing patterns and best practices

## References

- [Playwright Authentication Documentation](https://playwright.dev/docs/auth)
- [Playwright Storage State API](https://playwright.dev/docs/api/class-browsercontext#browser-context-storage-state)
- Migration Plan: `/docs/reqs/_tech/0Z - Role Based E2E Testing/ROLE_BASED_TESTING_MIGRATION_PLAN.md`
