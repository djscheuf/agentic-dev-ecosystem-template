# 20251125-09. Adopt ShadCN/Radix UI for Complex Interactive Components

Date: 2025-11-25

## Status

Accepted

## Context

### Problem
The team needs to accelerate the mockup-to-implementation workflow, particularly for complex interactive components. Currently:

1. **Custom development is time-consuming**: Components like Combobox (364 lines) require significant effort to implement accessibility, keyboard navigation, focus management, and edge cases.

2. **Inconsistent patterns**: Each complex component (Combobox, Select, future Dialogs) requires custom solutions for similar problems (focus traps, keyboard navigation, ARIA attributes).

3. **Maintenance burden**: Custom implementations require ongoing maintenance for accessibility improvements, browser compatibility, and bug fixes.

4. **Slow feature velocity**: Building complex components from scratch delays feature delivery when mockups require new interaction patterns.

### Current State
The `@coupon-builder/ui` package has:
- ✅ Tailwind CSS (v3.4.18) already in use
- ✅ Atomic Design structure (atoms/molecules/organisms)
- ✅ 17 components with tests and Storybook stories
- ✅ Simple components work well (Button, Input, Label, Badge)
- ⚠️ Complex components require significant custom development (Combobox, Select)
- ⚠️ Domain-specific components need custom logic (FileUploadManager, FormField)

### Evaluation Criteria
1. **Speed**: Reduce time from mockup to implementation
2. **Quality**: Maintain or improve accessibility and UX
3. **Maintainability**: Reduce custom code maintenance
4. **Compatibility**: Preserve existing component APIs where possible
5. **Team velocity**: Enable faster feature development

## Decision

### Adopt a Hybrid Approach: ShadCN/Radix for Complex Components Only

**DO adopt ShadCN/Radix for:**
- Complex interactive components (Combobox, Select, Dialog, Dropdown, Popover, Tooltip)
- Components requiring advanced accessibility (focus management, ARIA, keyboard navigation)
- Components with significant state management (tabs, accordions, date pickers)
- New complex components needed in the future

**DO NOT migrate certain existing components:**
- Simple components (Button, Input, Label, Badge, Textarea)
- Domain-specific components (FileUploadManager, TacticTable, FormField)
- Components with custom business logic (Input formatting, TanStack Form integration)

### Implementation Strategy

#### 1. Package Structure
```
packages/ui/src/
  components/
    ui/              # NEW: ShadCN/Radix components (complex)
      combobox.tsx
      select.tsx
      dialog.tsx
      dropdown-menu.tsx
      command.tsx
    atoms/           # KEEP: Simple components
      Button/
      Input/
      Label/
      Badge/
      FileUpload/
    molecules/       # KEEP: Domain-specific
      FormField/
      FileUploadManager/
    organisms/       # KEEP: Domain-specific
      TacticTable/
      CollapsibleCard/
```

#### 2. Component Selection Matrix

| Scenario | Approach | Rationale |
|----------|----------|-----------|
| Complex interactions (dropdowns, modals, popovers) | Use ShadCN/Radix | Accessibility, keyboard nav, focus management built-in |
| Simple styling (buttons, badges, labels) | Keep custom | Migration cost > benefit |
| Domain-specific logic | Keep custom | Business logic > UI primitives |
| TanStack Form integration | Keep custom | Tight coupling with form library |
| No ShadCN equivalent | Build custom | No alternative |
| New complex component needed | Check ShadCN first | Prefer existing over custom |

#### 3. Migration Phases

**Phase 1: Infrastructure (1-2 days)**
- Install ShadCN CLI and Radix primitives
- Configure Tailwind with design tokens
- Setup `components/ui/` directory
- Update build configuration

**Phase 2: High-Value Components (2-3 weeks)**
- Week 1: Migrate Combobox (364 lines → ~50 line wrapper)
- Week 2: Migrate Select (better mobile UX)
- Week 3: Add Dialog (needed for future features)

**Phase 3: Documentation (1 week)**
- Create component selection guide
- Document integration patterns
- Update development workflows

**Phase 4: Ongoing (as needed)**
- Add new ShadCN components when needed
- Maintain existing custom components
- No forced migration of working components

#### 4. Backward Compatibility

For components with existing consumers, provide adapter wrappers:

```typescript
// ComboboxAdapter.tsx - maintains legacy API
import { Combobox as ShadcnCombobox } from '../../ui/combobox';

/**
 * @deprecated Use ShadCN Combobox directly for new code
 */
export function ComboboxAdapter({ options, value, onChange }: LegacyProps) {
  // Map legacy API to ShadCN API
}
```

#### 5. Dependencies

**Add:**
- `@radix-ui/react-*` primitives (select, dropdown-menu, dialog, popover, etc.)
- `lucide-react` (for icons, replacing custom Icons component over time)
- `cmdk` (for Command component used in Combobox)

**Already have:**
- `tailwindcss` (v3.4.18)
- `class-variance-authority` (v0.7.1)
- `tailwind-merge` (v3.3.1)
- `clsx` (v2.1.1)

## Consequences

### Positive

1. **Faster development**: 50-70% reduction in time for complex component implementation
   - Combobox: 364 lines custom → ~50 line wrapper
   - Dialog: 0 hours (use existing) vs 12-16 hours custom
   - Dropdown: 0 hours (use existing) vs 8-12 hours custom

2. **Better accessibility**: Radix primitives provide WCAG-compliant implementations
   - Focus management
   - Keyboard navigation
   - ARIA attributes
   - Screen reader support

3. **Improved mobile UX**: Radix Select provides better mobile experience than native `<select>`

4. **Reduced maintenance**: Radix team handles browser compatibility, edge cases, and accessibility updates

5. **Consistent patterns**: Team learns one set of patterns for complex components

6. **Incremental adoption**: No big-bang migration, adopt as needed

7. **Preserve investments**: Keep working simple components and domain-specific logic

### Negative

1. **Learning curve**: Team needs to learn Radix composition patterns (1-2 weeks)

2. **Dependency increase**: Adding Radix primitives increases bundle size
   - Mitigated by tree-shaking (only import what you use)
   - Complex components would have similar size if built custom

3. **Two component systems**: Temporary hybrid state during migration
   - Mitigated by clear component selection matrix
   - Adapter wrappers provide backward compatibility

4. **Test updates**: Existing tests for migrated components need updates
   - Combobox: ~1 day to update tests
   - Select: ~1 day to update tests
   - Behavior tests remain similar, implementation tests change

5. **Storybook updates**: Stories for migrated components need updates
   - Similar effort to test updates
   - Opportunity to improve story coverage

### Neutral

1. **No impact on existing consumers**: Adapter wrappers maintain API compatibility

2. **No impact on simple components**: Button, Input, Label, Badge remain unchanged

3. **No impact on domain logic**: FileUploadManager, FormField, TacticTable unchanged

## Success Metrics

**After Phase 2 (3 weeks):**
- ✅ Combobox migrated with test coverage maintained
- ✅ Select migrated with improved mobile UX
- ✅ Dialog component available for future features
- ✅ Component selection guide documented
- ✅ Zero breaking changes for consumers

**After 3 months:**
- ✅ 3+ new complex components added using ShadCN (vs custom development)
- ✅ 50-70% time reduction for complex component implementation
- ✅ Accessibility audit shows improved WCAG compliance
- ✅ Team velocity increased for features requiring new UI patterns

## Alternatives Considered

### Alternative 1: Full ShadCN Migration
**Rejected**: Migration cost (40-80 hours) > benefit for simple components that already work well.

### Alternative 2: Continue Custom Development
**Rejected**: Slow velocity, inconsistent patterns, high maintenance burden for complex components.

### Alternative 3: Different Component Library (Material UI, Ant Design, Chakra)
**Rejected**: 
- Heavier frameworks with opinionated styling
- Harder to customize to match design system
- ShadCN/Radix provides unstyled primitives with full control

### Alternative 4: Headless UI
**Rejected**: 
- Smaller component library than Radix
- Less active development
- ShadCN provides better integration patterns

## References

- [ShadCN UI Documentation](https://ui.shadcn.com/)
- [Radix UI Primitives](https://www.radix-ui.com/primitives)
- [Lucide React Icons](https://lucide.dev/)
- ADR-08: Collapsible Card CSS Visibility (related UI pattern)
- ADR-06: File Upload Manager Reusable Component (custom component example)

## Implementation Plan

See `/docs/reqs/ShadCN-Migration/` for detailed implementation plans (to be created).

**Next Steps:**
1. Create feature branch: `feature/shadcn-complex-components`
2. Phase 1: Infrastructure setup (1-2 days)
3. Phase 2: Combobox migration pilot (1 week)
4. Review pilot results, adjust strategy if needed
5. Continue with Select and Dialog migrations
