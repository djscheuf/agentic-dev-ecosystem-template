import { useEffect, useState } from "react";
import { logger } from "../utils/logger.util";
import { getCurrentUser } from "../apis/user-api";
import type { User, Role } from "@coupon-builder/models";

export function useUser(): User | undefined {
  const [user, setUser] = useState<User | undefined>(undefined);

  useEffect(() => {
    const fetchUser = async () => {
      const apiMode = import.meta.env.VITE_API_MODE;

      // Use mock mode for: mock, test, or undefined (default for tests)
      if (apiMode === "mock" || apiMode === "test" || !apiMode) {
        const demoUser: User = {
          userId: "de.mo@purina.com",
          roles: ["Requester"],
        };
        logger.debug("useUser - mock mode", { user: demoUser });
        setUser(demoUser);
      } else {
        // Fetch from API in integration/production mode
        try {
          const userData = await getCurrentUser();
          logger.debug("useUser - fetched from API", { user: userData });
          setUser(userData);
        } catch (error) {
          logger.error("useUser - failed to fetch", { error });
          setUser(undefined);
        }
      }
    };

    fetchUser();
  }, []);

  return user;
}
