import { Badge } from "../../atoms/Badge/Badge";
import { TacticStatus } from "@coupon-builder/models";
import { getStatusDisplay } from "../../../utils/status-display.util";
import { useStatusContext } from "../../../contexts/StatusContext/StatusContext";

export interface StatusBadgeProps {
  status: TacticStatus;
  className?: string;
  testId?: string;
  useContext?: boolean;
}

type BadgeColor = "default" | "secondary" | "destructive" | "outline" | "success" | "grey" | "green" | "blue" | "red" | "yellow" | "orange" | "purple" | "pink" | "cyan" | "dark-green" | "dark-red";

const colorToBadgeColorMap: Record<string, BadgeColor> = {
  gray: "grey",
  blue: "blue",
  yellow: "yellow",
  orange: "orange",
  green: "green",
  pink: "pink",
  cyan: "cyan",
  "dark-green": "dark-green",
  "dark-red": "dark-red",
};

export default function StatusBadge({
  status,
  className,
  testId,
  useContext = false,
}: StatusBadgeProps) {
  // Try to use context if available, otherwise fall back to static config
  let context;
  try {
    context = useStatusContext();
  } catch {
    // Context not available, will use static fallback
    context = undefined;
  }

  const statusDisplay = context 
    ? context.getStatusDisplay(status)
    : getStatusDisplay(status);
  
  const badgeColor: BadgeColor = colorToBadgeColorMap[statusDisplay.color] || "default";

  return (
    <Badge
      variant="outline"
      color={badgeColor}
      className={className}
      testId={testId}
    >
      {statusDisplay.displayName}
    </Badge>
  );
}
