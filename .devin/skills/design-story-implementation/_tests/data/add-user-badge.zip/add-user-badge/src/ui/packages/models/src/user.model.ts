export interface User {
  userId: string; // User's email address
  roles: Role[];
  isAuthenticated?: boolean;
  fromJwt?: boolean;
  opCo?: string | null;
  businessEntity?: string | null;
}

export type Role = 
  | "ADMIN" 
  | "ProofReader" 
  | "InternalRequester"
  | "CREATIVE_AGENT"
  | "CreativeAgent"
  | "CLEARINGHOUSE_AGENT"
  | "ClearinghouseAgent";
