import React, { useState } from "react";
import type { TacticStatus } from "@coupon-builder/models";
import Button from "../../atoms/Button/Button";
import StatusBadge from "../../molecules/StatusBadge/StatusBadge";
import { Icons } from "../../atoms/Icons";
import { TacticStickyHeaderTestIds } from "./TacticStickyHeader.testids";

export interface ActionButton {
  content: React.ReactNode;
  onClick: () => void;
  disabled?: boolean;
  isLoading?: boolean;
  testId?: string;
}

export interface MenuEntry {
  content: React.ReactNode;
  onClick: () => void;
  testId?: string;
  disabled?: boolean;
}

export interface TacticStickyHeaderProps {
  title: string;
  status?: TacticStatus;
  requesterId: string;
  requesterEmail?: string;
  lastModified?: Date;
  onBack: () => void;
  primaryAction?: ActionButton;
  secondaryAction?: ActionButton;
  menuEntries?: MenuEntry[];
  callToAction?: React.ReactNode;
  progressCurrent?: number;
  progressTotal?: number;
  testId?: string;
}

export const TacticStickyHeader: React.FC<TacticStickyHeaderProps> = ({
  title,
  status,
  requesterId,
  requesterEmail,
  lastModified,
  onBack,
  primaryAction,
  secondaryAction,
  menuEntries,
  callToAction,
  progressCurrent = 0,
  progressTotal = 1,
  testId,
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div
      data-testid={
        testId ? TacticStickyHeaderTestIds.container(testId) : undefined
      }
      className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex items-center justify-between gap-8">
          {/* Left section: Back button vertically centered next to info column */}
          <div className="flex items-center gap-3 flex-1 min-w-0">
            {/* Back button - vertically centered */}
            <button
              data-testid={
                testId
                  ? TacticStickyHeaderTestIds.backButton(testId)
                  : undefined
              }
              onClick={onBack}
              className="flex-shrink-0 p-1 text-blue-600 hover:text-blue-800 transition-colors self-center"
              aria-label="Back to tactics list"
            >
              <Icons.ChevronLeft size="sm" aria-hidden="true" />
            </button>

            {/* Info column */}
            <div className="flex flex-col gap-1 min-w-0">
              {/* Row 1: Title and Status Badge */}
              <div className="flex items-center gap-2">
                <h1
                  data-testid={
                    testId ? TacticStickyHeaderTestIds.title(testId) : undefined
                  }
                  className="text-lg font-semibold text-gray-900 truncate"
                >
                  {title}
                </h1>
                {status && (
                  <StatusBadge
                    status={status}
                    testId={
                      testId
                        ? TacticStickyHeaderTestIds.statusBadge(testId)
                        : undefined
                    }
                  />
                )}
              </div>

              {/* Row 2: Requester ID/Email • Last Update */}
              <div
                className="flex items-center gap-2 text-sm text-gray-600"
                data-testid={
                  testId
                    ? TacticStickyHeaderTestIds.requesterInfo(testId)
                    : undefined
                }
              >
                <span>
                  Requester ID:{" "}
                  <span className="font-medium">
                    {requesterId}
                    {requesterEmail && ` (${requesterEmail})`}
                  </span>
                </span>
                {lastModified && (
                  <>
                    <span className="text-gray-400">•</span>
                    <span
                      data-testid={
                        testId
                          ? TacticStickyHeaderTestIds.lastModifiedInfo(testId)
                          : undefined
                      }
                      className="text-gray-600"
                    >
                      Last Update:{" "}
                      {lastModified.toLocaleDateString("en-US", {
                        month: "2-digit",
                        day: "2-digit",
                        year: "numeric",
                      })}
                      ,{" "}
                      {lastModified.toLocaleTimeString("en-US", {
                        hour: "numeric",
                        minute: "2-digit",
                        hour12: true,
                      })}
                    </span>
                  </>
                )}
              </div>

              {/* Row 3: Call to action with progress bar (if provided) */}
              {callToAction && (
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <div 
                    className="h-1 w-24 bg-gray-200 rounded-full overflow-hidden"
                    role="progressbar"
                    aria-valuenow={progressCurrent}
                    aria-valuemin={0}
                    aria-valuemax={progressTotal}
                    aria-label="Task progress"
                  >
                    <div
                      className="h-full bg-blue-500 transition-all duration-300"
                      style={{
                        width: `${progressTotal > 0 ? (progressCurrent / progressTotal) * 100 : 0}%`,
                      }}
                    ></div>
                  </div>
                  <div aria-live="polite">{callToAction}</div>
                </div>
              )}
            </div>
          </div>

          {/* Right section: Action buttons */}
          <div className="flex items-center gap-2 flex-shrink-0">
            {secondaryAction && (
              <Button
                variant="outline"
                size="md"
                onClick={secondaryAction.onClick}
                disabled={secondaryAction.disabled}
                isLoading={secondaryAction.isLoading}
                testId={
                  secondaryAction.testId ||
                  (testId
                    ? TacticStickyHeaderTestIds.secondaryButton(testId)
                    : undefined)
                }
              >
                {secondaryAction.content}
              </Button>
            )}
            {primaryAction && primaryAction.content && (
              <Button
                variant="primary"
                size="md"
                onClick={primaryAction.onClick}
                disabled={primaryAction.disabled}
                isLoading={primaryAction.isLoading}
                testId={
                  primaryAction.testId ||
                  (testId
                    ? TacticStickyHeaderTestIds.primaryButton(testId)
                    : undefined)
                }
              >
                {primaryAction.content}
              </Button>
            )}
            {menuEntries && menuEntries.length > 0 && (
              <div className="relative">
                <button
                  data-testid={
                    testId
                      ? TacticStickyHeaderTestIds.kebabMenuButton(testId)
                      : undefined
                  }
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                  onKeyDown={(e) => {
                    if (e.key === 'Escape' && isMenuOpen) {
                      setIsMenuOpen(false);
                    }
                  }}
                  className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded transition-colors"
                  aria-label="More actions"
                  aria-expanded={isMenuOpen}
                  aria-haspopup="menu"
                >
                  <Icons.MoreVertical size="sm" aria-hidden="true" />
                </button>
                {isMenuOpen && (
                  <>
                    <div
                      className="fixed inset-0 z-10"
                      onClick={() => setIsMenuOpen(false)}
                      aria-hidden="true"
                    />
                    <div
                      data-testid={
                        testId
                          ? TacticStickyHeaderTestIds.kebabMenu(testId)
                          : undefined
                      }
                      role="menu"
                      className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg border border-gray-200 py-1 z-20"
                      onKeyDown={(e) => {
                        if (e.key === 'Escape') {
                          setIsMenuOpen(false);
                        }
                      }}
                    >
                      {menuEntries.map((entry, index) => (
                        <button
                          key={index}
                          data-testid={entry.testId}
                          role="menuitem"
                          onClick={() => {
                            entry.onClick();
                            setIsMenuOpen(false);
                          }}
                          disabled={entry.disabled}
                          className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          {entry.content}
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TacticStickyHeader;
