import { logger } from "../utils/logger.util";
import { apiClient } from "../utils/api-client.util";
import { tacticApiBaseUrl, apiMode } from "../../config";
import type { User } from "@coupon-builder/models";

// Log the API configuration on module load
logger.info("User API initialized", {
  baseUrl: tacticApiBaseUrl,
  mode: apiMode,
});

/**
 * Requester DTO returned from the API
 */
export interface RequesterDto {
  userId: string;
  displayName: string;
  email: string;
  isActive: boolean;
}

/**
 * Fetches the current user's information from the API
 * @returns Promise<User> - The current user's data
 * @throws Error if the API call fails
 */
export const getCurrentUser = async (): Promise<User> => {
  try {
    const endpoint = `${tacticApiBaseUrl}/user/me`;
    logger.debug("Fetching current user", { endpoint });

    const response = await apiClient(endpoint);

    if (!response.ok) {
      throw new Error(`Failed to fetch user: ${response.status}`);
    }

    const userData = await response.json();
    logger.debug("User loaded successfully", { user: userData });

    return userData;
  } catch (err) {
    logger.error("Failed to load current user", { error: err });
    throw err;
  }
};

/**
 * Fetches all requesters from the current user's OpCo
 * Only accessible to users with Requester role
 * @returns Promise<RequesterDto[]> - List of requesters from user's OpCo
 * @throws Error if the API call fails or user doesn't have Requester role (403)
 */
export const getOpCoRequesters = async (): Promise<RequesterDto[]> => {
  try {
    const endpoint = `${tacticApiBaseUrl}/user/requesters`;
    logger.debug("Fetching OpCo requesters", { endpoint });

    const response = await apiClient(endpoint);

    if (!response.ok) {
      throw new Error(`Failed to fetch requesters: ${response.status}`);
    }

    const requesters = await response.json();
    logger.debug("Requesters loaded successfully", { count: requesters.length });

    return requesters;
  } catch (err) {
    logger.error("Failed to load OpCo requesters", { error: err });
    throw err;
  }
};

/**
 * Alias for getOpCoRequesters - fetches peers (requesters from user's OpCo)
 * Used for reassigning tactic ownership
 * @returns Promise<RequesterDto[]> - List of peers from user's OpCo
 */
export const getPeers = getOpCoRequesters;

export default {
  getCurrentUser,
  getOpCoRequesters,
  getPeers,
};
