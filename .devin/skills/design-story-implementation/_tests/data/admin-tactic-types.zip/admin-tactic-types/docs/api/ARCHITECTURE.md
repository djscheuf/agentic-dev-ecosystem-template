# Tactic Management API - System Architecture

## Document Information
- **Version**: 2.0
- **Last Updated**: 2025-11-07
- **Status**: Active
- **Purpose**: Pattern declaration and architectural guidance for AI coding agents

## Table of Contents
1. [Executive Summary](#executive-summary)
2. [System Overview](#system-overview)
3. [Business Rules & Constraints](#business-rules--constraints)
4. [System Architecture](#system-architecture)
5. [CQRS Pattern Implementation](#cqrs-pattern-implementation)
6. [API Patterns](#api-patterns)
7. [Layer Responsibilities](#layer-responsibilities)
8. [Project-Specific Patterns](#project-specific-patterns)
9. [Quick Reference](#quick-reference)

---

## Executive Summary

The Tactic Management API is a RESTful web service built on .NET 8.0 that manages marketing tactics for the Purina Coupon Builder system. The system follows **Clean Architecture** principles with **CQRS (Command Query Responsibility Segregation)** as the core design pattern.

### Key Architectural Decisions
- **Clean Architecture**: 4-layer separation (API → Application → Domain → Infrastructure)
- **CQRS Pattern**: Separate command (write) and query (read) operations
- **Two APIs**: Management API (tactics lifecycle) + Reference API (lookup data)
- **Command-Query UI Pattern**: Commands return ID only, UI fetches data via queries
- **Security-First**: Return 404 (not 403) for unauthorized access
- **UTC Enforcement**: All DateTime values validated as DateTimeKind.Utc

---

## System Overview

### Two Distinct APIs

#### 1. Management API (`/api/v1/tactics`)
**Purpose**: Tactic lifecycle operations (create, update, view)  
**Access**: `InternalRequester` role required  
**Pattern**: CQRS with command-query separation

**Endpoints**: POST (create), PATCH (update), GET (list), GET/{id} (detail)

#### 2. Reference API (`/api/v1/reference`)
**Purpose**: Read-only reference data (tactic types, distribution methods, system config)  
**Access**: Any authenticated user  
**Pattern**: Simple queries with caching (15 min)

**Endpoints**: GET /tactic-types, GET /tactic-distribution-methods, GET /handling-fee

### UI Integration Pattern
**Commands return minimal data:**
```
POST /api/v1/tactics → { tacticId: "...", success: true }
UI then calls: GET /api/v1/tactics/{id} → Full TacticDetailDto
```

**Why?** Prevents stale data, ensures consistency, simplifies command handlers.

---

## Business Rules & Constraints

### Tactic Lifecycle Rules
1. **Status Values**: DRAFT (1), PROOF_READY (2). Additional statuses will be added in future stories.
2. **Edit Restriction**: Only DRAFT tactics can be modified (PATCH returns 400 for non-DRAFT)
3. **Ownership**: `OwnerId` defaults to `RequesterId` if not provided
4. **Offer Code**: Database-generated IDENTITY, starting at 100000 (auto-incremented, may have gaps)

### Date Validation Rules
1. **Campaign Start**: Must be ≥ 15 days from today (UTC, date comparison only)
2. **Campaign End**: Must be > Campaign Start
3. **Expiry Date**: Must be ≥ Campaign End (if provided, optional)
4. **UTC Enforcement**: All DateTime values must be `DateTimeKind.Utc`
   - Validated in `DbContext.SaveChanges()` (throws InvalidOperationException)
   - ValueConverters ensure DB values marked as UTC
   - Use `DateTime.UtcNow` for new dates
   - Use `DateTime.SpecifyKind(date, DateTimeKind.Utc)` for user input

### Authorization Rules
1. **Access Control**: User can view/edit tactics where `OwnerId == UserId OR RequesterId == UserId`
2. **Security Pattern**: Return 404 (not 403) for unauthorized access to prevent information disclosure
3. **Role Requirement**: `InternalRequester` role required for Management API
4. **Reference API**: Any authenticated user can access

### Authorization Services

#### ITacticReadAuthorizationService
Centralized service for determining read-level access to tactics. Used by all query handlers (GET) and before command handlers (PATCH/POST/DELETE) to verify user can access the tactic.

**Authorization Rules:**
- **Owner**: `tactic.OwnerId == userId` → Access granted
- **Requester**: `tactic.RequesterId == userId` → Access granted
- **ProofReader**: User has `ProofReader` role → Access granted (can read ALL tactics)

**Usage Pattern:**
```csharp
var hasAccess = await _readAuthService.HasReadAccessAsync(
    userId, tactic, correlationId, cancellationToken);
if (!hasAccess) 
    throw new KeyNotFoundException($"Tactic with ID {tacticId} not found"); // 404, not 403
```

**Performance Optimization:**
- Short-circuit evaluation: Owner check first (cheapest), then Requester, then ProofReader role lookup
- Role lookups cached via `IUserContextService` (15 min default)

**Complementary Service:**
- `IFieldAuthorizationService`: Determines which fields can be modified (write access)

**Logging:**
- Service logs at **Debug** level (authorization decision with reason)
- Handler logs at **Warning** level (security event - unauthorized attempt)
- Correlation ID links service and handler logs for request tracing

**Handlers Using Service (7 total):**
1. `GetTacticByIdQueryHandler` - View tactic details
2. `UpdateTacticAllocationsCommandHandler` - Modify allocations
3. `MarkTacticProofReadyCommandHandler` - Change status
4. `UploadAttachmentCommandHandler` - Add attachments
5. `DeleteTacticAttachmentCommandHandler` - Remove attachments
6. `DownloadTacticAttachmentQueryHandler` - Download files
7. `GetTacticAttachmentsQueryHandler` - List attachments

### Budget Calculation (Frontend Responsibility)
- **Redemption Budget** = `FaceValue × CirculationQuantity × (RedemptionRate/100) × HandlingFee`
- **Total Budget** = `NonworkingBudget + RedemptionBudget`
- **Backend**: Stores input values only (no calculated fields)
- **Handling Fee**: Retrieved from SystemConfigurations table, cached 15 min

### Validation Constraints

**Required Fields:**
- Description (max 25 characters)
- TacticTypeId (must reference existing TacticType)
- TacticDistributionMethodId (must reference existing method)
- CampaignStartDate (≥ 15 days from now)
- CampaignEndDate (> CampaignStartDate)

**Optional Fields:**
- Notes (max 500 characters when provided)
- ExpiryDate (≥ CampaignEndDate when provided)
- FaceValue (> 0 when provided)
- CirculationQuantity (> 0 when provided)
- RedemptionRate (0-100, max 2 decimals when provided)
- NonworkingBudget (≥ 0 when provided)

**System-Managed Fields:**
- Id (Guid, generated by application)
- OfferCode (int, database-generated IDENTITY starting at 100000)
- Status (always DRAFT on create)
- OwnerId (defaults to RequesterId)
- CreatedDate, LastModified (UTC, auto-managed)

---

## System Architecture

### High-Level Architecture

```
Client (UI)
    │ HTTPS/JWT
    ▼
API Layer (Controllers)
    │ MediatR
    ▼
Application Layer (Handlers, Validators, Repositories)
    │ EF Core
    ▼
Domain Layer (Entities, DTOs, Commands, Queries)
    │
    ▼
Infrastructure (SQL Server 2022)
```

**Dependency Rule**: Dependencies point inward (API → Application → Domain)

### Project Structure

```
tactic-mgmt-api/
├── src/
│   ├── TacticManagement.Api/              # Controllers, Middleware, DI config
│   ├── TacticManagement.Application/      # Handlers, Validators, Repositories, DbContext
│   └── TacticManagement.Domain/           # Entities, DTOs, Commands, Queries, Enums
└── tests/
    ├── TacticManagement.Api.Tests/        # Integration tests
    ├── TacticManagement.Application.Tests/ # Handler + Repository tests (BDD/GWT style)
    └── TacticManagement.Domain.Tests/     # Domain model tests
```

**See**: Actual project structure for detailed file organization

---

## CQRS Pattern Implementation

### Core Principles
1. **Commands** change state, return status + ID only (no entity data)
2. **Queries** read state, return full DTOs
3. **UI Pattern**: POST/PATCH → GET (command returns ID, UI fetches latest data)
4. **Separation**: Commands and Queries never mixed in same handler
5. **MediatR**: All operations routed through `IMediator.Send()`

### When to Use Commands vs Queries

**Use Command when:**
- Creating new entities (`CreateTacticCommand`)
- Updating existing entities (`UpdateTacticCommand`)
- Deleting entities
- Any operation that changes database state

**Use Query when:**
- Fetching entity by ID (`GetTacticByIdQuery`)
- Listing entities with filters (`GetUserTacticsQuery`)
- Retrieving reference data (`GetTacticTypesQuery`)
- Any read-only operation

### Command Pattern (Write Operations)

**Structure:**
- **Location**: `Domain/Commands/` (definition), `Application/Tactics/Commands/` (handler)
- **Naming**: `{Verb}{Entity}Command` + `{Verb}{Entity}CommandHandler`
- **Returns**: `{Verb}{Entity}Response` with `{ TacticId, Success, Message? }`
- **Validation**: FluentValidation (input) + Business rules (handler)

**Handler Responsibilities:**
1. Validate business rules (throw exceptions for violations)
2. Apply business logic (status, defaults, calculations)
3. Persist via repository
4. Return minimal response (ID + status)

**Example Implementations:**
- `CreateTacticCommandHandler` - Creates tactic, generates offer code, sets DRAFT status
- `UpdateTacticCommandHandler` - Updates tactic, enforces DRAFT-only rule

**Controller Pattern:**
```csharp
var response = await _mediator.Send(command);
return CreatedAtAction(nameof(GetTacticById), new { id = response.TacticId }, response);
```

### Query Pattern (Read Operations)

**Structure:**
- **Location**: `Domain/Queries/` (definition), `Application/Tactics/Queries/` (handler)
- **Naming**: `Get{Entity}[By{Criteria}]Query` + `Get{Entity}[By{Criteria}]QueryHandler`
- **Returns**: DTO with complete entity data
- **Authorization**: Enforce in handler (return 404 for unauthorized, not 403)

**Handler Responsibilities:**
1. Retrieve data via repository
2. Verify authorization (owner OR requester)
3. Map to DTO
4. Return complete data

**Example Implementations:**
- `GetTacticByIdQueryHandler` - Fetches single tactic, verifies access
- `GetUserTacticsQueryHandler` - Lists user's tactics with filtering/pagination
- `GetTacticTypesQueryHandler` - Returns all tactic types ordered by DisplayOrder

**Controller Pattern:**
```csharp
var result = await _mediator.Send(query);
return Ok(result);
```

### MediatR Integration

**Request/Response Contracts:**
```csharp
// Commands implement IRequest<TResponse>
public class CreateTacticCommand : IRequest<CreateTacticResponse> { }

// Queries implement IRequest<TDto>
public class GetTacticByIdQuery : IRequest<TacticDetailDto> { }
```

**Handler Registration:**
- Auto-registered via `services.AddMediatR()` in `Program.cs`
- Handlers discovered by assembly scanning
- One handler per command/query (enforced by MediatR)

---

## API Patterns

### Management API (`/api/v1/tactics`)
**Purpose**: Commands and queries for Tactic lifecycle  
**Access**: `InternalRequester` role required

| Method | Endpoint | Type | Returns | Status |
|--------|----------|------|---------|--------|
| POST | `/tactics` | Command | `{ tacticId, success }` | 201 |
| PATCH | `/tactics/{id}` | Command | `{ tacticId, success, message? }` | 200 |
| GET | `/tactics` | Query | `{ items[], totalCount, page, pageSize }` | 200 |
| GET | `/tactics/{id}` | Query | `TacticDetailDto` | 200 |

**Command Response Pattern:**
- Returns ID + status only (no entity data)
- UI must call GET endpoint to fetch latest data
- Prevents stale data issues

**Query Authorization:**
- User sees only tactics where `OwnerId == UserId OR RequesterId == UserId`
- Return 404 (not 403) for unauthorized access

### Reference API (`/api/v1/reference`)
**Purpose**: Read-only reference data (tactic types, distribution methods)  
**Access**: Any authenticated user

| Method | Endpoint | Returns | Caching |
|--------|----------|---------|---------|
| GET | `/reference/tactic-types` | `TacticTypeDto[]` | 15 min |
| GET | `/reference/tactic-distribution-methods` | `TacticDistributionMethodDto[]` | 15 min |
| GET | `/reference/handling-fee` | `decimal` | 15 min |

**Reference Data Pattern:**
- Small, stable datasets (< 100 items)
- Ordered by `DisplayOrder` for consistent UI
- Backend caching (IMemoryCache, 15 min)
- No pagination needed

---

## Layer Responsibilities

### 1. API Layer (`TacticManagement.Api`)

**Responsibilities**:
- HTTP request/response handling
- Authentication/authorization enforcement
- Routing and API versioning
- Swagger/OpenAPI documentation
- Middleware pipeline orchestration

**Key Components**:
- **Controllers**: Thin controllers that delegate to MediatR
- **Middleware**: CorrelationId, ExceptionHandling
- **Program.cs**: Dependency injection configuration

**Pattern**:
- Controllers have **no business logic**
- Extract user context (UserId, roles) from JWT claims
- Delegate all operations to MediatR

### 2. Application Layer (`TacticManagement.Application`)

**Responsibilities**:
- Business logic orchestration
- Command/query handling
- Validation (FluentValidation)
- Data access (via repositories)
- DTO mapping

**Key Components**:
- **Command Handlers**: Execute write operations
- **Query Handlers**: Execute read operations
- **Validators**: FluentValidation rules
- **Repositories**: Data access implementations
- **DbContext**: Entity Framework Core context

**Pattern**:
- One handler per command/query
- Handlers are **stateless**
- Dependencies injected via constructor
- Comprehensive structured logging

### 3. Domain Layer (`TacticManagement.Domain`)

**Responsibilities**:
- Domain entities (business objects)
- Command/query definitions
- DTOs (data transfer objects)
- Enums and value objects
- **No external dependencies**

**Key Components**:
- **Models**: Domain entities (`Tactic`, `TacticType`)
- **Commands**: Command definitions
- **Queries**: Query definitions
- **DTOs**: Request/response models
- **Enums**: Status, roles, etc.

**Pattern**:
- **Pure C#** - no framework dependencies
- Rich domain models with behavior
- Self-validating where appropriate

---

## Project-Specific Patterns

### 1. BDD/GWT Testing Pattern
**All test files MUST follow Given-When-Then pattern**

**Structure:**
```csharp
public class HandlerTests : IDisposable
{
    // State fields
    private List<Entity> _knownEntities;
    private Result _result;
    private Exception _exception;
    
    // Given methods - setup
    private async Task Given_Some_Entities() { }
    
    // When method - centralized execution with exception handling
    private async Task When_Executing_Handler() 
    {
        try { _result = await _handler.Handle(...); }
        catch (Exception ex) { _exception = ex; }
    }
    
    // Then methods - assertions
    private void Then_Result_Should_Match() { }
    
    // Test methods compose Given/When/Then
    [Fact]
    public async Task Handle_WhenValid_ReturnsSuccess()
    {
        await Given_Some_Entities();
        await When_Executing_Handler();
        Then_Result_Should_Match();
    }
}
```

**See**: `docs/testing/BDD-GWT-Testing-Style-Guide.md`

### 2. Offer Code Generation

Offer codes are unique identifiers for tactics, generated using SQL Server IDENTITY:

**Implementation:**
- **Database:** `IDENTITY(100000, 1)` on `Tactics.OfferCode` column
- **EF Core:** Configured with `UseIdentityColumn()` and `ValueGeneratedOnAdd()`
- **Application:** Single `AddAsync()` call - database generates code atomically

**Benefits:**
- **Concurrency-safe:** Database handles synchronization
- **No race conditions:** Atomic generation and insert
- **Better performance:** No MAX() query overhead
- **Simpler code:** No retry logic required

**Note:** Offer codes may have gaps due to transaction rollbacks or failed validations. This is acceptable as offer codes are identifiers, not sequential counters.

**See:** ADR-31 for detailed decision rationale

### 3. UTC DateTime Enforcement
**Pattern**: Three-layer defense

1. **Domain**: Use `DateTime.UtcNow` for new dates
2. **Database**: DATETIME2 with GETUTCDATE() defaults
3. **DbContext**: ValueConverters + SaveChanges validation

```csharp
// DbContext validates on save
public override int SaveChanges()
{
    ValidateUtcDates(); // Throws if any DateTime.Kind != Utc
    return base.SaveChanges();
}
```

**See**: `docs/adrs/20251107-06-defensive-utc-datetime-enforcement.md`

### 4. Security Pattern
**Always return 404 (not 403) for unauthorized access**

```csharp
// Query Handler
if (!tactic.CanBeViewedBy(userId))
    throw new KeyNotFoundException($"Tactic {id} not found"); // NOT UnauthorizedAccessException
```

**Why?** Prevents information disclosure about entity existence

### 5. Structured Logging
**Pattern**: Correlation ID + structured parameters

```csharp
_logger.LogInformation(
    "[{CorrelationId}] Creating tactic. Description: {Description}, Type: {TypeId}",
    correlationId, description, typeId);
```

**Middleware Order**: HTTPS → CorrelationId → ExceptionHandling → Authentication → Authorization

---

## Quick Reference

### Creating a New Command

1. **Define Command** (`Domain/Commands/`)
   ```csharp
   public class DoSomethingCommand : IRequest<DoSomethingResponse> { }
   ```

2. **Define Response** (`Domain/DTOs/`)
   ```csharp
   public class DoSomethingResponse { public Guid Id { get; set; } public bool Success { get; set; } }
   ```

3. **Create Handler** (`Application/Tactics/Commands/`)
   ```csharp
   public class DoSomethingCommandHandler : IRequestHandler<DoSomethingCommand, DoSomethingResponse> { }
   ```

4. **Add FluentValidation** (`Application/Validators/`)
   ```csharp
   public class DoSomethingRequestValidator : AbstractValidator<DoSomethingRequest> { }
   ```

5. **Wire up Controller** (`Api/Controllers/`)
   ```csharp
   var response = await _mediator.Send(command);
   return CreatedAtAction(...);
   ```

### Creating a New Query

1. **Define Query** (`Domain/Queries/`)
   ```csharp
   public class GetSomethingQuery : IRequest<SomethingDto> { }
   ```

2. **Define DTO** (`Domain/DTOs/`)
   ```csharp
   public class SomethingDto { /* properties */ }
   ```

3. **Create Handler** (`Application/Tactics/Queries/`)
   ```csharp
   public class GetSomethingQueryHandler : IRequestHandler<GetSomethingQuery, SomethingDto> { }
   ```

4. **Wire up Controller** (`Api/Controllers/`)
   ```csharp
   var result = await _mediator.Send(query);
   return Ok(result);
   ```

### Testing Checklist

- [ ] Follow BDD/GWT pattern (Given-When-Then)
- [ ] Test constructor validation (null dependencies)
- [ ] Test success scenarios
- [ ] Test error scenarios (not found, unauthorized, validation failures)
- [ ] Test business rules enforcement
- [ ] Verify repository interactions (NSubstitute)
- [ ] Test cancellation token support
- [ ] All tests pass (run `dotnet test`)

---

## Related Documentation

- **[Testing Strategy](./testing/BDD-GWT-Testing-Style-Guide.md)** - BDD/GWT testing approach
- **[Coding Standards](./CODING_STANDARDS.md)** - Code style and patterns
- **[Planning Standards](./PLANNING_STANDARDS.md)** - Feature planning approach
- **[CI/CD Setup](./CI-CD-SETUP.md)** - Pipeline configuration
- **[Logging](./LOGGING_INSTRUMENTATION.md)** - Structured logging guide
- **[ADRs](./adrs/)** - Architecture Decision Records

---

## Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 2.0 | 2025-11-07 | System | Streamlined for AI agents: Added Business Rules, removed redundancy, focused on patterns |
| 1.0 | 2025-11-04 | System | Initial architecture document |
