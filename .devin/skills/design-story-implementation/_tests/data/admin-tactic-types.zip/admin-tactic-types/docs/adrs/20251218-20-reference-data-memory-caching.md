# ADR 013. Reference Data Memory Caching Strategy

Date: 2025-12-18

## Status

Accepted

## Context

The Tactic Management API provides reference data endpoints for UI dropdowns and validation. This includes:

- **Tactic Types** (4 digital types: Cash Back, Load to Card, Reward Points, UDC)
- **Delivery Methods** (9 total methods across all tactic types)
- **GL Codes** (accounting reference data)
- **WBS/Event Codes** (accounting reference data, filtered by GL Code)
- **Attachment Types** (Creative Asset, UPC List, Reference)
- **Digital Providers** (proof-ready vendors)
- **Creative Agencies** (design vendors)
- **Printers** (print vendors)
- **Offer Types** (offer classification)

**Characteristics of Reference Data:**
- **Read-heavy**: Accessed frequently by UI (every form load, validation)
- **Write-rarely**: Updated infrequently (quarterly or less)
- **Small datasets**: Typically 5-50 items per reference table
- **Stable**: Values don't change during user sessions
- **Performance-critical**: Must load quickly for responsive UI

**Problem:**
Without caching, every reference data request hits the database, causing:
- Unnecessary database load (hundreds of queries per day for same data)
- Slower API response times (50-100ms per query)
- Poor user experience (dropdowns load slowly)
- Wasted server resources (repeated queries for identical data)

**Requirements:**
1. Fast response times for reference data queries (<10ms)
2. Reduce database load for frequently accessed data
3. Ensure data freshness (updates visible within reasonable time)
4. Simple implementation (no distributed cache infrastructure)
5. Support filtered queries (e.g., Delivery Methods by Tactic Type)
6. Consistent pattern across all reference data endpoints

## Decision

**Use ASP.NET Core IMemoryCache with 1-hour sliding expiration for all reference data queries.**

### Implementation Pattern

**Cache Configuration:**
- **Cache Type**: `IMemoryCache` (in-process memory cache)
- **Expiration**: 
  - **Global queries**: 1-hour sliding expiration (admin, unfiltered)
  - **OpCo-filtered queries**: 15-minute sliding expiration (updated 2026-02-25)
- **Cache Keys**: Descriptive string format with parameters
- **Scope**: Per-query handler (injected via DI)

**Cache Key Formats:**
```
TacticTypes                              // All tactic types (1-hour TTL)
DeliveryMethods:All                      // All delivery methods (1-hour TTL)
DeliveryMethods:{tacticTypeId}           // Filtered by tactic type (1-hour TTL)
GlCodes:{yyyy-MM-dd}                     // Active GL codes by date (1-hour TTL)
WbsEventCodes:{glCode}:{yyyy-MM-dd}      // WBS codes by GL code and date (1-hour TTL)
AttachmentTypes                          // All attachment types (1-hour TTL)
OfferTypes                               // All offer types (1-hour TTL)

// OpCo-filtered queries (15-minute TTL) - Added 2026-02-25
Entities:DigitalProvider:All             // All digital providers (admin, 1-hour TTL)
Entities:DigitalProvider:{opCoCode}      // OpCo-filtered digital providers (15-min TTL)
Entities:CreativeAgency:All              // All creative agencies (admin, 1-hour TTL)
Entities:CreativeAgency:{opCoCode}       // OpCo-filtered creative agencies (15-min TTL)
Entities:Printer:All                     // All printers (admin, 1-hour TTL)
Entities:Printer:{opCoCode}              // OpCo-filtered printers (15-min TTL)
```

**Handler Pattern:**
```csharp
public class GetDeliveryMethodsQueryHandler : IRequestHandler<GetDeliveryMethodsQuery, IEnumerable<DeliveryMethodDto>>
{
    private readonly IDeliveryMethodRepository _repository;
    private readonly IMemoryCache _cache;
    private readonly ILogger<GetDeliveryMethodsQueryHandler> _logger;

    public async Task<IEnumerable<DeliveryMethodDto>> Handle(
        GetDeliveryMethodsQuery request, 
        CancellationToken cancellationToken)
    {
        // Build cache key based on query parameters
        var cacheKey = request.TacticTypeId.HasValue 
            ? $"DeliveryMethods:{request.TacticTypeId}" 
            : "DeliveryMethods:All";

        // Try to get from cache
        if (_cache.TryGetValue(cacheKey, out IEnumerable<DeliveryMethodDto>? cachedResult) 
            && cachedResult != null)
        {
            _logger.LogDebug("Delivery methods retrieved from cache. Key: {CacheKey}", cacheKey);
            return cachedResult;
        }

        _logger.LogDebug("Delivery methods not in cache. Querying repository.");

        // Query database
        var deliveryMethods = request.TacticTypeId.HasValue
            ? await _repository.GetByTacticTypeIdAsync(request.TacticTypeId.Value, cancellationToken)
            : await _repository.GetAllAsync(cancellationToken);

        // Map to DTOs and order
        var dtos = deliveryMethods
            .OrderBy(dm => dm.DisplayOrder)
            .Select(dm => new DeliveryMethodDto
            {
                Id = dm.Id,
                Name = dm.Name,
                TacticTypeId = dm.TacticTypeId,
                DisplayOrder = dm.DisplayOrder
            })
            .ToList();

        // Store in cache with sliding expiration
        // Use 15-minute TTL for OpCo-filtered queries, 1-hour for global queries
        var ttl = cacheKey.Contains(":") && !cacheKey.EndsWith(":All") 
            ? TimeSpan.FromMinutes(15)  // OpCo-filtered
            : TimeSpan.FromHours(1);     // Global/Admin
        
        _cache.Set(cacheKey, dtos, new MemoryCacheEntryOptions
        {
            SlidingExpiration = ttl
        });

        _logger.LogInformation(
            "Retrieved {Count} delivery methods for TacticTypeId: {TacticTypeId}", 
            dtos.Count, 
            request.TacticTypeId?.ToString() ?? "All");

        return dtos;
    }
}
```

**Dependency Injection:**
```csharp
// Program.cs - IMemoryCache registered by default in ASP.NET Core
builder.Services.AddMemoryCache();
```

### Cache Invalidation Strategy

**Sliding Expiration (Chosen Approach):**
- Cache entries expire after 1 hour of inactivity
- Frequently accessed data stays cached
- Infrequently accessed data expires naturally
- No manual invalidation needed for reference data

**When Cache is Invalidated:**
1. **Automatic**: After 1 hour of no access (sliding expiration)
2. **Application Restart**: Cache cleared when app restarts
3. **Manual** (future): Admin endpoint to clear specific cache keys (not implemented yet)

**Why NOT Absolute Expiration:**
- Reference data changes infrequently (quarterly or less)
- 1-hour sliding window provides good balance between freshness and performance
- Frequently accessed data (like Tactic Types) stays cached indefinitely
- Rarely accessed data expires naturally

**Why NOT Distributed Cache (Redis):**
- Single-server deployment (no need for shared cache)
- Small datasets (KB, not MB)
- In-memory cache is faster (no network latency)
- Simpler infrastructure (no Redis dependency)

### Performance Characteristics

**Cache Hit (Typical Case):**
- Response time: <5ms
- Database queries: 0
- Memory usage: ~1-5 KB per cache entry

**Cache Miss (First Request or After Expiration):**
- Response time: 50-100ms (database query + mapping)
- Database queries: 1
- Memory usage: Query result cached

**Memory Footprint (Estimated):**
```
Tactic Types:        4 items × 100 bytes  = 0.4 KB
Delivery Methods:    9 items × 150 bytes  = 1.4 KB
GL Codes:           50 items × 200 bytes  = 10 KB
WBS Event Codes:   100 items × 200 bytes  = 20 KB (per GL Code)
Other Reference:    ~5 KB total
---
Total (worst case): ~50 KB (negligible)
```

### Logging Strategy

**Cache Operations Logged:**
- **Debug Level**: Cache hits, cache misses, cache key used
- **Information Level**: Data retrieved count, query parameters
- **Warning Level**: Missing required parameters

**Example Logs:**
```
[Debug] Delivery methods not in cache. Querying repository.
[Debug] Delivery methods retrieved from cache. Key: DeliveryMethods:2
[Information] Retrieved 4 delivery methods for TacticTypeId: 2
```

## Consequences

### Positive Consequences

1. **Dramatic Performance Improvement**
   - Reference data queries: 50-100ms → <5ms (10-20x faster)
   - Reduced database load: ~90% fewer queries for reference data
   - Better user experience: Dropdowns load instantly

2. **Scalability**
   - Supports high concurrent user load without database bottleneck
   - Memory footprint is negligible (~50 KB total)
   - No additional infrastructure required

3. **Simplicity**
   - Built-in ASP.NET Core feature (IMemoryCache)
   - Consistent pattern across all reference data handlers
   - Easy to understand and maintain
   - No distributed cache complexity

4. **Flexibility**
   - Separate cache entries for filtered queries (e.g., by Tactic Type, by date)
   - Sliding expiration ensures frequently used data stays cached
   - Cache keys are descriptive and debuggable

5. **Data Freshness**
   - 1-hour window is acceptable for reference data (changes quarterly)
   - Application restart clears cache (deployments pick up new data)
   - Can add manual invalidation endpoint if needed

### Negative Consequences

1. **Stale Data Risk**
   - Reference data changes may not be visible for up to 1 hour
   - **Mitigation**: Reference data changes are rare (quarterly), 1-hour delay is acceptable
   - **Mitigation**: Application restart clears cache (deployments force refresh)

2. **Cache Warming**
   - First request after app start or cache expiration is slower (cache miss)
   - **Mitigation**: Subsequent requests are fast (cache hit)
   - **Mitigation**: Most reference data is accessed frequently (stays cached)

3. **Memory Usage**
   - Cache consumes server memory (though minimal: ~50 KB)
   - **Mitigation**: Memory footprint is negligible for reference data
   - **Mitigation**: Sliding expiration releases memory for unused data

4. **No Cross-Server Cache Sharing**
   - Each application instance has its own cache
   - **Mitigation**: Single-server deployment (no load balancer yet)
   - **Future**: If scaling to multiple servers, consider Redis

5. **Manual Invalidation Not Implemented**
   - No admin endpoint to clear cache on-demand
   - **Mitigation**: Application restart clears cache
   - **Future**: Can add cache invalidation endpoint if needed

### Trade-offs Accepted

| Aspect | Trade-off | Rationale |
|--------|-----------|-----------|
| **Freshness vs Performance** | Accept 1-hour stale data | Reference data changes quarterly, 1-hour delay acceptable |
| **Simplicity vs Features** | No distributed cache | Single-server deployment, in-memory cache sufficient |
| **Memory vs Speed** | Use memory for cache | ~50 KB is negligible, 10-20x speed improvement worth it |
| **Automatic vs Manual** | No manual invalidation | App restart sufficient, can add later if needed |

### Future Considerations

1. **Distributed Cache (Redis)**
   - **When**: Scaling to multiple application servers
   - **Why**: Share cache across instances, reduce database load
   - **Effort**: Medium (add Redis dependency, update handlers)

2. **Cache Invalidation Endpoint**
   - **When**: Reference data changes become more frequent
   - **Why**: Allow admins to force cache refresh without app restart
   - **Effort**: Low (add admin endpoint to clear cache keys)

3. **Cache Warming on Startup**
   - **When**: First-request latency becomes an issue
   - **Why**: Pre-populate cache on app startup
   - **Effort**: Low (background task to query all reference data)

4. **Monitoring & Metrics**
   - **When**: Need visibility into cache effectiveness
   - **Why**: Track hit/miss ratios, memory usage, performance gains
   - **Effort**: Low (add telemetry events for cache operations)

## References

- **Implementation Examples**:
  - `GetGlCodesQueryHandler.cs` (GL Codes with date-based caching)
  - `GetWbsEventCodesQueryHandler.cs` (WBS Codes with GL Code + date caching)
  - `GetDeliveryMethodsQueryHandler.cs` (Delivery Methods with Tactic Type filtering)

- **Microsoft Documentation**:
  - [ASP.NET Core Memory Cache](https://learn.microsoft.com/en-us/aspnet/core/performance/caching/memory)
  - [Cache in-memory in ASP.NET Core](https://learn.microsoft.com/en-us/aspnet/core/performance/caching/memory)

- **Related ADRs**:
  - None (this is the first caching ADR)

- **Design Review**:
  - `docs/reqs/09 - Update Tactic Details/design-review-outcome.md` (Caching strategy confirmed)

## Updates

### 2026-02-25: OpCo-Filtered Cache TTL Reduction
- **Change**: OpCo-filtered reference queries now use 15-minute TTL (Story 25A)
- **Previous**: All reference data cached for 1 hour
- **Current**: 
  - Global/Admin queries: 1-hour TTL (unchanged)
  - OpCo-filtered queries: 15-minute TTL (new)
- **Rationale**: OpCo-Entity associations may change more frequently; 15-minute window balances freshness vs performance
- **Implementation**: Cache key pattern determines TTL (contains `:` but not `:All` = OpCo-filtered)
- **Trade-off**: Slightly increased cache misses vs reduced stale data risk (15 min acceptable)
