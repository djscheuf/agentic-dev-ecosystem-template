# 20260127-16. Field-Level Authorization Service for Tactic Updates

Date: 2026-01-27

## Status

Accepted

**Implementation Note:** Service implemented and integrated into `UpdateTacticCommandHandler` as of 2026-01-27. See:
- `IFieldAuthorizationService` interface
- `FieldAuthorizationService` implementation
- Integration in `UpdateTacticCommandHandler.Handle()` (line 72-73)

## Context

The UpdateTactic PATCH endpoint currently allows any authenticated user to send any field in the request body. Authorization is partially enforced through role-based checks in the handler, but several issues exist:

1. **Insufficient Validation**: If a user sends unauthorized fields with values that match the current state, the request succeeds even though the user shouldn't be allowed to send those fields at all.

2. **Complex Handler Logic**: Authorization logic is embedded directly in the UpdateTacticCommandHandler, mixing business logic with security concerns. This makes the handler difficult to test and maintain.

3. **Status-Aware Permissions**: Different roles have different field permissions based on the tactic's current status. For example, a ProofReader can only modify `OfferVerbiage` and `Comments` when the tactic is in `PROOF_READY` status, but the current implementation doesn't cleanly express this.

4. **Security Risk**: A malicious client could probe which fields exist by sending all possible fields and observing which ones are accepted or rejected.

5. **Unclear Client Contract**: The API doesn't clearly communicate which fields are allowed for a given role and status, forcing clients to guess or implement their own authorization logic.

### Alternative Considered: Endpoint Proliferation

We considered creating separate endpoints for each role/status combination:
- `PATCH /api/tactics/{id}/draft-updates` (InternalRequester only)
- `PATCH /api/tactics/{id}/proof-ready-updates` (ProofReader only)
- `PATCH /api/tactics/{id}/verbiage` (ProofReader in PROOF_READY status)

**Why Rejected:**
- Violates DRY principle - duplicate validation and persistence logic across endpoints
- Explodes API surface area - O(roles × statuses) endpoint growth
- Harder to maintain consistency - changes must be synchronized across endpoints
- Doesn't scale - adding new roles or statuses requires new endpoints
- Client complexity - client must know which endpoint to call for each scenario

## Decision

We will implement a **Field Authorization Service** that validates field-level permissions before any changes are applied.

### Architecture

```
Controller → UpdateTacticCommandHandler → IFieldAuthorizationService → Apply Changes
                                                    ↓
                                          Validates fields based on:
                                          - User roles (from UserContext)
                                          - Tactic status
                                          - Requested field changes
```

### Service Interface

```csharp
public interface IFieldAuthorizationService
{
    /// <summary>
    /// Validates that the requested field changes are authorized.
    /// Throws UnauthorizedAccessException if any unauthorized fields are being changed.
    /// </summary>
    Task ValidateFieldChangesAsync(
        UpdateTacticCommand command,
        Tactic currentTactic,
        UserContext userContext,
        CancellationToken cancellationToken = default);
    
    /// <summary>
    /// Gets the list of fields that can be modified for the given roles and status.
    /// </summary>
    IReadOnlyList<string> GetAllowedFields(
        IReadOnlyList<string> roles,
        TacticStatus status,
        bool isOwnerOrRequester);
}
```

### Authorization Rules

| Role | Status | Allowed Fields |
|------|--------|----------------|
| InternalRequester | Any | All fields (admin override) |
| ProofReader | PROOF_READY | OfferVerbiage, Comments |
| ProofReader | Other | None |
| Owner/Requester (no role) | DRAFT | All fields |
| Owner/Requester (no role) | Other | None |
| No role, not owner | Any | None (read-only) |

### Validation Behavior

**Strict Field Validation:**
- If a field is sent in the command (even with the same value as current), it must be authorized
- Distinguish between `null` (clear the field) and field not provided (don't change)
- Throw `UnauthorizedAccessException` with detailed message listing denied fields

**Example Error Message:**
```
User with roles [ProofReader] attempted to modify unauthorized fields on tactic in status PROOF_READY.
Attempted fields: Description, FaceValue, CirculationQuantity
Allowed fields: OfferVerbiage, Comments
```

### Handler Integration

```csharp
public async Task<UpdateTacticResponseDto> Handle(
    UpdateTacticCommand request,
    CancellationToken cancellationToken)
{
    // 1. Retrieve tactic
    var tactic = await _tacticRepository.GetByIdAsync(...);
    
    // 2. Get user context (DB or JWT fallback)
    var userContext = await _userContextService.GetUserContextAsync(...);
    
    // 3. Validate field-level authorization (NEW)
    await _fieldAuthorizationService.ValidateFieldChangesAsync(
        request, tactic, userContext, cancellationToken);
    
    // 4. Apply changes (existing logic, simplified)
    // ... update fields ...
    
    // 5. Persist
    await _tacticRepository.UpdateAsync(tactic, cancellationToken);
    
    return new UpdateTacticResponseDto(...);
}
```

### Audit Logging

The service will log:
- **Information**: Every field authorization check with roles, status, attempted fields, allowed fields
- **Warning**: Authorization failures with denied fields
- **Information**: Successful field updates with list of updated fields

This provides a complete audit trail for security review and compliance.

## Consequences

### Positive

1. **Single Responsibility**: Handler focuses on persistence, service handles authorization
2. **Testability**: Authorization logic can be unit tested independently with all role × status combinations
3. **Maintainability**: Adding new roles or statuses only requires updating the service
4. **Security**: Fail-fast validation prevents unauthorized field access and probing
5. **Clear API Contract**: Single PATCH endpoint with well-defined authorization rules
6. **Audit Trail**: Comprehensive logging of all authorization decisions
7. **Extensibility**: Easy to add new authorization rules or policies

### Negative

1. **Client Complexity**: Clients must know which fields are allowed (mitigated by clear error messages)
2. **Service Complexity**: More complex than simple role-based endpoint authorization
3. **Testing Burden**: Requires thorough testing of all role × status × field combinations
4. **Performance**: Additional service call before applying changes (minimal - in-memory rules)

### Neutral

1. **Database Precedence**: Database roles always win over JWT claims (existing behavior, now explicit)
2. **Multi-Role Users**: Users with multiple roles get most permissive permissions (InternalRequester > ProofReader)
3. **Cache TTL**: Role changes propagate within cache TTL (15 min DB, 5 min JWT)

### Future Enhancements Enabled

1. **Dynamic Rules**: Store authorization rules in database for runtime configuration
2. **Attribute-Based Access Control (ABAC)**: More granular policies beyond role + status
3. **Client Helper Endpoint**: `GET /api/tactics/{id}/allowed-fields` to guide UI
4. **Field-Level Audit Table**: Persist field change history for compliance
5. **Partial Update Support**: Allow partial success with warnings (opt-in behavior)

## Implementation Notes

- Service will be implemented in `TacticManagement.Application` layer
- Interface will be in `TacticManagement.Application.Common.Interfaces`
- Implementation will use in-memory authorization rules (no DB lookup)
- Comprehensive unit tests required before handler integration
- Existing handler authorization logic will be removed after service integration

## Related Documents

- Technical Requirements: `docs/reqs/_tech/0B - Field Level Authorization/requirements.md`
- Related ADR: `20251022-02-cqrs-api-contracts.md` (CQRS pattern)
- Related ADR: `20260107-14-i18n-error-codes.md` (Error handling)
