# 20260129-17. Read-Write Authorization Separation for Tactic Access

Date: 2026-01-29

## Status

Accepted

## Context

Authorization logic for tactic access was duplicated across 7+ handlers with inconsistent behavior:

1. **Code Duplication**: The pattern `(tactic.OwnerId != userId && tactic.RequesterId != userId)` appeared in multiple handlers
2. **Inconsistent ProofReader Access**: ProofReaders need to access all tactics for review, but this logic was missing from most handlers (only present in `GetTacticByIdQueryHandler`)
3. **Unclear Separation**: No clear distinction between "can user access this tactic?" (read) vs "which fields can user modify?" (write)
4. **Maintenance Burden**: Adding new authorization rules required updating multiple files

### Existing Authorization Services

We already have `IFieldAuthorizationService` (ADR 20260127-16) which handles **field-level write permissions** for PATCH operations. It answers: "Which fields can this user modify based on their roles and the tactic's status?"

However, we lacked a service to answer: "Can this user read/access this tactic at all?"

### Alternative Considered: Unified Authorization Service

We considered extending `IFieldAuthorizationService` to handle both read and write authorization with a `PermissionType` enum.

**Why Rejected**:
- Violates Single Responsibility Principle
- Field-level authorization is complex enough on its own (role + status + ownership + field-specific rules)
- Read authorization is simpler (ownership + role-based) and used more frequently
- Mixing concerns would make the service harder to test and maintain
- Different use cases: Read checks happen in ALL handlers, field checks only in UpdateTactic

### Alternative Considered: Handler-Level Authorization Only

We considered keeping authorization logic in handlers without a centralized service.

**Why Rejected**:
- Code duplication across 7+ handlers
- Inconsistent behavior (ProofReader bug)
- Difficult to add new authorization rules (e.g., team-based access)
- No single source of truth for authorization decisions
- Testing burden (must test authorization in every handler)

## Decision

We will implement **two separate authorization services** with clear responsibilities:

### 1. ITacticReadAuthorizationService (NEW)

**Purpose**: Determines if a user has **read access** to a tactic.

**Interface**:
```csharp
public interface ITacticReadAuthorizationService
{
    /// <summary>
    /// Determines if a user has read access to a tactic.
    /// This includes viewing tactic details, downloading attachments, and listing attachments.
    /// Write access (field modifications) is handled by IFieldAuthorizationService.
    /// </summary>
    Task<bool> HasReadAccessAsync(
        string userId, 
        Tactic tactic,
        string correlationId,
        CancellationToken cancellationToken = default);
}
```

**Authorization Rules (Phase 1 - Updated for OpCo Scoping)**:
- Grant access if user is tactic **Owner** (`tactic.OwnerId == userId`)
- Grant access if user is tactic **Requester** (`tactic.RequesterId == userId`)
- Grant access if user has **ProofReader** role AND tactic belongs to one of user's assigned OpCos
  - **Updated 2026-02-25**: ProofReaders are now OpCo-scoped (see Story 25A)
  - ProofReaders can only read tactics from OpCos they are assigned to
  - Implementation: `tactic.OpCoId IN (user's assigned OpCo IDs)`

**Used By**: All query handlers (GET operations) and before command handlers (to verify user can access tactic before modifying)

### 2. IFieldAuthorizationService (EXISTING)

**Purpose**: Determines which **fields** a user can modify on a tactic.

**Interface**: (No changes - already exists)
```csharp
public interface IFieldAuthorizationService
{
    Task ValidateFieldChangesAsync(
        UpdateTacticCommand command,
        Tactic tactic,
        UserContext userContext,
        CancellationToken cancellationToken = default);
}
```

**Used By**: UpdateTactic PATCH operations only

### Service Interaction Pattern

Command handlers use **both services in sequence**:

```csharp
// 1. Check READ access first (can't update what you can't read)
var hasReadAccess = await _readAuthService.HasReadAccessAsync(userId, tactic, correlationId, ct);
if (!hasReadAccess) throw new TacticNotFoundException(tacticId); // 404, not 403

// 2. Get user context for write authorization
var userContext = await _userContextService.GetUserContextAsync(userId, ct);

// 3. Check WRITE access (field-level)
await _fieldAuthService.ValidateFieldChangesAsync(command, tactic, userContext, ct);
```

### Key Design Decisions

1. **Service accepts `userId` (not `UserContext`)**: Service internally calls `IUserContextService` for role lookups, handlers don't need to fetch UserContext for read checks

2. **Correlation ID parameter**: Enables consistent log tracing across service boundaries

3. **Logging levels**: Service logs at Debug (detailed decision), handler logs at Warning (security event)

4. **Fallback strategy**: Database roles → JWT roles → Deny access (log at Error if both fail)

5. **Short-circuit optimization**: Return true on first match (Owner → Requester → ProofReader)

6. **Configurable cache duration**: Role cache TTL configurable via SystemConfigurations (default 15 min database, 5 min JWT)

7. **Empty string userId**: Rejected immediately (return false)

8. **Cancellation token**: Respected immediately (bail out if cancelled)

## Consequences

### Positive

1. **Single Source of Truth**: Authorization logic centralized in one service
2. **Consistent Behavior**: ProofReader access bug fixed across all handlers
3. **Simplified Handlers**: Handlers call one method instead of implementing authorization checks
4. **Clear Separation**: Read vs Write authorization responsibilities are explicit
5. **Testability**: Authorization logic can be unit tested independently
6. **Extensibility**: Easy to add new authorization rules (team-based, role-based) without touching handlers
7. **Audit Trail**: Comprehensive logging of all authorization decisions with correlation IDs
8. **Performance**: Short-circuit optimization, role caching via UserContextService

### Negative

1. **Additional Service**: One more service to maintain (but simpler than duplicated handler logic)
2. **Two Authorization Checks**: Command handlers call both services (mitigated by caching)
3. **Cache Staleness Risk**: Revoked roles may grant access for up to cache TTL (accepted trade-off for performance)

### Neutral

1. **Handler Migration Required**: 7 handlers must be updated to use new service (incremental migration possible)
2. **UserContext Fetched Twice**: Read service fetches roles, write service fetches full context (cached, minimal overhead)
3. **ProofReader Scope**: 
   - **Original (2026-01-29)**: ProofReaders can READ all tactics but WRITE only specific fields in PROOF_READY status
   - **Updated (2026-02-25)**: ProofReaders can READ only tactics from their assigned OpCos (Story 25A)
   - ProofReaders can WRITE only specific fields in PROOF_READY status (unchanged)

### Future Enhancements Enabled

1. **Team-Based Access**: Add team membership checks to read service
2. **Additional Roles**: Easy to add Executives, Managers with read-all access
3. **Department-Based Access**: Add organizational hierarchy checks
4. **Enhanced Delegation**: More sophisticated delegation beyond RequesterId
5. **Permission Caching**: Cache authorization decisions if performance becomes critical
6. **Dynamic Rules**: Store authorization rules in database for runtime configuration

## Implementation Notes

- **Location**: `src/TacticManagement.Application/Common/Services/TacticReadAuthorizationService.cs`
- **Interface**: `src/TacticManagement.Application/Common/Interfaces/ITacticReadAuthorizationService.cs`
- **Tests**: `tests/TacticManagement.Application.Tests/Common/Services/TacticReadAuthorizationServiceTests.cs`
- **DI Registration**: `builder.Services.AddScoped<ITacticReadAuthorizationService, TacticReadAuthorizationService>()`

### Handler Migration Priority

1. `GetTacticByIdQueryHandler` - Most used, already has ProofReader logic
2. `UpdateTacticAllocationsCommandHandler` - High-value write operation
3. `MarkTacticProofReadyCommandHandler` - Status transition
4. `UploadAttachmentCommandHandler` - File operations
5. `DeleteTacticAttachmentCommandHandler` - File operations
6. `DownloadTacticAttachmentQueryHandler` - File operations
7. `GetTacticAttachmentsQueryHandler` - File operations

### Testing Requirements

- 100% unit test coverage of authorization service
- Mock `IUserContextService` role lookup failures
- Test empty string userId rejection
- Test cancellation token respect
- Test multi-role precedence logic
- Handler-level tests verify service is called correctly

### Security Considerations

- Always return 404 (not 403) for unauthorized access (prevents information disclosure)
- Empty string userId rejected immediately
- Role cache staleness: Revoked roles may grant access for up to TTL (accepted risk)
- Fallback strategy: Deny if role lookup fails (database down + no JWT claims)
- No sensitive data in logs (no offer details, verbiage)

## Related Documents

- **Requirements**: `docs/reqs/14 - Proof Reader Review/tactic-access-authZ/requirements.md`
- **Design**: `docs/reqs/14 - Proof Reader Review/tactic-access-authZ/design.md`
- **Related ADR**: `20260127-16-field-level-authorization-service.md` (Write authorization)
- **User Context**: `IUserContextService.cs` (Role lookups with caching)
- **Architecture**: `docs/ARCHITECTURE.md` (Security pattern: 404 not 403)
- **Story 25A**: `docs/reqs/25A - OpCo Entity Admin Data Model/` (OpCo-based authorization)

## Updates

### 2026-02-25: OpCo-Scoped ProofReader Access
- **Change**: ProofReaders are now scoped to their assigned OpCos (Story 25A)
- **Previous**: ProofReaders could read ALL tactics globally
- **Current**: ProofReaders can only read tactics from OpCos they are assigned to
- **Implementation**: Service must check `tactic.OpCoId IN (user's assigned OpCo IDs)` for ProofReader role
- **Rationale**: Aligns with multi-OpCo data model and organizational boundaries
