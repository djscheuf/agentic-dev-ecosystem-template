# User Personas

## What
User Personas are profiles of potential users capturing some contextual information around their interests, motivations, needs, and situations to inform [[User Story|User Stories]] created to serve them. They are, in effect, the [[Communication#Who|Audience]] of software. 

## Why
User Personas allow you to create short-hand groupings of your user-base and cognitively explore how certain features will be received by a prospective group. Further they support more Narrative approaches to software development. 

Consider [[User Story#Description| a typical user story description]], we always include a WHO element, a persona or audience that the value of the story will be received by. This relates to the [[Minimum Viable Product#Actors|Actors concept for an MVP]]. These are the people who must derive value from out product. 

Personas are a tool to develop the empathy, and understanding of the development team with what matters to their end users in an approachable, succinct way. 

## How
A User Persona is created to help the team think through impact of their design and solution on their customers. That means they need to cover both functional aspects of the [[Jobs to be done]] , but also the contextual aspects. So while a Persona may just be skeletal, covering a role and their Jobs to be done. A better Persona library would have both the Role-based, and example Personas for that Role. These examples would exist to improve empathy with the prospective user. The best of these Examples might be build from REAL end users, somewhat generalized to avoid over-optimizing for a unique user, but still gaining a strong sense of the User's wants and thinking.

## Customer Profiles vs User Personas

While User Personas focus on product users (including internal users), **Customer Profiles** are used for external customers purchasing services. The distinction matters because service customers and product customers require different engagement approaches.

### Customer Profile Elements

For external service customers, profiles should include richer contextual details that help understand the person you want to buy your service:

From [Chris Do - Why Your Customers Don't Buy From You](https://www.youtube.com/watch?v=mgNTZRpZmEk):

- **Demographics**: Age, gender, location, occupation
- **Income**: Annual earnings to understand budget capacity
- **Family**: Household composition (spouse, children, dependents)
- **Interests**: Hobbies, activities, lifestyle preferences
- **Brand Affinities**: Brands they prefer (reveals values and status)
- **Vehicle**: Transportation choice (another status/values indicator)
- **Nickname/Avatar**: A memorable shorthand (e.g., "Miranda the Hustler")

**Example Customer Profile:**

> Miranda Jones, 38-year-old female New York realtor earning $450K annually. Two children (ages 12, 5). Interests: Pilates, yoga, meditation, astrology, fine dining, travel. Brands: Lululemon, Chanel, LV, Whole Foods, Equinox. Drives a Porsche Cayenne.

These details are less relevant for internal product users, where role-based personas focusing on [[Jobs to be done]] are more appropriate.

### Psychological Profile

Understanding customer psychology is critical for service engagements, where emotional resonance drives purchasing decisions.

From [Chris Do - Why Your Customers Don't Buy From You](https://www.youtube.com/watch?v=mgNTZRpZmEk):

**Internal Wants:**
- Feel important and significant
- Leave a legacy
- Make an impact

**Fears:**
- Being burned or wasting money
- Wasting time
- Not vibing with the service provider
- Being forced to do uncomfortable things

For example, a software consulting customer fears being taken for a ride, left with non-functioning software, then asked for more money to complete work they believed was already included.

Understanding these psychological drivers enables better positioning and messaging that addresses both aspirations and anxieties.

**Related Techniques:**
- [[TGO Framework]] - For identifying service opportunities
- [[AIDCA Customer Journey Framework]] - For moving customers through awareness to advocacy


## Usage
A User Persona links to a set of [[Jobs to be done]] and generally comes with a 'flavor' which impacts those jobs. 

For example, take Beth, a mid-30s house wife. She has a husband with a stable job, 2 kids and a dog. As she is looking at going back into the workforce, she finds she needs to contract some help maintain the home. She reasonably familiar with technology but doesn't have the time to sit down at the computer and do heavy research. She uses her smartphone as her primary communication device. While she cares about getting a fair price, she is more concerned with whether she can trust any given contractor in her home!

This Persona offers a [[Presenting_Storytelling|story]] that captures the motivations, and some of the concerns that an example customer might have. This helps the team build empathy into their product and design. However, be warned! This is a facsimile! This Beth is NOT a real customer, but a fictitious representation of an example customer group. Do NOT over-optimize your solution specifically for Beth, unless you have user research and market research which would support any given trait as representative of your actual customer base!

With that in mind, you might use the Beth persona, or you could use that persona as an example from a larger group while writing the user story and designing the workflow such a user might use. Considering the [[Jobs to be done]]: "Hire Contractors who I can trust, ideally from my Phone", you might create a [[User Story]] like this:
So that I can Find relevant contractors
As a Home Maker ( such as Beth{link to the Beth Persona})
I want to ...

Naturally since the example Persona includes explicit reference to Mobile use-cases, the team will be more empathetic to that use case, ideally resulting in better [[User Experience]].



Related to 
[[Service]]
[[Stakeholder]]
