namespace TacticManagement.Domain.Models;

public class TacticType
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Category { get; set; } = "Digital";
    public int DisplayOrder { get; set; }
    
    public ICollection<DeliveryMethod> DeliveryMethods { get; set; } = new List<DeliveryMethod>();
}
