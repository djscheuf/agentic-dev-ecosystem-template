namespace TacticManagement.Domain.Models;

public class DeliveryMethod
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public int TacticTypeId { get; set; }
    public int DisplayOrder { get; set; }
    
    public TacticType? TacticType { get; set; }
}
