using System;
using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TacticManagement.Application.Reference.DTOs;
using TacticManagement.Application.Reference.Queries;
using TacticManagement.Application.SystemConfigurations.Queries;
using TacticManagement.Application.Tactics.DTOs;
using TacticManagement.Application.Tactics.Queries;

namespace TacticManagement.Api.Controllers
{
    [ApiController]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/reference")]
    [Authorize()]
    public class ReferenceController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<ReferenceController> _logger;

        public ReferenceController(IMediator mediator, ILogger<ReferenceController> logger)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [HttpGet("tactic-types")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<List<TacticTypeDto>>> GetTacticTypes()
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            
            _logger.LogInformation(
                "[{CorrelationId}] GetTacticTypes request started",
                correlationId);
            
            _logger.LogDebug(
                "[{CorrelationId}] Retrieving all tactic distribution methods",
                correlationId);
            
            var query = new GetTacticTypesQuery();
            var result = await _mediator.Send(query);
            
            _logger.LogInformation(
                "[{CorrelationId}] GetTacticTypes completed successfully. Returned {Count} tactic distribution methods",
                correlationId, result.Count);
            
            return Ok(result);
        }

        /// <summary>
        /// Retrieves the current handling fee for budget calculations.
        /// </summary>
        /// <returns>Handling fee value</returns>
        /// <response code="200">Returns the handling fee value</response>
        /// <response code="404">Handling fee configuration not found</response>
        /// <response code="500">Internal server error</response>
        [HttpGet("handling-fee")]
        [ProducesResponseType(typeof(GetHandlingFeeResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<GetHandlingFeeResponse>> GetHandlingFee(
            CancellationToken cancellationToken)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";

            _logger.LogInformation(
                "[{CorrelationId}] GetHandlingFee request started",
                correlationId);

            _logger.LogDebug(
                "[{CorrelationId}] Retrieving handling fee configuration",
                correlationId);

            try
            {
                var query = new GetHandlingFeeQuery();
                var response = await _mediator.Send(query, cancellationToken);

                _logger.LogInformation(
                    "[{CorrelationId}] GetHandlingFee completed successfully. Handling fee: {HandlingFee}",
                    correlationId, response.HandlingFee);

                return Ok(response);
            }
            catch (KeyNotFoundException ex)
            {
                _logger.LogWarning(
                    ex,
                    "[{CorrelationId}] Handling fee configuration not found",
                    correlationId);
                return NotFound(new { message = "Handling fee configuration not found" });
            }
        }

        /// <summary>
        /// Retrieves active GL Codes for a specific date.
        /// </summary>
        /// <param name="activeDate">Optional date to check for active codes. Defaults to today.</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>List of active GL Codes</returns>
        /// <response code="200">Returns the list of active GL Codes</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="500">Internal server error</response>
        [HttpGet("gl-codes")]
        [ProducesResponseType(typeof(IEnumerable<GlCodeDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<GlCodeDto>>> GetGlCodes(
            [FromQuery] DateTime? activeDate,
            CancellationToken cancellationToken)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";

            _logger.LogInformation(
                "[{CorrelationId}] GET /api/reference/gl-codes - ActiveDate: {ActiveDate}",
                correlationId, activeDate);

            var query = new GetGlCodesQuery
            {
                ActiveDate = activeDate?.Date ?? DateTime.UtcNow.Date
            };

            var result = await _mediator.Send(query, cancellationToken);

            _logger.LogInformation(
                "[{CorrelationId}] GET /api/reference/gl-codes completed - Count: {Count}",
                correlationId, result.Count());

            return Ok(result);
        }

        /// <summary>
        /// Retrieves active WBS/Event Codes for a specific GL Code and date.
        /// </summary>
        /// <param name="glCode">GL Code to filter by (required)</param>
        /// <param name="activeDate">Optional date to check for active codes. Defaults to today.</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>List of active WBS/Event Codes</returns>
        /// <response code="200">Returns the list of active WBS/Event Codes</response>
        /// <response code="400">GL Code is required</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="500">Internal server error</response>
        [HttpGet("wbs-event-codes")]
        [ProducesResponseType(typeof(IEnumerable<WbsEventCodeDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<WbsEventCodeDto>>> GetWbsEventCodes(
            [FromQuery] string glCode,
            [FromQuery] DateTime? activeDate,
            CancellationToken cancellationToken)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";

            _logger.LogInformation(
                "[{CorrelationId}] GET /api/reference/wbs-event-codes - GlCode: {GlCode}, ActiveDate: {ActiveDate}",
                correlationId, glCode, activeDate);

            if (string.IsNullOrWhiteSpace(glCode))
            {
                _logger.LogWarning(
                    "[{CorrelationId}] GET /api/reference/wbs-event-codes - GlCode is required",
                    correlationId);
                return BadRequest(new { message = "GlCode query parameter is required" });
            }

            var query = new GetWbsEventCodesQuery
            {
                GlCode = glCode,
                ActiveDate = activeDate?.Date ?? DateTime.UtcNow.Date
            };

            var result = await _mediator.Send(query, cancellationToken);

            _logger.LogInformation(
                "[{CorrelationId}] GET /api/reference/wbs-event-codes completed - Count: {Count}",
                correlationId, result.Count());

            return Ok(result);
        }

        /// <summary>
        /// Retrieves digital providers for dropdown selection, filtered by OpCo.
        /// </summary>
        /// <param name="opCoCode">Operating Company code (e.g., PURINA, NESTLE, NOOSA) - Required</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>List of digital providers filtered by OpCo</returns>
        /// <response code="200">Returns the list of digital providers</response>
        /// <response code="400">OpCo code is required or invalid</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="404">OpCo not found</response>
        /// <response code="500">Internal server error</response>
        [HttpGet("digital-providers")]
        [ProducesResponseType(typeof(IEnumerable<DigitalProviderDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<DigitalProviderDto>>> GetDigitalProviders(
            [FromQuery] string opCoCode,
            CancellationToken cancellationToken)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";

            if (string.IsNullOrWhiteSpace(opCoCode))
            {
                _logger.LogWarning(
                    "[{CorrelationId}] GET /api/reference/digital-providers - Missing opCoCode parameter",
                    correlationId);
                return BadRequest(new { message = "OpCo code is required" });
            }

            _logger.LogInformation(
                "[{CorrelationId}] GET /api/reference/digital-providers - OpCoCode: {OpCoCode}",
                correlationId, opCoCode);

            try
            {
                var query = new GetDigitalProvidersQuery(opCoCode);
                var result = await _mediator.Send(query, cancellationToken);

                _logger.LogInformation(
                    "[{CorrelationId}] GET /api/reference/digital-providers completed - OpCoCode: {OpCoCode}, Count: {Count}",
                    correlationId, opCoCode, result.Count());

                return Ok(result);
            }
            catch (KeyNotFoundException ex)
            {
                _logger.LogWarning(
                    ex,
                    "[{CorrelationId}] OpCo not found - OpCoCode: {OpCoCode}",
                    correlationId, opCoCode);
                return NotFound(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Retrieves creative agencies for dropdown selection, filtered by OpCo.
        /// </summary>
        /// <param name="opCoCode">Operating Company code (e.g., PURINA, NESTLE, NOOSA) - Required</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>List of creative agencies filtered by OpCo</returns>
        /// <response code="200">Returns the list of creative agencies</response>
        /// <response code="400">OpCo code is required or invalid</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="404">OpCo not found</response>
        /// <response code="500">Internal server error</response>
        [HttpGet("creative-agencies")]
        [ProducesResponseType(typeof(IEnumerable<CreativeAgencyDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<CreativeAgencyDto>>> GetCreativeAgencies(
            [FromQuery] string opCoCode,
            CancellationToken cancellationToken)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";

            if (string.IsNullOrWhiteSpace(opCoCode))
            {
                _logger.LogWarning(
                    "[{CorrelationId}] GET /api/reference/creative-agencies - Missing opCoCode parameter",
                    correlationId);
                return BadRequest(new { message = "OpCo code is required" });
            }

            _logger.LogInformation(
                "[{CorrelationId}] GET /api/reference/creative-agencies - OpCoCode: {OpCoCode}",
                correlationId, opCoCode);

            try
            {
                var query = new GetCreativeAgenciesQuery(opCoCode);
                var result = await _mediator.Send(query, cancellationToken);

                _logger.LogInformation(
                    "[{CorrelationId}] GET /api/reference/creative-agencies completed - OpCoCode: {OpCoCode}, Count: {Count}",
                    correlationId, opCoCode, result.Count());

                return Ok(result);
            }
            catch (KeyNotFoundException ex)
            {
                _logger.LogWarning(
                    ex,
                    "[{CorrelationId}] OpCo not found - OpCoCode: {OpCoCode}",
                    correlationId, opCoCode);
                return NotFound(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Retrieves printers for dropdown selection, filtered by OpCo.
        /// </summary>
        /// <param name="opCoCode">Operating Company code (e.g., PURINA, NESTLE, NOOSA) - Required</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>List of printers filtered by OpCo</returns>
        /// <response code="200">Returns the list of printers</response>
        /// <response code="400">OpCo code is required or invalid</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="404">OpCo not found</response>
        /// <response code="500">Internal server error</response>
        [HttpGet("printers")]
        [ProducesResponseType(typeof(IEnumerable<PrinterDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<PrinterDto>>> GetPrinters(
            [FromQuery] string opCoCode,
            CancellationToken cancellationToken)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";

            if (string.IsNullOrWhiteSpace(opCoCode))
            {
                _logger.LogWarning(
                    "[{CorrelationId}] GET /api/reference/printers - Missing opCoCode parameter",
                    correlationId);
                return BadRequest(new { message = "OpCo code is required" });
            }

            _logger.LogInformation(
                "[{CorrelationId}] GET /api/reference/printers - OpCoCode: {OpCoCode}",
                correlationId, opCoCode);

            try
            {
                var query = new GetPrintersQuery(opCoCode);
                var result = await _mediator.Send(query, cancellationToken);

                _logger.LogInformation(
                    "[{CorrelationId}] GET /api/reference/printers completed - OpCoCode: {OpCoCode}, Count: {Count}",
                    correlationId, opCoCode, result.Count());

                return Ok(result);
            }
            catch (KeyNotFoundException ex)
            {
                _logger.LogWarning(
                    ex,
                    "[{CorrelationId}] OpCo not found - OpCoCode: {OpCoCode}",
                    correlationId, opCoCode);
                return NotFound(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Retrieves all attachment types for dropdown selection.
        /// </summary>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>List of attachment types</returns>
        /// <response code="200">Returns the list of attachment types</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="500">Internal server error</response>
        [HttpGet("attachment-types")]
        [ProducesResponseType(typeof(IEnumerable<AttachmentTypeDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<AttachmentTypeDto>>> GetAttachmentTypes(
            CancellationToken cancellationToken)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";

            _logger.LogInformation(
                "[{CorrelationId}] GET /api/reference/attachment-types",
                correlationId);

            var query = new GetAttachmentTypesQuery();
            var result = await _mediator.Send(query, cancellationToken);

            _logger.LogInformation(
                "[{CorrelationId}] GET /api/reference/attachment-types completed - Count: {Count}",
                correlationId, result.Count());

            return Ok(result);
        }

        /// <summary>
        /// Retrieves all available offer types for dropdown selection.
        /// </summary>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>List of offer types ordered by display order</returns>
        /// <response code="200">Returns list of offer types</response>
        /// <response code="401">Unauthorized - Missing or invalid JWT token</response>
        /// <response code="500">Internal server error</response>
        [HttpGet("offer-types")]
        [ProducesResponseType(typeof(List<OfferTypeDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<List<OfferTypeDto>>> GetOfferTypes(
            CancellationToken cancellationToken)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";

            _logger.LogInformation(
                "[{CorrelationId}] GET /api/reference/offer-types",
                correlationId);

            var query = new GetOfferTypesQuery();
            var result = await _mediator.Send(query, cancellationToken);

            _logger.LogInformation(
                "[{CorrelationId}] GET /api/reference/offer-types completed - Count: {Count}",
                correlationId, result.Count);

            return Ok(result);
        }

        /// <summary>
        /// Retrieves legal disclaimer text based on TacticType and OpCo.
        /// </summary>
        /// <param name="tacticDistributionMethodId">The tactic distribution method ID</param>
        /// <param name="opCo">The operating company (case-insensitive)</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Legal disclaimer text</returns>
        /// <response code="200">Returns the legal disclaimer text</response>
        /// <response code="400">Invalid parameters</response>
        /// <response code="404">No legal disclaimer found for this combination</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="500">Internal server error</response>
        [HttpGet("legal-disclaimer")]
        [ProducesResponseType(typeof(LegalDisclaimerDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<LegalDisclaimerDto>> GetLegalDisclaimer(
            [FromQuery] int tacticDistributionMethodId,
            [FromQuery] string opCo,
            CancellationToken cancellationToken)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";

            _logger.LogInformation(
                "[{CorrelationId}] GET /api/reference/legal-disclaimer - TacticTypeId: {TacticTypeId}, OpCo: {OpCo}",
                correlationId, tacticDistributionMethodId, opCo);

            if (tacticDistributionMethodId <= 0)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] GET /api/reference/legal-disclaimer - Invalid TacticTypeId: {TacticTypeId}",
                    correlationId, tacticDistributionMethodId);
                return BadRequest(new { message = "TacticTypeId must be greater than 0" });
            }

            if (string.IsNullOrWhiteSpace(opCo))
            {
                _logger.LogWarning(
                    "[{CorrelationId}] GET /api/reference/legal-disclaimer - OpCo is required",
                    correlationId);
                return BadRequest(new { message = "OpCo query parameter is required" });
            }

            try
            {
                var query = new GetLegalDisclaimerQuery(tacticDistributionMethodId, opCo);
                var result = await _mediator.Send(query, cancellationToken);

                _logger.LogInformation(
                    "[{CorrelationId}] GET /api/reference/legal-disclaimer completed successfully",
                    correlationId);

                return Ok(result);
            }
            catch (KeyNotFoundException ex)
            {
                _logger.LogWarning(
                    ex,
                    "[{CorrelationId}] GET /api/reference/legal-disclaimer - Not found for TacticTypeId: {TacticTypeId}, OpCo: {OpCo}",
                    correlationId, tacticDistributionMethodId, opCo);
                return NotFound(new { message = $"No legal disclaimer found for TacticTypeId {tacticDistributionMethodId} and OpCo '{opCo}'" });
            }
        }

        /// <summary>
        /// Gets delivery methods, optionally filtered by tactic type
        /// </summary>
        /// <param name="tacticTypeId">Optional tactic type ID to filter by</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>List of delivery methods</returns>
        /// <response code="200">Returns the list of delivery methods</response>
        /// <response code="400">Invalid tacticTypeId parameter</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="500">Internal server error</response>
        [HttpGet("delivery-methods")]
        [ProducesResponseType(typeof(IEnumerable<DeliveryMethodDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<DeliveryMethodDto>>> GetDeliveryMethods(
            [FromQuery] int? tacticTypeId, 
            CancellationToken cancellationToken)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
            
            _logger.LogInformation(
                "[{CorrelationId}] GET /api/reference/delivery-methods - TacticTypeId: {TacticTypeId}", 
                correlationId, tacticTypeId?.ToString() ?? "All");

            // Validate tacticTypeId if provided
            if (tacticTypeId.HasValue && tacticTypeId.Value <= 0)
            {
                _logger.LogWarning(
                    "[{CorrelationId}] GET /api/reference/delivery-methods - Invalid TacticTypeId: {TacticTypeId}", 
                    correlationId, tacticTypeId);
                return BadRequest(new { message = "TacticTypeId must be a positive integer" });
            }

            var query = new GetDeliveryMethodsQuery { TacticTypeId = tacticTypeId };
            var result = await _mediator.Send(query, cancellationToken);

            _logger.LogInformation(
                "[{CorrelationId}] GET /api/reference/delivery-methods completed - Count: {Count}", 
                correlationId, result.Count());

            return Ok(result);
        }

        /// <summary>
        /// Retrieves all tactic statuses with their display names.
        /// </summary>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>List of tactic statuses with display names</returns>
        /// <response code="200">Returns the list of tactic statuses</response>
        /// <response code="401">Unauthorized</response>
        /// <response code="500">Internal server error</response>
        [HttpGet("tactic-statuses")]
        [ProducesResponseType(typeof(List<TacticStatusDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<List<TacticStatusDto>>> GetTacticStatuses(
            CancellationToken cancellationToken)
        {
            var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";

            _logger.LogInformation(
                "[{CorrelationId}] GET /api/reference/tactic-statuses",
                correlationId);

            var query = new GetTacticStatusesQuery();
            var result = await _mediator.Send(query, cancellationToken);

            _logger.LogInformation(
                "[{CorrelationId}] GET /api/reference/tactic-statuses completed - Count: {Count}",
                correlationId, result.Count);

            return Ok(result);
        }
    }
}
