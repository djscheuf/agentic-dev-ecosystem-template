import { useCallback, useState } from "react";
import { Button } from "@coupon-builder/ui";
import "./App.css";
import { logger } from "../../utils/logger";

function App() {
  const [count, setCount] = useState(0);

  const updateCount = useCallback(() => {
    logger.debug("Updating count");
    setCount((count) => count + 1);
  }, [setCount]);

  return (
    <>
      <h1>Tactic Admin</h1>
      <div className="card">
        <Button variant="primary" size="md" onClick={updateCount}>
          count is {count}
        </Button>
        <p>
          Edit <code>tactic/admin/src/pages/App/App.tsx</code> and save to test
          HMR
        </p>
      </div>
      <p className="read-the-docs">
        Click on the Vite and React logos to learn more
      </p>
    </>
  );
}

export default App;
