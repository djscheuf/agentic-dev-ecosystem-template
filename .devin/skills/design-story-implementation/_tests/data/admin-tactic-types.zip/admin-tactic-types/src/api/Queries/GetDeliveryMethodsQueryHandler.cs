using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using TacticManagement.Application.Interfaces;
using TacticManagement.Application.Reference.DTOs;

namespace TacticManagement.Application.Reference.Queries;

public class GetDeliveryMethodsQueryHandler : IRequestHandler<GetDeliveryMethodsQuery, IEnumerable<DeliveryMethodDto>>
{
    private readonly IDeliveryMethodRepository _repository;
    private readonly IMemoryCache _cache;
    private readonly ILogger<GetDeliveryMethodsQueryHandler> _logger;
    private static readonly TimeSpan CacheDuration = TimeSpan.FromHours(1);

    public GetDeliveryMethodsQueryHandler(
        IDeliveryMethodRepository repository,
        IMemoryCache cache,
        ILogger<GetDeliveryMethodsQueryHandler> logger)
    {
        _repository = repository ?? throw new ArgumentNullException(nameof(repository));
        _cache = cache ?? throw new ArgumentNullException(nameof(cache));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<IEnumerable<DeliveryMethodDto>> Handle(
        GetDeliveryMethodsQuery request, 
        CancellationToken cancellationToken)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        // Generate cache key based on filter
        var cacheKey = request.TacticTypeId.HasValue 
            ? $"DeliveryMethods:{request.TacticTypeId.Value}" 
            : "DeliveryMethods:All";

        // Check cache first
        if (_cache.TryGetValue(cacheKey, out IEnumerable<DeliveryMethodDto>? cachedResult))
        {
            _logger.LogDebug("Cache hit for DeliveryMethods with key: {CacheKey}", cacheKey);
            return cachedResult!;
        }

        _logger.LogDebug("Cache miss for DeliveryMethods with key: {CacheKey}, querying database", cacheKey);

        // Query database
        var deliveryMethods = request.TacticTypeId.HasValue
            ? await _repository.GetByTacticTypeIdAsync(request.TacticTypeId.Value, cancellationToken)
            : await _repository.GetAllAsync(cancellationToken);
        
        // Map to DTOs and order by DisplayOrder
        var result = deliveryMethods
            .OrderBy(dm => dm.DisplayOrder)
            .Select(dm => new DeliveryMethodDto
            {
                Id = dm.Id,
                Name = dm.Name,
                TacticTypeId = dm.TacticTypeId,
                DisplayOrder = dm.DisplayOrder
            })
            .ToList();

        // Cache results
        _cache.Set(cacheKey, result, new MemoryCacheEntryOptions
        {
            SlidingExpiration = CacheDuration
        });

        _logger.LogInformation("Retrieved {Count} delivery methods from database (TacticTypeId: {TacticTypeId})", 
            result.Count, request.TacticTypeId?.ToString() ?? "All");

        return result;
    }
}
