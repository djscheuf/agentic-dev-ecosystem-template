using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TacticManagement.Application.Entities.Commands;
using TacticManagement.Application.Entities.Queries;
using TacticManagement.Domain.Enums;
using TacticManagement.Domain.Exceptions;

namespace TacticManagement.Api.Controllers;

/// <summary>
/// Admin controller for managing Entities (Digital Providers, Creative Agencies, Printers)
/// </summary>
[ApiController]
[ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/admin/entities")]
[Authorize(Roles = "Admin")]
public class AdminEntitiesController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly ILogger<AdminEntitiesController> _logger;

    public AdminEntitiesController(
        IMediator mediator,
        ILogger<AdminEntitiesController> logger)
    {
        _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Gets all Entities
    /// </summary>
    /// <returns>List of all Entities</returns>
    /// <response code="200">Returns the list of Entities</response>
    [HttpGet]
    [ProducesResponseType(typeof(List<EntityDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAllEntities(CancellationToken cancellationToken = default)
    {
        var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
        _logger.LogDebug("[{CorrelationId}] Getting all Entities", correlationId);

        var entities = await _mediator.Send(new GetAllEntitiesQuery(), cancellationToken);

        _logger.LogInformation("[{CorrelationId}] Retrieved {Count} Entities", correlationId, entities.Count);
        return Ok(entities);
    }

    /// <summary>
    /// Gets an Entity by ID
    /// </summary>
    /// <param name="id">The Entity ID</param>
    /// <returns>The Entity details</returns>
    /// <response code="200">Returns the Entity</response>
    /// <response code="404">Entity not found</response>
    [HttpGet("{id}")]
    [ProducesResponseType(typeof(EntityDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetEntityById(Guid id, CancellationToken cancellationToken = default)
    {
        var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
        _logger.LogDebug("[{CorrelationId}] Getting Entity {EntityId}", correlationId, id);

        var entity = await _mediator.Send(new GetEntityByIdQuery(id), cancellationToken);

        if (entity == null)
        {
            _logger.LogWarning("[{CorrelationId}] Entity {EntityId} not found", correlationId, id);
            return NotFound();
        }

        _logger.LogInformation("[{CorrelationId}] Retrieved Entity {EntityId}", correlationId, id);
        return Ok(entity);
    }

    /// <summary>
    /// Creates a new Entity
    /// </summary>
    /// <param name="request">The Entity creation request</param>
    /// <returns>The created Entity</returns>
    /// <response code="201">Entity created successfully</response>
    /// <response code="400">Invalid request</response>
    [HttpPost]
    [ProducesResponseType(typeof(CreateEntityResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> CreateEntity([FromBody] CreateEntityRequest request, CancellationToken cancellationToken = default)
    {
        var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
        _logger.LogDebug("[{CorrelationId}] Creating Entity {Name} ({Type})", correlationId, request.Name, request.Type);

        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        var command = new CreateEntityCommand(request.Name, request.Type, request.UsesPrinter);
        var response = await _mediator.Send(command, cancellationToken);

        _logger.LogInformation("[{CorrelationId}] Created Entity {EntityId} ({Type})", correlationId, response.Id, response.Type);
        return CreatedAtAction(nameof(GetEntityById), new { id = response.Id }, response);
    }

    /// <summary>
    /// Updates an existing Entity
    /// </summary>
    /// <param name="id">The Entity ID</param>
    /// <param name="request">The Entity update request</param>
    /// <returns>The updated Entity</returns>
    /// <response code="200">Entity updated successfully</response>
    /// <response code="400">Invalid request</response>
    /// <response code="404">Entity not found</response>
    [HttpPut("{id}")]
    [ProducesResponseType(typeof(UpdateEntityResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateEntity(Guid id, [FromBody] UpdateEntityRequest request, CancellationToken cancellationToken = default)
    {
        var correlationId = HttpContext.Items["CorrelationId"]?.ToString() ?? "unknown";
        _logger.LogDebug("[{CorrelationId}] Updating Entity {EntityId}", correlationId, id);

        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        try
        {
            var command = new UpdateEntityCommand(id, request.Name, request.UsesPrinter, request.IsActive);
            var response = await _mediator.Send(command, cancellationToken);

            _logger.LogInformation("[{CorrelationId}] Updated Entity {EntityId}", correlationId, id);
            return Ok(response);
        }
        catch (EntityNotFoundException ex)
        {
            _logger.LogWarning("[{CorrelationId}] Entity {EntityId} not found", correlationId, id);
            return NotFound(new { error = ex.Message });
        }
    }
}

/// <summary>
/// Request model for creating an Entity
/// </summary>
public record CreateEntityRequest(string Name, EntityType Type, bool UsesPrinter);

/// <summary>
/// Request model for updating an Entity
/// </summary>
public record UpdateEntityRequest(string Name, bool UsesPrinter, bool IsActive);
