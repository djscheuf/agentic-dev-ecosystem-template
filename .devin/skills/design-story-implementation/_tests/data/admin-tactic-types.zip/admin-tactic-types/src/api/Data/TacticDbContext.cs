using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System.Linq;
using TacticManagement.Domain.Models;
using TacticManagement.Domain.Enums;

namespace TacticManagement.Infrastructure.Data
{
    public class TacticDbContext : DbContext
    {
        // UTC ValueConverter to ensure all DateTime values are stored and retrieved as UTC
        private static readonly ValueConverter<DateTime, DateTime> UtcConverter = new ValueConverter<DateTime, DateTime>(
            toDb => toDb.Kind == DateTimeKind.Utc ? toDb : DateTime.SpecifyKind(toDb, DateTimeKind.Utc),
            fromDb => DateTime.SpecifyKind(fromDb, DateTimeKind.Utc)
        );

        private static readonly ValueConverter<DateTime?, DateTime?> NullableUtcConverter = new ValueConverter<DateTime?, DateTime?>(
            toDb => toDb.HasValue ? (toDb.Value.Kind == DateTimeKind.Utc ? toDb.Value : DateTime.SpecifyKind(toDb.Value, DateTimeKind.Utc)) : toDb,
            fromDb => fromDb.HasValue ? DateTime.SpecifyKind(fromDb.Value, DateTimeKind.Utc) : fromDb
        );

        public TacticDbContext(DbContextOptions<TacticDbContext> options)
            : base(options)
        {
        }

        public DbSet<Tactic> Tactics { get; set; } = null!;
        public DbSet<TacticType> TacticTypes { get; set; } = null!;
        public DbSet<DeliveryMethod> DeliveryMethods { get; set; } = null!;
        public DbSet<SystemConfiguration> SystemConfigurations { get; set; } = null!;
        public DbSet<TacticAllocation> TacticAllocations { get; set; } = null!;
        public DbSet<GlCode> GlCodes { get; set; } = null!;
        public DbSet<WbsEventCode> WbsEventCodes { get; set; } = null!;
        public DbSet<TacticAttachment> TacticAttachments { get; set; } = null!;
        public DbSet<AttachmentType> AttachmentTypes { get; set; } = null!;
        public DbSet<DigitalProvider> DigitalProviders { get; set; } = null!;
        public DbSet<CreativeAgency> CreativeAgencies { get; set; } = null!;
        public DbSet<Printer> Printers { get; set; } = null!;
        public DbSet<OfferType> OfferTypes { get; set; } = null!;
        public DbSet<TacticProductRow> TacticProductRows { get; set; } = null!;
        public DbSet<VerbiageBrand> VerbiageBrands { get; set; } = null!;
        public DbSet<VerbiageCategory> VerbiageCategories { get; set; } = null!;
        public DbSet<VerbiageSpecies> VerbiageSpecies { get; set; } = null!;
        public DbSet<VerbiageSizeVerbiage> VerbiageSizeVerbiages { get; set; } = null!;
        public DbSet<VerbiagePackageType> VerbiagePackageTypes { get; set; } = null!;
        public DbSet<VerbiageMeasure> VerbiageMeasures { get; set; } = null!;
        public DbSet<VerbiageSingleMultiUnitCount> VerbiageSingleMultiUnitCounts { get; set; } = null!;
        public DbSet<VerbiageBrandCategory> VerbiageBrandCategories { get; set; } = null!;
        public DbSet<VerbiageBrandSpecies> VerbiageBrandSpecies { get; set; } = null!;
        public DbSet<User> Users { get; set; } = null!;
        public DbSet<Role> Roles { get; set; } = null!;
        public DbSet<UserRole> UserRoles { get; set; } = null!;
        
        // OpCo and Entity Management
        public DbSet<OpCo> OpCos { get; set; } = null!;
        public DbSet<Entity> Entities { get; set; } = null!;
        public DbSet<UserOpCo> UserOpCos { get; set; } = null!;
        public DbSet<UserEntity> UserEntities { get; set; } = null!;
        public DbSet<OpCoEntity> OpCoEntities { get; set; } = null!;
        public DbSet<TacticManagement.Domain.Models.TacticStatus> TacticStatuses { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure TacticStatus FIRST - before Tactic entity that references it
            modelBuilder.Entity<TacticManagement.Domain.Models.TacticStatus>(entity =>
            {
                entity.ToTable("TacticStatus");
                entity.HasKey(ts => ts.Id);
                
                entity.Property(ts => ts.StatusName)
                    .IsRequired()
                    .HasMaxLength(50);
                
                entity.Property(ts => ts.DisplayName)
                    .IsRequired()
                    .HasMaxLength(100);
                
                entity.Property(ts => ts.DisplayOrder)
                    .IsRequired();
                
                entity.Property(ts => ts.CreatedAt)
                    .IsRequired()
                    .HasConversion(UtcConverter);
            });

            modelBuilder.Entity<Tactic>(entity =>
            {
                // Primary Key
                entity.HasKey(t => t.Id);

                // Required fields
                entity.Property(t => t.OwnerId)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(t => t.RequesterId)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(t => t.Description)
                    .HasMaxLength(25);

                entity.Property(t => t.PromoPlanId)
                    .HasMaxLength(200);

                entity.Property(t => t.Databar)
                    .HasColumnType("NVARCHAR(MAX)");

                entity.Property(t => t.Comments)
                    .HasColumnType("NVARCHAR(MAX)");

                entity.Property(t => t.Notes)
                    .HasColumnType("NVARCHAR(MAX)");

                // Status - Navigation property to TacticStatusEnum reference table
                entity.HasOne(t => t.Status)
                    .WithMany(s => s.Tactics)
                    .HasForeignKey(t => t.StatusId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.Property(t => t.StatusId)
                    .IsRequired();

                // OfferCode - Database-generated IDENTITY column
                // ValueGeneratedOnAdd: Database generates on INSERT
                // SetAfterSaveBehavior(Ignore): Excludes OfferCode from UPDATE statements
                entity.Property(t => t.OfferCode)
                    .UseIdentityColumn(seed: 100000, increment: 1)
                    .ValueGeneratedOnAdd()
                    .Metadata.SetAfterSaveBehavior(Microsoft.EntityFrameworkCore.Metadata.PropertySaveBehavior.Ignore);

                // Budget Input Fields (all nullable)
                entity.Property(t => t.FaceValue)
                    .HasColumnType("decimal(18,2)");

                entity.Property(t => t.CirculationQuantity);

                entity.Property(t => t.RedemptionRate)
                    .HasColumnType("decimal(5,2)");

                entity.Property(t => t.NonworkingBudget)
                    .HasColumnType("decimal(18,2)");

                // Design Card Fields (all nullable)
                entity.Property(t => t.DesignComments)
                    .HasColumnType("NVARCHAR(MAX)");

                entity.Property(t => t.DigitalProviderComments)
                    .HasColumnType("NVARCHAR(MAX)");

                // Foreign key relationships for Design Card (all optional with RESTRICT)
                entity.HasOne(t => t.DigitalProvider)
                    .WithMany()
                    .HasForeignKey(t => t.DigitalProviderId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .IsRequired(false);

                entity.HasOne(t => t.CreativeAgency)
                    .WithMany()
                    .HasForeignKey(t => t.CreativeAgencyId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .IsRequired(false);

                entity.HasOne(t => t.Printer)
                    .WithMany()
                    .HasForeignKey(t => t.PrinterId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .IsRequired(false);

                // Offer Details Fields (all nullable)
                entity.Property(t => t.ProductQuantity);

                entity.Property(t => t.OfferVerbiage)
                    .HasColumnType("NVARCHAR(MAX)");

                entity.Property(t => t.VerbiageComments)
                    .HasColumnType("NVARCHAR(MAX)");

                // Foreign key relationship for OfferType (optional with RESTRICT)
                entity.HasOne(t => t.OfferType)
                    .WithMany()
                    .HasForeignKey(t => t.OfferTypeId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .IsRequired(false);

                entity.Property(t => t.LastModifiedBy)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(t => t.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(t => t.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(t => t.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(t => t.StartDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(t => t.EndDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Foreign key relationship for TacticType (required)
                entity.HasOne(t => t.TacticType)
                    .WithMany()
                    .HasForeignKey(t => t.TacticTypeId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .IsRequired(true);

                // Foreign key relationship for DeliveryMethod (required)
                entity.HasOne(t => t.DeliveryMethod)
                    .WithMany()
                    .HasForeignKey(t => t.DeliveryMethodId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .IsRequired(true);

                // Indexes for performance
                entity.HasIndex(t => t.OwnerId)
                    .HasDatabaseName("IX_Tactics_OwnerId");

                entity.HasIndex(t => t.RequesterId)
                    .HasDatabaseName("IX_Tactics_RequesterId");

                entity.HasIndex(t => t.StatusId)
                    .HasDatabaseName("IX_Tactics_Status");

                entity.HasIndex(t => new { t.OwnerId, t.StatusId })
                    .HasDatabaseName("IX_Tactics_OwnerId_Status");

                entity.HasIndex(t => new { t.RequesterId, t.StatusId })
                    .HasDatabaseName("IX_Tactics_RequesterId_Status");

                // ExpiryDate (nullable)
                entity.Property(t => t.ExpiryDate)
                    .HasConversion(NullableUtcConverter);

                // Table name
                entity.ToTable("Tactics");
            });

            modelBuilder.Entity<TacticType>(entity =>
            {
                // Primary Key
                entity.HasKey(tt => tt.Id);

                // Required fields
                entity.Property(tt => tt.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(tt => tt.Category)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(tt => tt.DisplayOrder)
                    .IsRequired();

                // Navigation property for DeliveryMethods
                entity.HasMany(tt => tt.DeliveryMethods)
                    .WithOne(dm => dm.TacticType)
                    .HasForeignKey(dm => dm.TacticTypeId)
                    .OnDelete(DeleteBehavior.Restrict);

                // Index for performance
                entity.HasIndex(tt => tt.Name)
                    .IsUnique()
                    .HasDatabaseName("IX_TacticTypes_Name");

                entity.HasIndex(tt => tt.DisplayOrder)
                    .HasDatabaseName("IX_TacticTypes_DisplayOrder");

                // Table name
                entity.ToTable("TacticTypes");
            });

            modelBuilder.Entity<DeliveryMethod>(entity =>
            {
                // Primary Key
                entity.HasKey(dm => dm.Id);

                // Required fields
                entity.Property(dm => dm.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(dm => dm.TacticTypeId)
                    .IsRequired();

                entity.Property(dm => dm.DisplayOrder)
                    .IsRequired();

                // Index for performance
                entity.HasIndex(dm => dm.TacticTypeId)
                    .HasDatabaseName("IX_DeliveryMethods_TacticTypeId");

                entity.HasIndex(dm => dm.DisplayOrder)
                    .HasDatabaseName("IX_DeliveryMethods_DisplayOrder");

                // Table name
                entity.ToTable("DeliveryMethods");
            });

            modelBuilder.Entity<SystemConfiguration>(entity =>
            {
                // Primary Key
                entity.HasKey(sc => sc.ConfigKey);

                // Required fields
                entity.Property(sc => sc.ConfigKey)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(sc => sc.ConfigValue)
                    .IsRequired()
                    .HasMaxLength(500);

                entity.Property(sc => sc.DataType)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(sc => sc.Category)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(sc => sc.Description)
                    .IsRequired()
                    .HasMaxLength(500);

                entity.Property(sc => sc.IsActive)
                    .IsRequired();

                entity.Property(sc => sc.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(sc => sc.LastModifiedBy)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(sc => sc.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(sc => sc.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Indexes for performance
                entity.HasIndex(sc => sc.Category)
                    .HasDatabaseName("IX_SystemConfigurations_Category");

                entity.HasIndex(sc => sc.IsActive)
                    .HasDatabaseName("IX_SystemConfigurations_IsActive");

                entity.HasIndex(sc => new { sc.Category, sc.IsActive })
                    .HasDatabaseName("IX_SystemConfigurations_Category_IsActive");

                // Table name
                entity.ToTable("SystemConfigurations");
            });

            modelBuilder.Entity<TacticAllocation>(entity =>
            {
                // Primary Key
                entity.HasKey(ta => ta.Id);

                // Required fields
                entity.Property(ta => ta.GlDescription)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Property(ta => ta.WbsEventDescription)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Property(ta => ta.AllocationPercent)
                    .IsRequired()
                    .HasColumnType("decimal(5,2)");

                entity.Property(ta => ta.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(ta => ta.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Foreign key relationship to Tactic (cascade delete)
                entity.HasOne(ta => ta.Tactic)
                    .WithMany(t => t.Allocations)
                    .HasForeignKey(ta => ta.TacticId)
                    .OnDelete(DeleteBehavior.Cascade);

                // Index for performance
                entity.HasIndex(ta => ta.TacticId)
                    .HasDatabaseName("IX_TacticAllocations_TacticId");

                // Table name
                entity.ToTable("TacticAllocations");
            });

            modelBuilder.Entity<GlCode>(entity =>
            {
                // Primary Key
                entity.HasKey(gc => gc.Id);

                // Required fields
                entity.Property(gc => gc.Code)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(gc => gc.Description)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Property(gc => gc.ActiveStarting)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(gc => gc.ActiveUntil)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Unique constraint on Code
                entity.HasIndex(gc => gc.Code)
                    .IsUnique()
                    .HasDatabaseName("IX_GlCodes_Code");

                // Index for active date filtering
                entity.HasIndex(gc => new { gc.ActiveStarting, gc.ActiveUntil })
                    .HasDatabaseName("IX_GlCodes_ActiveDates");

                // Table name
                entity.ToTable("GlCodes");
            });

            modelBuilder.Entity<WbsEventCode>(entity =>
            {
                // Primary Key
                entity.HasKey(wec => wec.Id);

                // Required fields
                entity.Property(wec => wec.Code)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(wec => wec.Description)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Property(wec => wec.ActiveStarting)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(wec => wec.ActiveUntil)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Foreign key relationship to GlCode (restrict delete)
                entity.HasOne(wec => wec.GlCode)
                    .WithMany(gc => gc.WbsEventCodes)
                    .HasForeignKey(wec => wec.GlCodeId)
                    .OnDelete(DeleteBehavior.Restrict);

                // Unique constraint on Code
                entity.HasIndex(wec => wec.Code)
                    .IsUnique()
                    .HasDatabaseName("IX_WbsEventCodes_Code");

                // Index for GlCodeId foreign key
                entity.HasIndex(wec => wec.GlCodeId)
                    .HasDatabaseName("IX_WbsEventCodes_GlCodeId");

                // Index for active date filtering
                entity.HasIndex(wec => new { wec.ActiveStarting, wec.ActiveUntil })
                    .HasDatabaseName("IX_WbsEventCodes_ActiveDates");

                // Table name
                entity.ToTable("WbsEventCodes");
            });

            modelBuilder.Entity<TacticAttachment>(entity =>
            {
                // Primary Key
                entity.HasKey(ta => ta.Id);

                // Required fields
                entity.Property(ta => ta.FileName)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(ta => ta.FileSizeBytes)
                    .IsRequired();

                entity.Property(ta => ta.ContentType)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(ta => ta.StorageFileId)
                    .IsRequired()
                    .HasMaxLength(500);

                entity.Property(ta => ta.UploadedBy)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(ta => ta.UploadedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Foreign key relationship to Tactic (cascade delete, optional for orphaned attachments)
                entity.HasOne(ta => ta.Tactic)
                    .WithMany(t => t.Attachments)
                    .HasForeignKey(ta => ta.TacticId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .IsRequired(false);

                // Foreign key relationship to AttachmentType (restrict delete)
                entity.HasOne(ta => ta.AttachmentType)
                    .WithMany(at => at.Attachments)
                    .HasForeignKey(ta => ta.AttachmentTypeId)
                    .OnDelete(DeleteBehavior.Restrict);

                // Index for TacticId foreign key (for query performance)
                entity.HasIndex(ta => ta.TacticId)
                    .HasDatabaseName("IX_TacticAttachments_TacticId");

                // Table name
                entity.ToTable("TacticAttachments");
            });

            modelBuilder.Entity<AttachmentType>(entity =>
            {
                // Primary Key
                entity.HasKey(at => at.Id);

                // Required fields
                entity.Property(at => at.Name)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(at => at.Description)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(at => at.DisplayOrder)
                    .IsRequired();

                entity.Property(at => at.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(at => at.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Unique constraint on Name
                entity.HasIndex(at => at.Name)
                    .IsUnique()
                    .HasDatabaseName("IX_AttachmentTypes_Name");

                // Index for DisplayOrder (for ordering queries)
                entity.HasIndex(at => at.DisplayOrder)
                    .HasDatabaseName("IX_AttachmentTypes_DisplayOrder");

                // Table name
                entity.ToTable("AttachmentTypes");
            });

            modelBuilder.Entity<DigitalProvider>(entity =>
            {
                // Primary Key
                entity.HasKey(dp => dp.Id);

                // Required fields
                entity.Property(dp => dp.Name)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Ignore(dp => dp.DisplayOrder);

                entity.Property(dp => dp.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(dp => dp.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Map to Entity table as a SQL view/query
                entity.ToSqlQuery(@"
                    SELECT Id, Name, CreatedDate, LastModified 
                    FROM Entity 
                    WHERE Type = 'DigitalProvider'");
            });

            modelBuilder.Entity<CreativeAgency>(entity =>
            {
                // Primary Key
                entity.HasKey(ca => ca.Id);

                // Required fields
                entity.Property(ca => ca.Name)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Property(ca => ca.UsesPrinter)
                    .IsRequired(false);

                entity.Ignore(ca => ca.DisplayOrder);

                entity.Property(ca => ca.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(ca => ca.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Map to Entity table as a SQL view/query
                entity.ToSqlQuery(@"
                    SELECT Id, Name, UsesPrinter, CreatedDate, LastModified 
                    FROM Entity 
                    WHERE Type = 'CreativeAgency'");
            });

            modelBuilder.Entity<Printer>(entity =>
            {
                // Primary Key
                entity.HasKey(p => p.Id);

                // Required fields
                entity.Property(p => p.Name)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Ignore(p => p.DisplayOrder);

                entity.Property(p => p.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(p => p.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Map to Entity table as a SQL view/query
                entity.ToSqlQuery(@"
                    SELECT Id, Name, CreatedDate, LastModified 
                    FROM Entity 
                    WHERE Type = 'Printer'");
            });

            modelBuilder.Entity<OfferType>(entity =>
            {
                // Primary Key
                entity.HasKey(ot => ot.Id);

                // Required fields
                entity.Property(ot => ot.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(ot => ot.DisplayOrder)
                    .IsRequired();

                entity.Property(ot => ot.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(ot => ot.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Unique constraint on Name
                entity.HasIndex(ot => ot.Name)
                    .IsUnique()
                    .HasDatabaseName("IX_OfferTypes_Name");

                // Index for DisplayOrder (for ordering queries)
                entity.HasIndex(ot => ot.DisplayOrder)
                    .HasDatabaseName("IX_OfferTypes_DisplayOrder");

                // Table name
                entity.ToTable("OfferTypes");
            });

            modelBuilder.Entity<TacticProductRow>(entity =>
            {
                // Primary Key
                entity.HasKey(tpr => tpr.Id);

                // Required fields
                entity.Property(tpr => tpr.SizeVerbiageId)
                    .IsRequired();

                entity.Property(tpr => tpr.FreeOrRequired)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(tpr => tpr.NumberOfUnits)
                    .IsRequired();

                entity.Property(tpr => tpr.Brand)
                    .IsRequired()
                    .HasMaxLength(100);

                // Optional fields
                entity.Property(tpr => tpr.SingleOrMultiUnitCount)
                    .HasMaxLength(50);

                entity.Property(tpr => tpr.Weight)
                    .HasColumnType("decimal(10,2)");

                entity.Property(tpr => tpr.Measure)
                    .HasMaxLength(50);

                entity.Property(tpr => tpr.PackageType)
                    .HasMaxLength(100);

                entity.Property(tpr => tpr.Category)
                    .HasMaxLength(100);

                entity.Property(tpr => tpr.Species)
                    .HasMaxLength(100);

                entity.Property(tpr => tpr.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(tpr => tpr.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Foreign key relationship to Tactic (cascade delete, optional for orphaned rows)
                entity.HasOne(tpr => tpr.Tactic)
                    .WithMany(t => t.ProductRows)
                    .HasForeignKey(tpr => tpr.TacticId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .IsRequired(false);

                // Foreign key relationship to SizeVerbiage (behavioral control - required)
                entity.HasOne(tpr => tpr.SizeVerbiage)
                    .WithMany()
                    .HasForeignKey(tpr => tpr.SizeVerbiageId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .IsRequired();

                // Foreign key relationship to Brand (nullable for optional brand tracking)
                // Column and FK constraint created in V001 baseline schema
                entity.HasOne(tpr => tpr.BrandNavigation)
                    .WithMany()
                    .HasForeignKey(tpr => tpr.BrandId)
                    .OnDelete(DeleteBehavior.NoAction)
                    .IsRequired(false);

                // Index for TacticId foreign key (for query performance)
                entity.HasIndex(tpr => tpr.TacticId)
                    .HasDatabaseName("IX_TacticProductRows_TacticId");

                // Index for SizeVerbiageId foreign key (for query performance)
                entity.HasIndex(tpr => tpr.SizeVerbiageId)
                    .HasDatabaseName("IX_TacticProductRows_SizeVerbiageId");

                // Note: BrandId index is created directly in migration script V003
                // (filtered index with INCLUDE not fully supported in EF Core fluent API)

                // Index for CreatedDate (implicit display order)
                entity.HasIndex(tpr => tpr.CreatedDate)
                    .HasDatabaseName("IX_TacticProductRows_CreatedDate");

                // Table name
                entity.ToTable("TacticProductRows");
            });

            modelBuilder.Entity<VerbiageBrand>(entity =>
            {
                // Primary Key
                entity.HasKey(vb => vb.Id);

                // Required fields
                entity.Property(vb => vb.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(vb => vb.DisplayOrder)
                    .IsRequired();

                entity.Property(vb => vb.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(vb => vb.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Unique constraint on Name
                entity.HasIndex(vb => vb.Name)
                    .IsUnique()
                    .HasDatabaseName("UQ_Verbiage_Brands_Name");

                // Index for DisplayOrder (for ordering queries)
                entity.HasIndex(vb => vb.DisplayOrder)
                    .HasDatabaseName("IX_Verbiage_Brands_DisplayOrder");

                // Table name in verbiage schema
                entity.ToTable("Brands", "verbiage");
            });

            modelBuilder.Entity<VerbiageCategory>(entity =>
            {
                // Primary Key
                entity.HasKey(vc => vc.Id);

                // Required fields
                entity.Property(vc => vc.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(vc => vc.DisplayOrder)
                    .IsRequired();

                entity.Property(vc => vc.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(vc => vc.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Unique constraint on Name
                entity.HasIndex(vc => vc.Name)
                    .IsUnique()
                    .HasDatabaseName("UQ_Verbiage_Categories_Name");

                // Index for DisplayOrder (for ordering queries)
                entity.HasIndex(vc => vc.DisplayOrder)
                    .HasDatabaseName("IX_Verbiage_Categories_DisplayOrder");

                // Table name
                entity.ToTable("Categories", "verbiage");
            });

            modelBuilder.Entity<VerbiageSpecies>(entity =>
            {
                // Primary Key
                entity.HasKey(vs => vs.Id);

                // Required fields
                entity.Property(vs => vs.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(vs => vs.DisplayOrder)
                    .IsRequired();

                entity.Property(vs => vs.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(vs => vs.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Unique constraint on Name
                entity.HasIndex(vs => vs.Name)
                    .IsUnique()
                    .HasDatabaseName("UQ_Verbiage_Species_Name");

                // Index for DisplayOrder (for ordering queries)
                entity.HasIndex(vs => vs.DisplayOrder)
                    .HasDatabaseName("IX_Verbiage_Species_DisplayOrder");

                // Table name
                entity.ToTable("Species", "verbiage");
            });

            modelBuilder.Entity<VerbiageSizeVerbiage>(entity =>
            {
                // Primary Key
                entity.HasKey(vsv => vsv.Id);

                // Required fields
                entity.Property(vsv => vsv.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(vsv => vsv.DisplayOrder)
                    .IsRequired();

                entity.Property(vsv => vsv.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(vsv => vsv.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Unique constraint on Name
                entity.HasIndex(vsv => vsv.Name)
                    .IsUnique()
                    .HasDatabaseName("UQ_VerbiageSizeVerbiages_Name");

                // Index for DisplayOrder (for ordering queries)
                entity.HasIndex(vsv => vsv.DisplayOrder)
                    .HasDatabaseName("IX_VerbiageSizeVerbiages_DisplayOrder");

                // Table name
                entity.ToTable("SizeVerbiages", "verbiage");
            });

            modelBuilder.Entity<VerbiagePackageType>(entity =>
            {
                // Primary Key
                entity.HasKey(vpt => vpt.Id);

                // Required fields
                entity.Property(vpt => vpt.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(vpt => vpt.DisplayOrder)
                    .IsRequired();

                entity.Property(vpt => vpt.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(vpt => vpt.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Unique constraint on Name
                entity.HasIndex(vpt => vpt.Name)
                    .IsUnique()
                    .HasDatabaseName("UQ_Verbiage_PackageTypes_Name");

                // Index for DisplayOrder (for ordering queries)
                entity.HasIndex(vpt => vpt.DisplayOrder)
                    .HasDatabaseName("IX_Verbiage_PackageTypes_DisplayOrder");

                // Table name
                entity.ToTable("PackageTypes", "verbiage");
            });

            modelBuilder.Entity<VerbiageMeasure>(entity =>
            {
                // Primary Key
                entity.HasKey(vm => vm.Id);

                // Required fields
                entity.Property(vm => vm.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(vm => vm.DisplayOrder)
                    .IsRequired();

                entity.Property(vm => vm.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(vm => vm.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Unique constraint on Name
                entity.HasIndex(vm => vm.Name)
                    .IsUnique()
                    .HasDatabaseName("UQ_Verbiage_Measures_Name");

                // Index for DisplayOrder (for ordering queries)
                entity.HasIndex(vm => vm.DisplayOrder)
                    .HasDatabaseName("IX_Verbiage_Measures_DisplayOrder");

                // Table name
                entity.ToTable("Measures", "verbiage");
            });

            modelBuilder.Entity<VerbiageSingleMultiUnitCount>(entity =>
            {
                // Primary Key
                entity.HasKey(uc => uc.Id);

                // Required fields
                entity.Property(uc => uc.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(uc => uc.DisplayOrder)
                    .IsRequired();

                entity.Property(uc => uc.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(uc => uc.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Unique constraint on Name
                entity.HasIndex(uc => uc.Name)
                    .IsUnique()
                    .HasDatabaseName("UQ_Verbiage_SingleMultiUnitCounts_Name");

                // Index for DisplayOrder (for ordering queries)
                entity.HasIndex(uc => uc.DisplayOrder)
                    .HasDatabaseName("IX_Verbiage_SingleMultiUnitCounts_DisplayOrder");

                // Table name
                entity.ToTable("SingleMultiUnitCounts", "verbiage");
            });

            modelBuilder.Entity<VerbiageBrandCategory>(entity =>
            {
                // Primary Key
                entity.HasKey(vbc => vbc.Id);

                // Required fields
                entity.Property(vbc => vbc.BrandId)
                    .IsRequired();

                entity.Property(vbc => vbc.CategoryId)
                    .IsRequired();

                entity.Property(vbc => vbc.DisplayOrder)
                    .IsRequired()
                    .HasDefaultValue(0);

                entity.Property(vbc => vbc.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(vbc => vbc.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Foreign key to VerbiageBrands
                entity.HasOne(vbc => vbc.Brand)
                    .WithMany()
                    .HasForeignKey(vbc => vbc.BrandId)
                    .OnDelete(DeleteBehavior.Cascade);

                // Foreign key to VerbiageCategories
                entity.HasOne(vbc => vbc.Category)
                    .WithMany()
                    .HasForeignKey(vbc => vbc.CategoryId)
                    .OnDelete(DeleteBehavior.Cascade);

                // Unique constraint: One brand can have each category only once
                entity.HasIndex(vbc => new { vbc.BrandId, vbc.CategoryId })
                    .IsUnique()
                    .HasDatabaseName("UQ_VerbiageBrandCategories_BrandId_CategoryId");

                // Index for queries by BrandId
                entity.HasIndex(vbc => vbc.BrandId)
                    .HasDatabaseName("IX_VerbiageBrandCategories_BrandId");

                // Table name
                entity.ToTable("BrandCategories", "verbiage");
            });

            modelBuilder.Entity<VerbiageBrandSpecies>(entity =>
            {
                // Primary Key
                entity.HasKey(vbs => vbs.Id);

                // Required fields
                entity.Property(vbs => vbs.BrandId)
                    .IsRequired();

                entity.Property(vbs => vbs.SpeciesId)
                    .IsRequired();

                entity.Property(vbs => vbs.DisplayOrder)
                    .IsRequired()
                    .HasDefaultValue(0);

                entity.Property(vbs => vbs.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                entity.Property(vbs => vbs.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);

                // Foreign key to VerbiageBrands
                entity.HasOne(vbs => vbs.Brand)
                    .WithMany()
                    .HasForeignKey(vbs => vbs.BrandId)
                    .OnDelete(DeleteBehavior.Cascade);

                // Foreign key to VerbiageSpecies
                entity.HasOne(vbs => vbs.Species)
                    .WithMany()
                    .HasForeignKey(vbs => vbs.SpeciesId)
                    .OnDelete(DeleteBehavior.Cascade);

                // Unique constraint: One brand can have each species only once
                entity.HasIndex(vbs => new { vbs.BrandId, vbs.SpeciesId })
                    .IsUnique()
                    .HasDatabaseName("UQ_VerbiageBrandSpecies_BrandId_SpeciesId");

                // Index for queries by BrandId
                entity.HasIndex(vbs => vbs.BrandId)
                    .HasDatabaseName("IX_VerbiageBrandSpecies_BrandId");

                // Table name
                entity.ToTable("BrandSpecies", "verbiage");
            });

            modelBuilder.Entity<User>(entity =>
            {
                // Primary Key
                entity.HasKey(e => e.UserId);
                
                entity.Property(e => e.UserId)
                    .HasMaxLength(255)
                    .IsRequired();
                
                entity.Property(e => e.Email)
                    .HasMaxLength(255);
                
                entity.Property(e => e.DisplayName)
                    .HasMaxLength(255);
                
                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValue(true);
                
                entity.Property(e => e.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);
                
                entity.Property(e => e.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);
                
                entity.HasIndex(e => e.Email)
                    .HasDatabaseName("IX_Users_Email");

                entity.ToTable("Users");
            });

            modelBuilder.Entity<Role>(entity =>
            {
                // Primary Key
                entity.HasKey(e => e.RoleId);
                
                entity.Property(e => e.RoleName)
                    .HasMaxLength(50)
                    .IsRequired();
                
                entity.Property(e => e.DisplayName)
                    .HasMaxLength(100)
                    .IsRequired();
                
                entity.Property(e => e.Description)
                    .HasMaxLength(500);
                
                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValue(true);
                
                entity.Property(e => e.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);
                
                entity.Property(e => e.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);
                
                entity.HasIndex(e => e.RoleName)
                    .IsUnique()
                    .HasDatabaseName("IX_Roles_RoleName");

                entity.ToTable("Roles");
            });

            modelBuilder.Entity<UserRole>(entity =>
            {
                // Composite Primary Key
                entity.HasKey(e => new { e.UserId, e.RoleId });
                
                entity.Property(e => e.AssignedOn)
                    .IsRequired()
                    .HasConversion(UtcConverter);
                
                entity.HasOne(e => e.User)
                    .WithMany(u => u.UserRoles)
                    .HasForeignKey(e => e.UserId)
                    .OnDelete(DeleteBehavior.Cascade);
                
                entity.HasOne(e => e.Role)
                    .WithMany(r => r.UserRoles)
                    .HasForeignKey(e => e.RoleId)
                    .OnDelete(DeleteBehavior.Cascade);
                
                entity.HasIndex(e => e.RoleId)
                    .HasDatabaseName("IX_UserRoles_RoleId");

                entity.ToTable("UserRoles");
            });

            // OpCo Configuration
            modelBuilder.Entity<OpCo>(entity =>
            {
                entity.HasKey(e => e.Id);
                
                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(200);
                
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(50);
                
                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValue(true);
                
                entity.Property(e => e.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);
                
                entity.Property(e => e.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);
                
                entity.HasIndex(e => e.Code)
                    .IsUnique()
                    .HasDatabaseName("IX_OpCo_Code");
                
                entity.HasIndex(e => e.IsActive)
                    .HasDatabaseName("IX_OpCo_IsActive");
                
                entity.ToTable("OpCo");
            });

            // Entity Configuration
            modelBuilder.Entity<Entity>(entity =>
            {
                entity.HasKey(e => e.Id);
                
                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(200);
                
                entity.Property(e => e.Type)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasConversion<string>();
                
                entity.Property(e => e.UsesPrinter)
                    .IsRequired(false);
                
                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValue(true);
                
                entity.Property(e => e.CreatedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);
                
                entity.Property(e => e.LastModified)
                    .IsRequired()
                    .HasConversion(UtcConverter);
                
                entity.HasIndex(e => e.Type)
                    .HasDatabaseName("IX_Entity_Type");
                
                entity.HasIndex(e => e.IsActive)
                    .HasDatabaseName("IX_Entity_IsActive");
                
                entity.HasIndex(e => new { e.Type, e.IsActive })
                    .HasDatabaseName("IX_Entity_Type_IsActive");
                
                entity.ToTable("Entity");
            });

            // UserOpCo Configuration
            modelBuilder.Entity<UserOpCo>(entity =>
            {
                entity.HasKey(e => new { e.UserId, e.OpCoId });
                
                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasMaxLength(450);
                
                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValue(true);
                
                entity.Property(e => e.AssignedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);
                
                entity.HasOne(e => e.OpCo)
                    .WithMany(o => o.UserOpCos)
                    .HasForeignKey(e => e.OpCoId)
                    .OnDelete(DeleteBehavior.Cascade);
                
                entity.HasIndex(e => e.UserId)
                    .HasDatabaseName("IX_UserOpCo_UserId");
                
                entity.HasIndex(e => e.OpCoId)
                    .HasDatabaseName("IX_UserOpCo_OpCoId");
                
                entity.ToTable("UserOpCo");
            });

            // UserEntity Configuration
            modelBuilder.Entity<UserEntity>(entity =>
            {
                entity.HasKey(e => new { e.UserId, e.EntityId });
                
                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasMaxLength(450);
                
                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValue(true);
                
                entity.Property(e => e.AssignedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);
                
                entity.HasOne(e => e.Entity)
                    .WithMany(en => en.UserEntities)
                    .HasForeignKey(e => e.EntityId)
                    .OnDelete(DeleteBehavior.Cascade);
                
                entity.HasIndex(e => e.UserId)
                    .HasDatabaseName("IX_UserEntity_UserId");
                
                entity.HasIndex(e => e.EntityId)
                    .HasDatabaseName("IX_UserEntity_EntityId");
                
                entity.ToTable("UserEntity");
            });

            // OpCoEntity Configuration
            modelBuilder.Entity<OpCoEntity>(entity =>
            {
                entity.HasKey(e => new { e.OpCoId, e.EntityId });
                
                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValue(true);
                
                entity.Property(e => e.AssignedDate)
                    .IsRequired()
                    .HasConversion(UtcConverter);
                
                entity.HasOne(e => e.OpCo)
                    .WithMany(o => o.OpCoEntities)
                    .HasForeignKey(e => e.OpCoId)
                    .OnDelete(DeleteBehavior.Cascade);
                
                entity.HasOne(e => e.Entity)
                    .WithMany(en => en.OpCoEntities)
                    .HasForeignKey(e => e.EntityId)
                    .OnDelete(DeleteBehavior.Cascade);
                
                entity.HasIndex(e => e.OpCoId)
                    .HasDatabaseName("IX_OpCoEntity_OpCoId");
                
                entity.HasIndex(e => e.EntityId)
                    .HasDatabaseName("IX_OpCoEntity_EntityId");
                
                entity.ToTable("OpCoEntity");
            });

            // Update Tactic to add OpCo relationship
            modelBuilder.Entity<Tactic>()
                .HasOne(t => t.OpCo)
                .WithMany(o => o.Tactics)
                .HasForeignKey(t => t.OpCoId)
                .OnDelete(DeleteBehavior.Restrict)
                .IsRequired(false);
        }

        /// <summary>
        /// Validates that all DateTime properties are in UTC before saving to the database.
        /// This is a defensive measure to catch any code that might set DateTime values without UTC.
        /// </summary>
        public override int SaveChanges(bool acceptAllChangesOnSuccess)
        {
            ValidateUtcDates();
            return base.SaveChanges(acceptAllChangesOnSuccess);
        }

        /// <summary>
        /// Validates that all DateTime properties are in UTC before saving to the database.
        /// This is a defensive measure to catch any code that might set DateTime values without UTC.
        /// </summary>
        public override Task<int> SaveChangesAsync(bool acceptAllChangesOnSuccess, CancellationToken cancellationToken = default)
        {
            ValidateUtcDates();
            return base.SaveChangesAsync(acceptAllChangesOnSuccess, cancellationToken);
        }

        /// <summary>
        /// Validates that all DateTime properties in tracked entities are in UTC.
        /// Throws InvalidOperationException if any non-UTC DateTime is found.
        /// </summary>
        private void ValidateUtcDates()
        {
            var entries = ChangeTracker.Entries()
                .Where(e => e.State == EntityState.Added || e.State == EntityState.Modified);

            foreach (var entry in entries)
            {
                var dateTimeProperties = entry.Properties
                    .Where(p => (p.Metadata.ClrType == typeof(DateTime) || p.Metadata.ClrType == typeof(DateTime?)) 
                                && p.CurrentValue != null);

                foreach (var property in dateTimeProperties)
                {
                    var dateTime = property.CurrentValue as DateTime?;
                    if (dateTime.HasValue && dateTime.Value.Kind != DateTimeKind.Utc)
                    {
                        throw new InvalidOperationException(
                            $"DateTime property '{property.Metadata.Name}' on entity '{entry.Metadata.DisplayName()}' " +
                            $"must be in UTC. Current Kind: {dateTime.Value.Kind}. " +
                            $"Use DateTime.UtcNow or DateTime.SpecifyKind(date, DateTimeKind.Utc).");
                    }
                }
            }
        }
    }
}
